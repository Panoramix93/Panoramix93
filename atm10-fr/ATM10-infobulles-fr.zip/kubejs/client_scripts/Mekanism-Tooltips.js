// This File has been authored by AllTheMods Staff, or a Community contributor for use in AllTheMods - AllTheMods 10.
// As all AllTheMods packs are licensed under All Rights Reserved, this file is not allowed to be used in any public packs not released by the AllTheMods Team, without explicit permission.

ItemEvents.modifyTooltips(allthemods => {

    // ##### Gear #####

    //Mekasuit
    allthemods.add(/mekanism:mekasuit_/, [
        Text.red("Consommation d'énergie augmentée !"),
        Text.green("Capacité d'énergie augmentée")
    ])
    //Meka Tool
    allthemods.add('mekanism:meka_tool', [
        Text.red("Consommation d'énergie augmentée !"),
        Text.green("Capacité d'énergie augmentée !"),
        Text.green("Vitesse d'attaque et dégâts augmentés !")
    ])

    // ##### Generators #####

    //Solar Generator
    allthemods.add('mekanismgenerators:solar_generator', [
        Text.green("Capacité et production d'énergie augmentées !")
    ])
    //Advanced Solar Generator
    allthemods.add('mekanismgenerators:advanced_solar_generator', [
        Text.green("Capacité et production d'énergie augmentées !")
    ])
    //Wind Generator
    allthemods.add('mekanismgenerators:wind_generator', [
        Text.green("Capacité et production d'énergie augmentées !")
    ])
    //Heat Generator
    allthemods.add('mekanismgenerators:heat_generator', [
        Text.green("Capacité et production d'énergie augmentées !")
    ])
    //Gas Burning Generator
    allthemods.add('mekanismgenerators:gas_burning_generator', [
        Text.red("Production d'énergie réduite !"),
        Text.red("Consommation de carburant augmentée !")
    ])
    //Fission Generator
    allthemods.add(/mekanismgenerators:fission_/, [
        Text.red("Production d'énergie réduite !"),
    ])
    //Fusion Generator
    allthemods.add(/mekanismgenerators:fusion_/, [
        Text.red("Production d'énergie réduite !"),
        Text.green("Consommation de carburant réduite !"),
    ])
    //Turbine
    allthemods.add(/mekanismgenerators:turbine_/, [
        Text.green("Vitesse de production augmentée !"),
    ])
    //Boiler
    allthemods.add(/mekanism:boiler_/, [
        Text.green("Vitesse de production augmentée !"),
    ])

    // ##### Machines #####

    //Upgrades
    allthemods.add(/mekanism:upgrade_/, [
        Text.green("Bonus de machine augmenté !")
    ])
    //Waste Barrel
    allthemods.add('mekanism:radioactive_waste_barrel', [
        Text.green("Taux de désintégration augmenté !")
    ])
    //Thermal Evaporation Tower
    allthemods.add(/mekanism:thermal_evaporation_/, [
        Text.green("Vitesse de production augmentée !")
    ])
    //Solar Neutron Activator
    allthemods.add('mekanism:solar_neutron_activator', [
        Text.green("Vitesse de production augmentée !"),
        Text.green("Déchets -> Polonium amélioré !")
    ])
    //Isotopic Centrifuge
    allthemods.add('mekanism:isotopic_centrifuge', [
        Text.green("Déchets -> Plutonium amélioré !")
    ])
    //Electric Pump
    allthemods.add('mekanism:electric_pump', [
        Text.green("Vitesse de production augmentée !")
    ])
    //SPS
    allthemods.add(/mekanism:sps_/, [
        Text.green("Consommation d'énergie réduite !")
    ])
})

// This File has been authored by AllTheMods Staff, or a Community contributor for use in AllTheMods - AllTheMods 10.
// As all AllTheMods packs are licensed under All Rights Reserved, this file is not allowed to be used in any public packs not released by the AllTheMods Team, without explicit permission.