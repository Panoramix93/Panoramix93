// This File has been authored by AllTheMods Staff, or a Community contributor for use in AllTheMods - AllTheMods 10.
// As all AllTheMods packs are licensed under All Rights Reserved, this file is not allowed to be used in any public packs not released by the AllTheMods Team, without explicit permission.

ItemEvents.modifyTooltips(allthemods => {

    //AllTheModium

    allthemods.add(['allthemodium:allthemodium_ore', 'allthemodium:allthemodium_slate_ore'],[
        Text.of("§7Nécessite au moins de la Netherite pour être miné"),
        Text.of("§6Dans le biome des Abîmes, toujours exposé à l'air libre"),
        Text.of("§6Aussi dans la couche d'ardoise de la Dimension minière")
    ])
    allthemods.add(['allthemodium:vibranium_ore', 'allthemodium:other_vibranium_ore'],[
        Text.of("§7Nécessite au moins de l'Allthemodium pour être miné"),
        Text.of("§bDans n'importe quel biome du Nether"),
        Text.of("§bAussi dans L'Autre")
    ])
    allthemods.add('allthemodium:unobtainium_ore',[
        Text.of("§7Nécessite au moins du Vibranium pour être miné"),
        Text.of("§dDans les Hautes terres de l'End")
    ])

    allthemods.add('kubejs:silent_allthemodium_plate',[
        Text.of("§7§oIl est moins... bavard maintenant")
    ])
    allthemods.add('kubejs:silent_vibranium_plate',[
        Text.of("§7§oIl est moins... bavard maintenant")
    ])
    allthemods.add('kubejs:silent_unobtainium_plate',[
        Text.of("§7§oIl est moins... bavard maintenant")
    ])

    allthemods.add('allthemodium:allthemodium_ingot',[
        Text.of("§7§oCe ne sont pas les lingots que vous cherchez"),
        Text.of("§6Cherchez la [Plaque d'Allthemodium silencieuse]")
    ])
    allthemods.add('allthemodium:vibranium_ingot',[
        Text.of("§7§oCe ne sont pas les lingots que vous cherchez"),
        Text.of("§6Cherchez la [Plaque de Vibranium silencieuse]")
    ])
    allthemods.add('allthemodium:unobtainium_ingot',[
        Text.of("§7§oCe ne sont pas les lingots que vous cherchez"),
        Text.of("§6Cherchez la [Plaque d'Unobtainium silencieuse]")
    ])


    allthemods.add('allthemodium:allthemodium_upgrade_smithing_template',[
        Text.of("§6Dans l'argile suspecte des Cités antiques")
    ])
    allthemods.add('allthemodium:vibranium_upgrade_smithing_template',[
        Text.of("§bDans le sable des âmes suspect des Bastions")
    ])
    allthemods.add('allthemodium:unobtainium_upgrade_smithing_template',[
        Text.of("§dLâché par le générateur d'épreuve de la Library of the Dungeon, dans L'Autre")
    ])

    //Forbidden Arcanus
    allthemods.add('forbidden_arcanus:hephaestus_forge_tier_1',[
        Text.of("§c§lMaj + clic droit§r§c sur la §c§lTable de forge§r§c avec de la §lPoudre de Mundabitur"),
        Text.of("§c█ = Pierre sombre polie sculptée dorée avec une Table de forge au-dessus"),
        Text.of("§7█ = Pierre sombre polie"),
        Text.of("§5█§7 = Pierre sombre polie sculptée dorée"),
        Text.of("§6█§7 = Pierre sombre polie arcanique sculptée"),
        Text.of("§0███§7███§0███"),
        Text.of("§0█§7███§5█§7███§0█"),
        Text.of("§0█§7█§5█§7███§5█§7█§0█"),
        Text.of("§7████§6█§7████"),
        Text.of("§7█§5█§7█§6█§c█§6█§7█§5█§7█"),
        Text.of("§7████§6█§7████"),
        Text.of("§0█§7█§5█§7███§5█§7█§0█"),
        Text.of("§0█§7███§5█§7███§0█"),
        Text.of("§0███§7███§0███")

    ])
    allthemods.add('forbidden_arcanus:clibano_core',[
        Text.of("§c§lMaj + clic droit§r§c sur le §c§lCœur de Clibano§r§c avec de la §c§lPoudre de Mundabitur"),
        Text.of("§5█§7 = Pierre sombre polie"),
        Text.of("§7█ = Briques de pierre sombre polie"),
        Text.of("§6█§7 = Cœur de Clibano"),
        Text.of("§7De droite à gauche -> de bas en haut"),
        Text.of("§5█§7█§5█§0█§7███§0█§5█§7█§5█"),
        Text.of("§7███§0█§7█§0█§7█§0█§7███"),
        Text.of("§5█§7█§5█§0█§7█§6█§7█§0█§5█§7█§5█"),
    ])
    allthemods.add('forbidden_arcanus:growing_edelwood',[
        Text.of("§4S'obtient auprès du Marchand ambulant"),
        Text.of("§4Ou en utilisant une Âme corrompue sur une Pousse de chêne"),
    ])
    allthemods.add('forbidden_arcanus:magnetized_darkstone_pedestal',[
        Text.of("§7Utilisez du Mélange ferrognétique sur le Piédestal de pierre sombre"),
    ])
    allthemods.add('forbidden_arcanus:soul',[
        Text.of("§7Utilisez un Extracteur d'âmes sur du Sable des âmes"),
        Text.of("§7Apparaît rarement dans le monde"),
    ])
    allthemods.add('forbidden_arcanus:enchanted_soul',[
        Text.of("§7Utilisez une Fiole d'Auréal jetable sur une âme normale")
    ])
    allthemods.add('forbidden_arcanus:corrupt_soul',[
        Text.of("§7Apparaît rarement en tuant des créatures")
    ])
    allthemods.add('forbidden_arcanus:blood_test_tube',[
        Text.of("§7Tenez un Tube à essai en main secondaire puis tuez des créatures")
    ])
    allthemods.add('forbidden_arcanus:xpetrified_orb',[
        Text.of("§7S'obtient uniquement via le Trou noir"),
        Text.of("§7Pour créer un Trou noir, jetez de la Matière noire avec de la Poudre de Corrupti au sol"),
        Text.of("§7Donnez-lui assez d'XP pour qu'il recrache un Orbe XPétrifié")
    ])
    allthemods.add('forbidden_arcanus:dragon_scale',[
        Text.of("§7Lâché par le Dragon de l'Ender")
    ])
    allthemods.add('forbidden_arcanus:stella_arcanum',[
        Text.of("§7Apparaît très rarement entre Y -44 et Y 42"),
        Text.of("§cExplose quand vous le minez !")
    ])
    allthemods.add(/forbidden_arcanus:runic_[sd]/,[
        Text.of("§7Apparaît du fond du monde jusqu'à Y 2"),
    ])
    allthemods.add(['forbidden_arcanus:arcane_crystal_ore', 'forbidden_arcanus:deepslate_arcane_crystal_ore'],[
        Text.of("§7Apparaît très rarement entre Y -40 et Y 14"),
        Text.of("§7Le plus fréquent à Y -13")
    ])
    allthemods.add('forbidden_arcanus:artisan_relic',[
        Text.of("§aSe trouve dans les bâtiments de l'Armurier, du Forgeron d'outils ou du Forgeron d'armes"),
    ])
    allthemods.add('forbidden_arcanus:crescent_moon',[
        Text.of("§cImpossible à obtenir"),
    ])
    allthemods.add('forbidden_arcanus:crimson_stone',[
        Text.of("§aSe trouve dans les avant-postes de pillards"),
    ])
    allthemods.add('forbidden_arcanus:soul_crimson_stone',[
        Text.of("§cSe transforme en Pierre cramoisie après 1 utilisation"),
    ])
    allthemods.add('forbidden_arcanus:elementarium',[
        Text.of("§aSe trouve dans les temples de la jungle, les pyramides du désert et les ruines sous-marines"),
    ])
    allthemods.add('forbidden_arcanus:divine_pact',[
        Text.of("§aSe trouve dans le village et la pyramide de L'Autre"),
    ])
    allthemods.add('forbidden_arcanus:maledictus_pact',[
        Text.of("§aSe trouve dans les bastions au trésor"),
    ])

    //Mystical Agriculture
    allthemods.add(/mysticalagriculture:.*watering_can/,[
        Text.of("§cDésactivé pour les faux joueurs"),
        Text.of("§c(Blocs comme les Routeurs modulaires, les Clickers, etc.)")
    ])

    allthemods.add('toolbelt:belt', [
        Text.of("§7Possède son propre emplacement dédié"),
        Text.of("§7Voyez vos raccourcis pour \"Ouvrir l'inventaire de l'emplacement de ceinture\"")
    ])

	//Easy Villagers
    allthemods.add(['easy_villagers:trader', 'easy_villagers:auto_trader'], [
        Text.of("§aFaites un clic droit avec un bloc de métier pour l'y placer et permettre le réapprovisionnement des échanges")
    ])

	//Hyperbox
    if (Platform.isLoaded("hyperbox")) {
        allthemods.add('hyperbox:hyperbox', [
            Text.of("§aCe mod sera retiré à partir de la version 6.0")
        ])
    }

    //Eternal Starlight
    if (Platform.isLoaded("eternal_starlight")) {
        allthemods.add('eternal_starlight:loot_bag[eternal_starlight:loot_table="eternal_starlight:bosses/lunar_monstrosity"]', [
            Text.of("Ce sac de butin vient de la \"Monstruosité lunaire\".")
        ])
    }

    if (Platform.isLoaded('modular_machinery_reborn')) {
        allthemods.add('modular_machinery_reborn:controller[modular_machinery_reborn:machine="atm:runic_crucible"]', [
            Text.of("§cATTENTION, cette machine est obsolète."),
            Text.of("Utilisez un établi pour la convertir en nouvelle version.")
        ])
        allthemods.add('modular_machinery_reborn:controller[modular_machinery_reborn:machine="atm:runic_star_altar"]', [
            Text.of("§cATTENTION, cette machine est obsolète."),
            Text.of("Utilisez un établi pour la convertir en nouvelle version.")
        ])
        allthemods.add('modular_machinery_reborn:controller[modular_machinery_reborn:machine="atm:runic_enchanter"]', [
            Text.of("§cATTENTION, cette machine est obsolète."),
            Text.of("Utilisez un établi pour la convertir en nouvelle version.")
        ])
        allthemods.add('modular_machinery_reborn:controller[modular_machinery_reborn:machine="atm:auto_hepheastus_forge"]', [
            Text.of("§cATTENTION, cette machine est obsolète."),
            Text.of("Utilisez un établi pour la convertir en nouvelle version.")
        ])
    }
	// Apotheosis Gateway Warning
	allthemods.add([
	'gateways:gate_pearl[gateways:gateway="apotheosis:tiered/frontier"]',
	'gateways:gate_pearl[gateways:gateway="apotheosis:tiered/ascent"]',
	'gateways:gate_pearl[gateways:gateway="apotheosis:tiered/summit"]',
	'gateways:gate_pearl[gateways:gateway="apotheosis:tiered/pinnacle"]'],
	[
		Text.of("§cATTENTION : implose à la vague 3 en dehors des dimensions suivantes :"),
		Text.of("§cMonde normal, le Nether, l'End, la Twilight Forest")
	])
	// Botany Pot Sculk
	allthemods.add([
	"minecraft:sculk",
	"minecraft:sculk_sensor",
	"minecraft:sculk_catalyst",
	"minecraft:sculk_vein",
	"minecraft:sculk_shrieker",
	"deeperdarker:gloomy_sculk",
	"deeperdarker:gloomy_grass",
	"deeperdarker:glowing_flowers",
	"deeperdarker:sculk_vines",
	"deeperdarker:glowing_roots",
	"deeperdarker:bloom_berries",
	"deeperdarker:glowing_grass",
	"deeperdarker:sculk_tendrils"],
	[
		Text.of("§9Dans un Botany Pot : nécessite une houe enchantée avec Toucher de soie pour être récoltée")
	])
})


// This File has been authored by AllTheMods Staff, or a Community contributor for use in AllTheMods - AllTheMods 10.
// As all AllTheMods packs are licensed under All Rights Reserved, this file is not allowed to be used in any public packs not released by the AllTheMods Team, without explicit permission.
