---
navigation:
  parent: enderdrives_intro/enderdrives_intro-index.md
  title: Disque de stockage d'objets Ender
  icon: enderdrives:ender_disk_1k
categories:
  - enderdrives
item_ids:
  - enderdrives:ender_disk_1k
  - enderdrives:ender_disk_4k
  - enderdrives:ender_disk_16k
  - enderdrives:ender_disk_64k
  - enderdrives:ender_disk_256k
  - enderdrives:ender_disk_creative
  - enderdrives:ender_fluid_disk_1k
  - enderdrives:ender_fluid_disk_4k
  - enderdrives:ender_fluid_disk_16k
  - enderdrives:ender_fluid_disk_64k
  - enderdrives:ender_fluid_disk_256k
  - enderdrives:ender_fluid_disk_creative
---

# Ender Drives

Les Ender Drives sont des disques puissants qui permettent un stockage global synchronisé entre plusieurs systèmes ME, plusieurs dimensions et même entre différents joueurs, grâce à un système de fréquences.  

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_1k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_1k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_4k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_4k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_16k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_16k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_64k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_64k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_disk_256k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_disk_256k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_1k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_1k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_4k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_4k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_16k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_16k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_64k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_64k" />
  </Column>
</Row>

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:ender_fluid_disk_256k" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:ender_fluid_disk_256k" />
  </Column>
</Row>


---

## Fonctionnement
Chaque EnderDrive est configuré avec une fréquence, une portée et un mode.
- Une **fréquence** : les disques partageant la même fréquence partagent le même inventaire.
- Une **portée** : elle détermine qui peut accéder au disque (globale, privée ou équipe).
- Un **mode** : il contrôle le sens de circulation des objets (bidirectionnel, entrée, sortie). 

Tous les disques ayant la même fréquence et la même portée accèdent au **même inventaire virtuel**, où qu'ils se trouvent.

---

## Limites de types
Contrairement aux disques AE2 traditionnels, la limite des EnderDrives dépend uniquement des types. En raison de la manière dont les objets sont stockés en interne, la seule véritable limite est le nombre de types. Vous pouvez littéralement stocker jusqu'à 2^63 - 1, soit 9 223 372 036 854 775 807 objets pour chaque type. Attention toutefois : le coût en énergie augmente avec la quantité d'objets stockés sur le disque à cette fréquence !

Chaque serveur commence à souffrir à partir d'un nombre de types différent. Vous pouvez tester votre serveur avec la commande autobenchmark. Pour obtenir des résultats fiables, vous devez avoir un terminal ouvert avec un disque réglé sur Privé et la fréquence sélectionnée. Le test se poursuit jusqu'à ce que le TPS descende sous 18. Cela peut prendre quelques minutes.

Ma moyenne personnelle est d'environ 275 000 types. 275 000/255 ≈ 1078. Cela signifie qu'il me faudrait remplir 107,8 Range-disques ME de Ender Drives 256k et d'objets typés avant de commencer à voir des problèmes de performance. J'ai vu des maximums conseillés plus élevés comme plus bas. Cette limite est partagée entre tous ceux qui utilisent ces disques dans le même monde.

---

## Modes des disques
Chaque disque peut être réglé sur l'un des trois **modes de transfert** suivants :

- ![PEGui1](../pic/transport_bidirectional_alt.png) **Bidirectionnel** _(par défaut)_  
  Comportement standard d'un Range-disque ME. Insertion et extraction libres.


- ![PEGui1](../pic/transport_input_alt.png) **Entrée seule**  
  Les objets peuvent être insérés, mais pas retirés. Utile pour des tampons ou pour synchroniser des entrées.


- ![PEGui1](../pic/transport_output_alt.png) **Sortie seule**  
  Les objets peuvent être extraits, mais pas insérés. Idéal pour des tampons de sortie ou un accès en lecture seule.

---

## Portée et confidentialité

Chaque disque possède également une **portée**, qui détermine qui peut accéder à l'inventaire :
-  **Globale** _(par défaut)_  
   Public ! N'importe quel joueur utilisant la même fréquence peut accéder à cet inventaire partagé.


-  **Privée**  
  Liée à votre UUID. Vous êtes le seul à pouvoir créer des disques accédant à cette fréquence. Les autres utilisateurs de votre système ME peuvent malgré tout accéder à ce stockage


-  **Équipe**  
  Partagée avec votre équipe FTB. Tous les membres peuvent créer des disques accédant à la même fréquence.
