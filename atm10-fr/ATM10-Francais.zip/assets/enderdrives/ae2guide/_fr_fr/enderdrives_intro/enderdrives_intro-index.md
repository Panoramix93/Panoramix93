---
navigation:
  title: Introduction à EnderDrives
  position: 60
---

# EnderDrives !

EnderDrives propose une autre façon de stocker les objets. Ces range-disques se relient entre eux selon la fréquence définie pour chacun. Tous les range-disques ayant la même fréquence et la même confidentialité partagent le même contenu, peu importe qui les a fabriqués. Que ce soit dans votre système AE2, dans une autre dimension ou sur le système d'un autre joueur, le contenu est synchronisé globalement.

Pour la liste complète des blocs et objets fournis, consultez ces pages du guide :

## EnderDrives

<CategoryIndex category="enderdrives"></CategoryIndex>

## TapeDrives

<CategoryIndex category="tapedrives"></CategoryIndex>

Vous avez trouvé un problème ? Une fonctionnalité manque ?
Signalez-le ici :
[EnderDrives GitHub](https://github.com/STS15/enderdrives)
