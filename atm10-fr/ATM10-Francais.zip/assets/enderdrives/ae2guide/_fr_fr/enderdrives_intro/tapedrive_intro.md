---
navigation:
  parent: enderdrives_intro/enderdrives_intro-index.md
  title: Disque de stockage d'objets à bande
  icon: enderdrives:tape_disk
categories:
  - tapedrives
item_ids:
  - enderdrives:tape_disk
---

# Disques de stockage à bande

Les disques à bande sont de puissants disques de stockage compatibles AE2, conçus pour gérer les **objets riches en NBT**, comme les outils, les armures, l'équipement enchanté ou tout objet portant des étiquettes uniques qui saturent normalement l'espace de types des range-disques ME classiques.

Contrairement aux disques AE2 habituels, les octets utilisés par un disque à bande évoluent dynamiquement selon la **taille réelle des NBT** des objets stockés, ce qui vous donne un contrôle très fin sur votre système.  Les disques à bande n'indiqueront **PAS** à AE2 qu'ils sont à privilégier pour un objet correspondant à leur filtre, utilisez la priorité du range-disque ME.

<Row gap="10">
  <Column>
    <ItemImage id="enderdrives:tape_disk" />
  </Column>
  <Column>
    <ItemLink id="enderdrives:tape_disk" />
  </Column>
</Row>

---

## Fonctionnement

Chaque disque à bande n'accepte que les objets ayant des NBT non standard, les armures, les outils ou les objets non empilables.

---

## Limites d'octets et de types

Les disques à bande imposent à la fois une **limite de types** et une **limite d'octets utilisés** :

- **Limite de types** – Nombre maximal de types d'objets uniques stockés (par exemple des livres enchantés, des armures personnalisées).
- **Limite d'octets** – Basée sur la **taille des données NBT** de chaque objet. Les objets comportant beaucoup d'étiquettes (comme l'équipement d'Apotheosis) occupent plus de place à cause de la quantité de NBT.

Les disques à bande sont conçus pour **privilégier les objets riches en NBT**, ce qui les rend parfaits pour stocker de l'équipement ou des objets uniques sans polluer l'espace des disques classiques.

---


## Quand utiliser un disque à bande

Utilisez un disque à bande plutôt qu'un disque classique lorsque :

- Vous stockez des **objets non empilables** comme des armures, des outils ou de l'équipement.
- Vous avez besoin de place pour des **objets moddés riches en NBT**.
- Vous voulez garder les objets spéciaux hors de vos range-disques ME habituels.

Les disques à bande brillent là où les disques normaux peinent : en évitant de consommer la limite de types de vos énormes disques.

---

## Transferts par port d'E/S

Un disque à bande s'auto-limite lors des transferts depuis ou vers lui via un port d'E/S.  C'est dû au fait qu'il peut manipuler des objets riches en NBT : il évite ainsi de tout déverser d'un coup et de figer votre jeu.

---

## Que peut-on y stocker ?

Les disques à bande sont spécialisés dans les objets **riches en NBT**, **non empilables** ou **personnalisés** — pas dans le stockage de masse ordinaire.

---

### Objets acceptés

| Objet                               | Exemple                                  |
|-------------------------------------|------------------------------------------|
| <ItemImage id="minecraft:diamond_chestplate" /> | **Plastron en diamant** avec des enchantements |
| <ItemImage id="minecraft:enchanted_book" />     | **Livre enchanté** avec un enchantement   |
| <ItemImage id="minecraft:splash_potion" />      | **Potions** avec des effets                 |
| <ItemImage id="minecraft:netherite_pickaxe" />  | **Outils** avec de la durabilité                |

---

### Non acceptés

| Objet                             | Raison                         |
|-----------------------------------|--------------------------------|
| <ItemImage id="minecraft:cobblestone" /> | Pas de NBT, empilable              |
| <ItemImage id="minecraft:wheat" />       | Pas de NBT, empilable  |
| <ItemImage id="minecraft:oak_log" />     | Pas de NBT, empilable             |
| <ItemImage id="minecraft:apple" />       | Pas de NBT, empilable    |
| <ItemImage id="minecraft:iron_ingot" />  | Pas de NBT, empilable    |

---

