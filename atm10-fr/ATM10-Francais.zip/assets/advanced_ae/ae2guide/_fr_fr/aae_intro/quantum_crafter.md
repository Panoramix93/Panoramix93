---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Fabricateur quantique
  icon: advanced_ae:quantum_crafter
categories:
  - advanced devices
item_ids:
  - advanced_ae:quantum_crafter
---

# Fabricateur quantique

<BlockImage id="advanced_ae:quantum_crafter" p:working="true" scale="4"></BlockImage>

Le fabricateur quantique est un fabricateur automatique puissant et très configurable. Avec tout l'inventaire des systèmes
AE à sa disposition, fabriquer sans interruption devient trivial. Il peut exécuter des tâches de fabrication à un rythme
très rapide tout en garantissant que vous ne manquerez jamais de ressources essentielles. Il est également capable de gérer
les fabrications avec substitution de fluides ainsi que les fabrications récursives, dont une entrée est aussi une sortie.

## Utilisation du fabricateur

Pour utiliser le fabricateur quantique, vous devez le placer dans votre réseau et le raccorder avec un câble. Un seul canal
est nécessaire à son fonctionnement. Choisissez les recettes que vous voulez voir tourner indéfiniment et encodez-les dans un modèle de fabrication.
Ces modèles s'insèrent dans les emplacements prévus à cet effet dans le fabricateur.

![QCGUI](../pic/quantum_crafter_ui.png)

Une fois les modèles insérés, deux boutons permettent de configurer chacun d'eux. Le bouton carré, en bas, sert à
activer ou désactiver un modèle. Les modèles désactivés ne seront jamais fabriqués, mais les modèles activés restent soumis
à un ensemble de conditions. Pour définir ces conditions, cliquez sur le bouton en forme d'engrenage afin d'ouvrir l'interface de configuration du modèle.

![PCGUI](../pic/pattern_configuration_ui.png)

Dans l'interface de configuration du modèle, tous les ingrédients et la sortie principale sont listés. Les champs numériques vous permettent de
régler la quantité de chaque ingrédient que vous souhaitez conserver en permanence dans le système ME, ainsi que de définir une quantité maximale
de produit final, afin d'éviter de surproduire des objets coûteux. Après avoir saisi le nombre souhaité (les expressions 
mathématiques sont également acceptées), vous devez appuyer sur Entrée pour appliquer la valeur. Une indication sur la droite vous précise si
les valeurs ont été appliquées ou non. En particulier lors de la configuration de la limite de sortie, si la valeur est réglée sur 0, la limite est
supprimée et la fabrication continue jusqu'à épuisement des entrées.

## Sorties

Les sorties des fabrications effectuées par le fabricateur quantique sont très configurables. La configuration par défaut tente de
pousser les objets directement depuis les emplacements de sortie vers le système ME. En faisant un clic gauche sur le bouton de cellule dans la barre d'outils de gauche, la
sortie peut au contraire être poussée dans les inventaires adjacents. Cela se configure encore davantage en cliquant sur l'autre
bouton qui apparaît lorsque ce réglage est activé : il permet de choisir quelles faces sont considérées comme
actives pour l'exportation automatique. La combinaison de ces deux réglages devrait vous offrir beaucoup de contrôle et de liberté
dans la façon d'utiliser le fabricateur.

## Améliorations

Pour exploiter tout le potentiel du fabricateur quantique, vous devez installer des cartes d'amélioration. Il accepte des
<ItemLink id="ae2:speed_card" /> et des <ItemLink id="ae2:redstone_card" />. Les premières accélèrent fortement la vitesse de
fabrication, jusqu'à 64 fabrications par modèle et par tick, tandis que les secondes permettent un contrôle par redstone.
