---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Bus d'exportation de stock
  icon: advanced_ae:stock_export_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:stock_export_bus_part
---

# Bus d'exportation de stock

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_stock_export_bus.snbt"></ImportStructure>
</GameScene>

Le bus d'exportation de stock peut être configuré pour exporter une quantité exacte des piles filtrées. Il suit la quantité
actuellement présente dans l'inventaire de destination et n'insère pas au-delà de ce nombre. Pour le configurer, ouvrez son interface, glissez
l'objet souhaité dans l'emplacement de filtre et, avec un clic du milieu, vous pouvez régler la quantité. Notez qu'il ne
régulera pas la sortie : il n'extraira pas d'objets ou de fluides supplémentaires de l'inventaire si ceux-ci dépassent la quantité
configurée.