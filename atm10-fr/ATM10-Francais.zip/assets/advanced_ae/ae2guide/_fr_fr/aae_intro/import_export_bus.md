---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Bus d'importation/exportation
  icon: advanced_ae:import_export_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:import_export_bus_part
---

# Bus d'importation/exportation

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_import_export_bus.snbt"></ImportStructure>
</GameScene>

Le bus d'importation/exportation est un mélange d'<ItemLink id="ae2:import_bus" /> et d'<ItemLink id="ae2:export_bus" />. Le
filtre peut être réglé pour définir les lots exportés. Tout ce qui n'est pas dans le filtre est un lot valable à importer.