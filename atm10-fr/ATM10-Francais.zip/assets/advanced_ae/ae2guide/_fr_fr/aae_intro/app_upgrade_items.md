---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Objets d'amélioration du fournisseur de modèles avancé
  icon: advanced_ae:adv_pattern_provider_upgrade
categories:
  - advanced items
item_ids:
  - advanced_ae:adv_pattern_provider_upgrade
  - advanced_ae:adv_pattern_provider_capacity_upgrade
---

# Améliorations du fournisseur de modèles avancé

AdvancedAE propose des objets qui vous permettent d'améliorer vos fournisseurs de modèles sans avoir à déplacer tous vos modèles et
toutes vos améliorations.

## Amélioration de fournisseur de modèles avancé

<ItemImage id="advanced_ae:adv_pattern_provider_upgrade" scale="3"></ItemImage>

Ces améliorations s'utilisent sur les fournisseurs de modèles AE classiques et sur les fournisseurs de modèles étendus d'ExtendedAE. Les utiliser sur
ces machines les transforme en version avancée tout en conservant le même nombre d'emplacements qu'auparavant. Cela
signifie que vous ne perdez pas, au passage, les matériaux employés pour transformer un fournisseur classique en fournisseur étendu.

## Amélioration de capacité de fournisseur de modèles avancé

<ItemImage id="advanced_ae:adv_pattern_provider_capacity_upgrade" scale="3"></ItemImage>

Les améliorations de capacité servent à transformer directement un fournisseur de modèles classique en fournisseur de modèles avancé doté de 36 emplacements
de modèles.
