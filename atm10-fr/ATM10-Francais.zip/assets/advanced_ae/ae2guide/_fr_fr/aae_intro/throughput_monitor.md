---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Moniteur de débit ME
  icon: advanced_ae:throughput_monitor
categories:
  - advanced items
item_ids:
  - advanced_ae:throughput_monitor
  - advanced_ae:throughput_monitor_configurator
---

# Moniteur de débit ME

<GameScene zoom="8" background="transparent">
<ImportStructure src="../structure/throughput_monitors.snbt"></ImportStructure>
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Les moniteurs de débit sont une variante des moniteurs. Ils offrent les mêmes fonctionnalités qu'un <ItemLink id="ae2:storage_monitor" />,
avec en plus un indicateur de débit. Il suit un seul type d'objet ou de fluide et surveille les variations de sa
quantité, en affichant la quantité par seconde.

Il n'a *pas* besoin de canal.

## Commandes

*   Faites un clic droit avec un objet, ou un double clic droit avec un récipient à fluide, pour régler le moniteur sur cet objet ou ce fluide.
*   Faites un clic droit à main vide pour réinitialiser le moniteur.
*   Faites Maj + clic droit à main vide pour verrouiller le moniteur.

## Configurateur de moniteur de débit

<ItemImage id="advanced_ae:throughput_monitor_configurator" scale="4"></ItemImage>

Le configurateur de moniteur de débit est un outil qui permet de changer la donnée affichée. Un clic droit sur un moniteur
avec cet outil en main fait défiler trois options :

* Objets par tick
* Objets par seconde
* Objets par minute

Remarque : les relevés peuvent mettre un certain temps à se stabiliser après un changement de mode, ne vous fiez donc pas aux premières valeurs !
