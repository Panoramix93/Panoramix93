---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Encodeur de modèles avancé
  icon: advanced_ae:adv_pattern_encoder
categories:
  - advanced items
item_ids:
  - advanced_ae:adv_pattern_encoder
  - advanced_ae:adv_processing_pattern
---

# Encodeur de modèles avancé

Pour indiquer au Fournisseur de pattern ME avancé où envoyer vos objets, il faut un appareil spécial capable d'encoder cette
information. Vous pouvez faire un clic droit avec l'encodeur en main pour ouvrir son interface.

<ItemImage id="advanced_ae:adv_pattern_encoder" scale="4"></ItemImage>

Les modèles de traitement encodés peuvent être insérés dans l'emplacement de gauche : ils sont alors décodés et tous leurs ingrédients bruts
s'affichent sous forme de liste.

![PEGui1](../pic/ape_pattern.png)

Chaque ligne contient un ensemble de boutons représentant toutes les faces de bloc vers lesquelles l'ingrédient
peut être envoyé. Laisser la sélection sur le bouton « A » enverra l'ingrédient vers la face directement connectée au
Fournisseur de pattern ME, alors que choisir une face précise forcera l'insertion des objets de ce côté. Il est important de
noter que les modèles avancés ne peuvent être décodés correctement que par un <ItemLink id="advanced_ae:adv_pattern_provider" /> et qu'ils
se comporteront comme un modèle normal s'ils sont utilisés dans un autre type de Fournisseur de pattern ME.
De plus, si un seul objet ne peut pas être inséré dans la face indiquée, aucun objet ne sera inséré de façon directionnelle et
le comportement standard du Fournisseur de pattern ME s'appliquera.
