---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Ordinateur quantique
  icon: advanced_ae:quantum_core
categories:
  - advanced devices
item_ids:
  - advanced_ae:quantum_unit
  - advanced_ae:quantum_core
  - advanced_ae:quantum_structure
  - advanced_ae:quantum_accelerator
  - advanced_ae:quantum_multi_threader
  - advanced_ae:quantum_storage_128
  - advanced_ae:quantum_storage_256
  - advanced_ae:data_entangler
---

# Ordinateur quantique

L'ordinateur quantique est un type particulier d'ordinateur de fabrication. Il est capable d'exécuter un nombre illimité de demandes
de fabrication, du moment qu'il dispose de suffisamment de stockage de fabrication.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../structure/quantum_computer_multiblock.snbt"></ImportStructure>
</GameScene>

## Cœur quantique

<BlockImage id="advanced_ae:quantum_core" p:powered="true" p:formed="true" scale="4"></BlockImage>

Le cœur quantique est le cœur de l'ordinateur quantique. À lui seul, il dispose de 256M de stockage de fabrication et de 8 fils de coprocesseur.
C'est le seul bloc capable de former un ordinateur quantique à lui seul et d'en fournir tous les avantages. Toutefois, s'il est utilisé pour
construire un multibloc, on peut obtenir un ordinateur bien plus puissant. Utilisé comme ordinateur autonome, il doit être alimenté
par la face du dessus ou du dessous, là où se trouvent les connecteurs.

## Stockages quantiques

<Row gap="20">
<BlockImage id="advanced_ae:quantum_storage_128" scale="4"></BlockImage>
<BlockImage id="advanced_ae:quantum_storage_256" scale="4"></BlockImage>
</Row>

Ces blocs augmentent le stockage de fabrication du cœur quantique. Ils augmentent donc concrètement le nombre de tâches simultanées
que l'ordinateur quantique peut exécuter. Il en existe deux variantes, de 128M et de 256M de capacité.

## Intriqueur de données quantique

<BlockImage id="advanced_ae:data_entangler" scale="4"></BlockImage>

Les intriqueurs de données sont un bloc particulier qui agit sur tous les blocs de stockage présents dans le multibloc. Ils permettent aux blocs
de stockage de stocker des données dans plusieurs dimensions, ce qui multiplie leur capacité par 4. Un seul exemplaire peut être placé
dans chaque multibloc d'ordinateur quantique.

## Accélérateur quantique

<BlockImage id="advanced_ae:quantum_accelerator" scale="4"></BlockImage>

Les accélérateurs quantiques ajoutent 8 coprocesseurs au multibloc de l'ordinateur quantique. Il est important de noter que tous les patterns
de fabrication exécutés par l'ordinateur quantique peuvent se partager l'ensemble des coprocesseurs : c'est donc probablement une bonne idée
d'en installer un grand nombre.

## Multi-threader quantique

<BlockImage id="advanced_ae:quantum_multi_threader" scale="4"></BlockImage>

À l'image des intriqueurs de données, les multi-threaders permettent aux accélérateurs d'exécuter des fils supplémentaires dans des dimensions séparées,
ce qui multiplie leur puissance de coprocessing par 4. Un seul exemplaire peut être placé dans chaque multibloc d'ordinateur quantique.

## Structure quantique

<Row gap="20">
<BlockImage id="advanced_ae:quantum_structure" scale="4"></BlockImage>
<BlockImage id="advanced_ae:quantum_structure" p:formed="true" p:powered="true" scale="4"></BlockImage>
</Row>

Ces blocs forment l'ossature de l'ordinateur quantique. Ils servent de bloc de construction pour l'ordinateur quantique et
relient le tout entre eux.

## Le multibloc

Pour créer un ordinateur quantique multibloc, certaines règles doivent être respectées :
- La taille maximale est de 7x7x7 (dimensions extérieures) ;
- Aucun espace vide ne doit subsister à l'intérieur du multibloc. On peut les combler avec des <ItemLink id="advanced_ae:quantum_unit" />
sans bénéfice supplémentaire ;
- Exactement un <ItemLink id="advanced_ae:quantum_core" /> ;
- Au maximum un <ItemLink id="advanced_ae:data_entangler" /> ;
- Au maximum un <ItemLink id="advanced_ae:quantum_multi_threader" /> ;
- Tous les blocs de la couche extérieure doivent être des <ItemLink id="advanced_ae:quantum_structure" /> ;
- Aucun bloc de l'intérieur ne doit être un <ItemLink id="advanced_ae:quantum_structure" />.

## Configurations serveur

Plusieurs valeurs peuvent être ajustées dans la configuration du serveur, par exemple :
- La taille maximale du multibloc ;
- Le nombre de coprocesseurs de chaque accélérateur quantique ;
- Le nombre maximal de multi-threaders quantiques ;
- Le facteur de multiplication des fils du multi-threader ;
- Le nombre maximal d'intriqueurs de données ;
- Le facteur de multiplication du stockage de l'intriqueur de données ;

Les limites de votre instance peuvent être consultées dans les infobulles des objets.
