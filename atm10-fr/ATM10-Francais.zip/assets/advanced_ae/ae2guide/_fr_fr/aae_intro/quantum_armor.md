---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Panoplie d'armure quantique
  icon: advanced_ae:quantum_helmet
categories:
  - advanced items
item_ids:
  - advanced_ae:quantum_helmet
  - advanced_ae:quantum_chestplate
  - advanced_ae:quantum_leggings
  - advanced_ae:quantum_boots
  - advanced_ae:quantum_upgrade_base
  - advanced_ae:walk_speed_card
  - advanced_ae:sprint_speed_card
  - advanced_ae:step_assist_card
  - advanced_ae:jump_height_card
  - advanced_ae:lava_immunity_card
  - advanced_ae:flight_card
  - advanced_ae:water_breathing_card
  - advanced_ae:auto_feeding_card
  - advanced_ae:auto_stock_card
  - advanced_ae:magnet_card
  - advanced_ae:hp_buffer_card
  - advanced_ae:evasion_card
  - advanced_ae:regeneration_card
  - advanced_ae:strength_card
  - advanced_ae:attack_speed_card
  - advanced_ae:luck_card
  - advanced_ae:reach_card
  - advanced_ae:swim_speed_card
  - advanced_ae:night_vision_card
  - advanced_ae:flight_drift_card
  - advanced_ae:recharging_card
  - advanced_ae:portable_workbench_card
  - advanced_ae:pick_craft_card
---

# Panoplie d'armure quantique

<Row gap="10">
<ItemImage id="advanced_ae:quantum_helmet" components="ae2:stored_energy=2.0E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_chestplate" components="ae2:stored_energy=3.0E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_leggings" components="ae2:stored_energy=2.5E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_boots" components="ae2:stored_energy=2.0E8d" scale="4"></ItemImage>
</Row>

<ItemGrid>
<ItemIcon id="advanced_ae:quantum_helmet" components="ae2:stored_energy=2.0E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_chestplate" components="ae2:stored_energy=3.0E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_leggings" components="ae2:stored_energy=2.5E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_boots" components="ae2:stored_energy=2.0E8d"></ItemIcon>
</ItemGrid>

Vous vous êtes déjà demandé ce que ça donnerait de porter votre système AE sur vous ? Vous n'avez plus à vous le demander.
La panoplie d'armure quantique est un équipement discret et hautement technologique qui se connecte au système AE2 pour
vous donner un accès pratique à tout, où que vous soyez ! Par défaut, c'est une tenue alimentée en énergie dont les
défenses sont comparables à celles d'un équipement en Netherite. Elle peut utiliser sa réserve pour créer un bouclier
énergétique qui absorbe une bonne partie des dégâts. Les bottes annulent aussi les dégâts de chute, tandis que le
plastron supprime les pénalités de minage en vol. Mais la véritable puissance de cette tenue ne se révèle que lorsque
vous la remplissez d'améliorations !

<br/>

## Lier l'armure

Chaque pièce d'armure peut être liée individuellement au système en l'insérant dans les emplacements prévus d'un
<ItemLink id="ae2:wireless_access_point" />. Cela débloque différents avantages selon la pièce d'équipement et les cartes
d'amélioration installées. Nous y reviendrons plus loin. Notez que pour que ces fonctions supplémentaires fonctionnent
correctement, vous devez aussi être à portée du point d'accès connecté.

<br/>

## Installer des améliorations

Pour installer des améliorations, vous devez porter les pièces, puis ouvrir le menu de configuration de l'armure
quantique en appuyant sur le raccourci clavier (N par défaut).

![QAGUI](../pic/quantum_armor_config.png)

Sur cet écran, vous pouvez ajouter ou retirer des améliorations, les activer ou les désactiver, et régler les paramètres
des améliorations qui en possèdent.

<br/>

## Carte de base d'amélioration quantique

<ItemImage id="advanced_ae:quantum_upgrade_base" scale="2"></ItemImage>

La <ItemLink id="advanced_ae:quantum_upgrade_base" /> ne fait rien de particulier en soi, mais elle sert d'ingrédient de
fabrication pour toutes les cartes d'amélioration.

<br/>

## Carte d'alimentation automatique

<ItemImage id="advanced_ae:auto_feeding_card" scale="2"></ItemImage>

La <ItemLink id="advanced_ae:auto_feeding_card" /> permet de choisir des objets précis pour nourrir le joueur.
Glissez simplement les objets voulus dans les emplacements de filtre : si l'équipement est lié au réseau AE2, il
essaiera de les trouver dans le système pour nourrir le joueur quand il a faim.

<br/>

## Carte de stock automatique

<ItemImage id="advanced_ae:auto_stock_card" scale="2"></ItemImage>

La <ItemLink id="advanced_ae:auto_stock_card" /> exige également que la pièce d'équipement soit liée au système AE2 et
que vous soyez à bonne portée du point d'accès. Elle permet de configurer quelques piles d'objets à maintenir en
permanence en quantité définie dans l'inventaire de l'utilisateur. Les emplacements ne sont pas limités à une seule
pile : vous pouvez donc les régler pour garder plusieurs emplacements remplis en permanence dans l'inventaire si vous
le souhaitez.

<br/>

## Cartes de vitesse

<Row gap="10">
<ItemImage id="advanced_ae:walk_speed_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:sprint_speed_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:swim_speed_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:walk_speed_card" />
* <ItemLink id="advanced_ae:sprint_speed_card" />
* <ItemLink id="advanced_ae:swim_speed_card" />

Ces cartes d'amélioration augmentent la vitesse de déplacement du porteur de la panoplie. Elles ont toutes des valeurs
configurables pour choisir votre vitesse et affectent aussi les déplacements accroupi et en vol. Point important : ces
améliorations peuvent également servir à réduire la vitesse, pour garder plus de contrôle lorsque d'autres effets
d'accélération sont actifs.

<br/>

## Cartes de hauteur

<Row gap="10">
<ItemImage id="advanced_ae:jump_height_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:step_assist_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:jump_height_card" />
* <ItemLink id="advanced_ae:step_assist_card" />

Ces améliorations modifient les déplacements verticaux, en permettant de configurer la hauteur de saut ou l'assistance
au franchissement de marches.

<br/>

## Cartes de vol

<Row gap="10">
<ItemImage id="advanced_ae:flight_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:flight_drift_card" scale="2"></ItemImage>
</Row>

### Carte de vol

La <ItemLink id="advanced_ae:flight_card" /> active le vol créatif une fois installée. La vitesse de vol se règle à
l'aide du curseur dans l'interface. Elle est aussi affectée de façon additive par les cartes de vitesse de marche et de
course.

### Carte de dérive en vol

La <ItemLink id="advanced_ae:flight_drift_card" /> ne fonctionne que si la carte de vol est installée, et elle ajoute un
second curseur de configuration pour modifier l'inertie qui s'applique au vol créatif. Des valeurs plus faibles vous
font vous arrêter plus vite, l'arrêt étant instantané quand la valeur est réglée sur 0.

<br/>

## Carte de recharge ME

<ItemImage id="advanced_ae:recharging_card" scale="2"></ItemImage>

La <ItemLink id="advanced_ae:recharging_card" /> active la recharge sans fil de la pièce équipée. Cela nécessite un lien
avec le réseau et d'être à portée du point d'accès. Installer cette amélioration dans le plastron a l'avantage
supplémentaire de recharger aussi les emplacements de l'inventaire.

<br/>

## Carte d'établi portable

<ItemImage id="advanced_ae:portable_workbench_card" scale="2"></ItemImage>

La <ItemLink id="advanced_ae:portable_workbench_card" /> ajoute un établi de cellules portable à la tenue quantique.
Pour l'ouvrir, appuyez sur le raccourci clavier configuré. Il fonctionne exactement comme sa version en bloc.

<br/>

## Carte de fabrication ciblée

<ItemImage id="advanced_ae:pick_craft_card" scale="2"></ItemImage>

La <ItemLink id="advanced_ae:pick_craft_card" /> ajoute une nouvelle fonction accessible par raccourci clavier à
l'armure. L'activer tente de fabriquer le bloc actuellement visé par le joueur. Cette fonction nécessite un lien avec le
réseau ainsi qu'un modèle correspondant à la cible. Une fenêtre s'ouvre pour vous demander la quantité souhaitée, puis
le processus se déroule exactement comme une demande de fabrication automatique normale.

<br/>

## Cartes utilitaires

<Row gap="10">
<ItemImage id="advanced_ae:night_vision_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:lava_immunity_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:water_breathing_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:magnet_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:camo_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:night_vision_card" />
* <ItemLink id="advanced_ae:lava_immunity_card" />
* <ItemLink id="advanced_ae:water_breathing_card" />
* <ItemLink id="advanced_ae:magnet_card" />
* <ItemLink id="advanced_ae:camo_card" />

Ces cartes apportent plusieurs utilités au porteur de la panoplie : elles confèrent l'immunité à certains types de
dégâts et accordent la vision nocturne. La carte magnétique, en particulier, dispose d'un écran de configuration où vous
pouvez définir des filtres sur ce qu'il faut ramasser ou non, et régler sa portée.

<br/>

## Cartes défensives

<Row gap="10">
<ItemImage id="advanced_ae:hp_buffer_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:regeneration_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:evasion_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:hp_buffer_card" />
* <ItemLink id="advanced_ae:regeneration_card" />
* <ItemLink id="advanced_ae:evasion_card" />

Ces améliorations offrent divers bénéfices défensifs au porteur de la panoplie. La carte de points de vie augmente les
points de vie maximum, tandis que la carte de régénération accélère la vitesse à laquelle ils se rétablissent. La carte
d'esquive accorde, avec une certaine probabilité, une immunité totale à n'importe quelle source de dégâts.

<br/>

## Cartes offensives

<Row gap="10">
<ItemImage id="advanced_ae:strength_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:attack_speed_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:strength_card" />
* <ItemLink id="advanced_ae:attack_speed_card" />

Ces améliorations renforcent les capacités offensives du porteur. Elles accordent un bonus aux dégâts d'attaque et à la
vitesse d'attaque.

<br/>

## Cartes de statistiques

<Row gap="10">
<ItemImage id="advanced_ae:luck_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:reach_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:luck_card" />
* <ItemLink id="advanced_ae:reach_card" />

Ces cartes d'amélioration accordent des augmentations fixes de statistiques au porteur : elles jouent sur la chance,
pour de meilleurs tirages de butin, et sur la distance d'atteinte des blocs. La carte d'atteinte peut être réglée sur
une valeur précise.

<br/>

## À venir

Cet équipement a été publié comme une base, avec une tonne d'autres fonctionnalités prévues pour la suite : restez
connectés !
