---
navigation:
  title: Introduction à Advanced AE
  position: 70
---

# Advanced AE !

Advanced AE se concentre sur l'amélioration de l'expérience utilisateur dans la gestion de votre système ME et sur
l'élargissement des possibilités des systèmes de fin de partie. Ce mod vous permet d'améliorer les fournisseurs de
modèles pour qu'ils puissent pousser des objets vers des faces précises des machines ciblées, et de construire des
ordinateurs multiblocs capables d'exécuter un nombre illimité de fabrications en partageant les coprocesseurs, tant
qu'il reste du stockage de fabrication disponible, sans compter une tonne d'autres améliorations de confort !

![PEGui1](../pic/aae_intro.png)

Pour la liste complète des blocs et objets fournis, consultez ces pages du guide :

## Appareils avancés

<CategoryIndex category="advanced devices"></CategoryIndex>

## Objets avancés

<CategoryIndex category="advanced items"></CategoryIndex>

Vous avez trouvé un problème ? Une fonctionnalité manque ?
Merci de le signaler ici :
[GitHub d'Advanced AE](https://github.com/pedroksl/AdvancedAE)
