---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Chambre de réaction
  icon: advanced_ae:reaction_chamber
categories:
  - advanced devices
item_ids:
  - advanced_ae:reaction_chamber
---

# Chambre de réaction

<BlockImage id="advanced_ae:reaction_chamber" scale="4"></BlockImage>

La chambre de réaction est capable d'accélérer les réactions chimiques grâce à un fluide catalyseur et à une grande quantité
d'énergie. Ainsi, des réactions qui se produisent naturellement peuvent être forcées à l'intérieur de la chambre, la plupart du temps avec
des résultats plus efficaces, grâce à l'environnement contrôlé.

## Alimenter la chambre

La chambre de réaction peut être très gourmande en énergie lorsqu'elle est accélérée. Les cartes d'accélération augmentent la vitesse à laquelle le
coût total en énergie est consommé, ce qui augmente la puissance requise par tick. Lorsque l'énergie est tirée directement du système ME,
la chambre essaie de prélever la quantité nécessaire pour un tick de traitement et, si cela échoue, vous pouvez observer un
clignotement, l'alimentation du système s'allumant et s'éteignant. Pour corriger cet effet, le système AE doit être équipé
de tampons d'énergie sous la forme de <ItemLink id="ae2:dense_energy_cell" />. La chambre est aussi capable de tirer
l'énergie directement depuis des cellules énergétiques (d'Applied Flux) si elles sont présentes dans les range-disques, afin de se recharger et de fabriquer
sans consommer les tampons d'énergie ME. Réduire le nombre de cartes d'accélération est également une option s'il n'y a pas
plus de production d'énergie disponible pour le moment. Pour l'alimenter correctement, vous avez plusieurs possibilités.
* Remarque : les fournisseurs de pattern ou les interfaces en version élément (fixés à un câble) ne fournissent pas de connexion au réseau. Pour pouvoir
alimenter la chambre avec ceux-là, vous devrez aussi lui connecter directement un câble en Fluix.

### Fournisseur de pattern en bloc plein

Un fournisseur de pattern en bloc plein est capable de connecter la chambre de réaction directement au réseau AE2, ce qui permet d'en extraire l'énergie
au besoin et supprime la nécessité du tampon interne de la chambre. Si l'énergie totale stockée dans le réseau
est inférieure à la puissance requise par tick, la progression ralentira et un avertissement s'affichera à l'écran.
Pour cette méthode, il est recommandé que le réseau soit relié à quelques <ItemLink id="ae2:dense_energy_cell" />.

### Énergie externe

Une autre manière d'alimenter la chambre de réaction consiste à utiliser une source d'énergie externe. Toute source capable de pousser
de l'énergie devrait suffire à remplir ses tampons et à lancer le traitement. Si l'énergie fournie est reçue à un
débit insuffisant, un avertissement s'affichera sur l'écran de la chambre.

### Cartes d'induction (mod supplémentaire requis : Applied Flux)

Les cartes d'induction peuvent être insérées dans les fournisseurs de pattern en version élément de câble ou dans les fournisseurs de pattern directionnels, ce qui leur permet
d'exporter l'énergie stockée dans des cellules énergétiques. Si l'installation est correcte, cela devrait remplir le stockage d'énergie de la chambre
de réaction et lui permettre de fonctionner. Notez toutefois que les cartes d'induction, comme certains autres composants d'AE2, ont un
temps de montée en régime : elles commencent lentement et accélèrent avec le temps. La vitesse de fabrication ne sera donc pas maximale au début,
par manque d'énergie stockée, mais à mesure que la fabrication se poursuit, la carte d'induction devrait pouvoir fournir assez d'énergie.