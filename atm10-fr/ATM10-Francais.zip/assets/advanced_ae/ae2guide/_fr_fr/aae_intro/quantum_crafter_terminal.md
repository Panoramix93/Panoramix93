---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Terminaux de fabricateur quantique
  icon: advanced_ae:quantum_crafter_terminal
categories:
  - advanced devices
item_ids:
  - advanced_ae:quantum_crafter_terminal
  - advanced_ae:wireless_quantum_crafter_terminal
---

# Terminaux de fabricateur quantique

<Row gap="20">
<ItemImage id="advanced_ae:quantum_crafter_terminal" scale="4"></ItemImage>
<ItemImage id="advanced_ae:wireless_quantum_crafter_terminal" scale="4"></ItemImage>
</Row>

Les terminaux de fabricateur quantique permettent au joueur de gérer depuis un seul endroit l'ensemble de son réseau de <ItemLink id="advanced_ae:quantum_crafter"/>.
La version sans fil est pratique pour modifier les réglages en déplacement : il suffit de la lier à votre grille en l'insérant dans
votre point d'accès sans fil, et le tour est joué !

<Row gap="20">
<RecipeFor id="advanced_ae:quantum_crafter_terminal" />
<RecipeFor id="advanced_ae:wireless_quantum_crafter_terminal" />
</Row>
