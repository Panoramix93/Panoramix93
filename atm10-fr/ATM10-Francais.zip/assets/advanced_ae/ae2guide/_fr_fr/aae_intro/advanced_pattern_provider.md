---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Fournisseur de pattern avancé ME
  icon: advanced_ae:adv_pattern_provider
categories:
  - advanced devices
item_ids:
  - advanced_ae:adv_pattern_provider
  - advanced_ae:small_adv_pattern_provider
  - advanced_ae:adv_pattern_provider_part
  - advanced_ae:small_adv_pattern_provider_part
---

# Fournisseur de pattern avancé ME

<Row gap="20">
<BlockImage id="advanced_ae:adv_pattern_provider" scale="8"></BlockImage>
<BlockImage id="advanced_ae:adv_pattern_provider" p:push_direction="up" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_app_part.snbt"></ImportStructure>
</GameScene>
</Row>

Le Fournisseur de pattern avancé ME est un nouveau type de <ItemLink id="ae2:pattern_provider" /> qui améliore
la version standard ou l'<ItemLink id="extendedae:ex_pattern_provider" /> en permettant de configurer la face vers
laquelle chaque objet d'un pattern sera poussé. Ce formidable ajout permet d'automatiser avec un seul bloc et sans aucun tuyau
les machines qui exigent des faces précises pour des entrées précises !

*C'est à toi qu'on pense, Mekanism.*

Pour utiliser cette fonctionnalité, vous devez y insérer un <ItemLink id="advanced_ae:adv_processing_pattern" />, obtenu
en insérant un pattern encodé dans un <ItemLink id="advanced_ae:adv_pattern_encoder" /> et en ressortant la version
avancée.

Il existe également une version étendue, capable d'accueillir jusqu'à 36 patterns dans un seul fournisseur de pattern.

![AAEGui](../pic/app_gui.png)
