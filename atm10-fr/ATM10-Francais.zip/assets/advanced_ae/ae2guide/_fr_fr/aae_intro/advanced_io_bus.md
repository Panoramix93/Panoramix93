---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Bus d'E/S avancé
  icon: advanced_ae:advanced_io_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:advanced_io_bus_part
---

# Bus d'E/S avancé

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_advanced_io_bus.snbt"></ImportStructure>
</GameScene>

Le bus d'E/S avancé est un outil très puissant pour interagir avec les inventaires externes. Il s'obtient en fusionnant
un <ItemLink id="advanced_ae:import_export_bus_part"/> et un <ItemLink id="advanced_ae:stock_export_bus_part"/>. Il
hérite des fonctions de ses deux parents. De plus, la vitesse de base du bus d'E/S avancé est 8 fois supérieure à celle
d'un <ItemLink id="ae2:export_bus"/>. Il lui faut un peu de temps pour monter en régime, mais il devient
extrêmement rapide une fois pleinement amélioré.

## Exportation

Le bus d'E/S avancé exporte selon son filtre, jusqu'à une quantité fixe, puis s'arrête. Sur le côté gauche de
l'interface se trouve également un réglage qui permet à l'utilisateur de choisir de réguler le stock d'objets.

## Importation

Le bus d'E/S avancé importe également tout ce qui n'est pas filtré pour être exporté. Les opérations d'importation et
d'exportation sont comptées séparément, de sorte que le bus ne reste pas bloqué sur l'une ou l'autre. Lorsque le bus est
configuré en mode régulation, il donne la priorité à l'importation de tout ce qui dépasse la quantité définie. S'il
reste des opérations disponibles, il importe ce qui n'est pas filtré.

<RecipeFor id="advanced_ae:advanced_io_bus_part"/>
