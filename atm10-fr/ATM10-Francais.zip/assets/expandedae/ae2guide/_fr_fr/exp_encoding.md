---
navigation:
  parent: expandedae-index.md
  title: Terminal d'encodage étendu
  icon: exp_encoding_terminal
  position: 7
categories:
  - expandedae
item_ids:
- expandedae:exp_encoding_terminal
- expandedae:wireless_exp_encoding_terminal
---

<GameScene zoom="4" background="transparent">
  <ImportStructure src="structures/exp_encoding.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Le terminal d'encodage de modèles étendu est une amélioration du terminal d'origine, qui ajoute les fonctionnalités suivantes
 - Un Maj + clic lors de l'encodage d'un modèle le déplace dans votre inventaire
 - Des boutons de multiplication directement dans le terminal

![pattern_mult_screen.png](assets/pattern_mult_screen.png)
