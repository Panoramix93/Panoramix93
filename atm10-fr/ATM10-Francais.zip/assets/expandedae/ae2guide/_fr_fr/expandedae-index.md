---
navigation:
  title: "Add-on : ExpandedAE"
  position: 150
---

# AppliedE

<GameScene zoom="4" background="transparent">
  <ImportStructure src="structures/expandedae.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Un add-on pour 
[*Applied Energistics 2*](https://github.com/AppliedEnergistics/Applied-Energistics-2) qui étend encore le mod et ajoute des fonctionnalités de confort
issues d'anciennes versions d'AE2 qui vous manquent peut-être.
