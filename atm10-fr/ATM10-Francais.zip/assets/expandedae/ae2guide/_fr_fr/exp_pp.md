---
navigation:
  parent: expandedae-index.md
  title: Fournisseur de modèles étendu
  icon: exp_pattern_provider
  position: 0
categories:
  - expandedae
item_ids:
  - expandedae:exp_pattern_provider
  - expandedae:exp_pattern_provider_part
---

# Fournisseurs de modèles étendus

<GameScene zoom="4" background="transparent">
  <ImportStructure src="structures/exp_pp.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

### Le fournisseur de modèles étendu est un fournisseur de modèles plus grand, disponible en version bloc complet et en version élément,
### qui peut contenir jusqu'à 72 modèles.  
![exp_pp_screen.png](assets/exp_pp_screen.png)

## Toutes les recettes

<Row>
  <RecipesFor id="exp_pattern_provider" />
  <RecipesFor id="exp_pattern_provider_part" />
</Row>