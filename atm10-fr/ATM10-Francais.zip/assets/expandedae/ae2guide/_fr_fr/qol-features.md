---
navigation:
  parent: expandedae-index.md
  title: Fonctions de confort
  icon: expandedae:exp_pattern_provider
  position: 10
categories:
  - expandedae
---

# Le mod ajoute toutes les fonctions de confort listées ci-dessous
## Multiplication des modèles dans les Fournisseurs de pattern ME : ajoute au Fournisseur de pattern ME un bouton qui permet de multiplier ou de diviser tous les modèles qu'il contient 
__Les multiplicateurs se cumulent !__

![modify_patterns.png](assets/modify_patterns.png)
## Modes de blocage supplémentaires : ajoute deux modes de blocage supplémentaires à tous les Fournisseurs de pattern ME
### Par défaut : c'est le mode de blocage par défaut d'ae2. Il envoie le modèle si le stockage connecté ne contient aucune des entrées du modèle de ce Fournisseur de pattern ME ; si le stockage contient quelque chose qui n'est pas une entrée du modèle, le mode de blocage l'ignore et envoie quand même le modèle. 
    
![blocking_1.png](assets/blocking/blocking_1.png)

### Complet : ce mode de blocage n'envoie pas le modèle si le stockage connecté contient quoi que ce soit. 
    
![blocking_2.png](assets/blocking/blocking_2.png)

### Intelligent : permet au Fournisseur de pattern ME d'envoyer le même modèle si le stockage de destination ne contient que les entrées de ce modèle précis 

![blocking_3.png](assets/blocking/blocking_3.png)
