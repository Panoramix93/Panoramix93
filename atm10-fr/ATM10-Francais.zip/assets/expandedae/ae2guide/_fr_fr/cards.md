---
navigation:
  parent: expandedae-index.md
  title: Cartes d'amélioration
  icon: auto_complete_card
  position: 5
categories:
  - expandedae
item_ids:
- expandedae:auto_complete_card
- expandedae:pattern_refiller_card
---

## Pour l'instant, le mod n'ajoute que les deux cartes d'amélioration listées ci-dessous
- Carte de complétion automatique : cette carte est une amélioration pour les fournisseurs de modèles, elle annule automatiquement la fabrication dès
qu'elle a envoyé le modèle. _Note : ne fonctionne pas avec les modèles de fabrication, soyez donc prudent_ 
<ItemImage id="auto_complete_card" />
- Carte de recharge de modèles : cette carte est une amélioration pour le <ItemLink id="wireless_exp_encoding_terminal" /> 
et le <ItemLink id="ae2wtlib:wireless_universal_terminal" /> qui remplit automatiquement l'emplacement de modèle vierge du 
terminal d'encodage étendu 

_Note : la carte n'essaie de recharger les modèles qu'à chaque clic sur le bouton d'encodage ; c'était la solution la plus économe en ressources_
<ItemImage id="pattern_refiller_card" />