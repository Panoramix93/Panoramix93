---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Terminal universel sans fil
  icon: ae2wtlib:wireless_universal_terminal
  position: 20
categories:
- ae2wtlib
item_ids:
  - ae2wtlib:wireless_universal_terminal
---

# Terminal universel sans fil

<ItemImage id="ae2wtlib:wireless_universal_terminal" scale="3" />

Le <ItemLink id="ae2wtlib:wireless_universal_terminal" /> réunit plusieurs [terminaux sans fil](wireless_terminals.md) en un seul objet.

Tous les [terminaux sans fil d'AE2WTLib](wireless_terminals.md) peuvent être combinés en un seul terminal.

Le <ItemLink id="ae2:wireless_terminal" /> d'AE2, en revanche, ne peut ***PAS*** être combiné dans un <ItemLink id="ae2wtlib:wireless_universal_terminal" />.


## L'interface

Le <ItemLink id="ae2wtlib:wireless_universal_terminal" /> ajoute un bouton à l'interface du terminal :
un clic gauche (ou un clic droit) permet de passer au [terminal sans fil](wireless_terminals.md) suivant (ou précédent).


## Améliorations

Le <ItemLink id="ae2wtlib:wireless_universal_terminal" /> accepte les mêmes améliorations que les [terminaux sans fil](wireless_terminals.md) installés.
Chaque terminal installé ajoute 2 emplacements d'amélioration.

## Stockage d'énergie

L'ajout de terminaux cumule leur stockage d'énergie :
un <ItemLink id="ae2wtlib:wireless_universal_terminal" /> contenant deux terminaux dispose donc de deux fois le stockage d'énergie d'un [terminal sans fil](wireless_terminals.md).
