---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Terminaux sans fil AE2WTLib
  icon: ae2wtlib:wireless_universal_terminal
  position: 10
categories:
- ae2wtlib
item_ids:
  - ae2wtlib:wireless_pattern_encoding_terminal
  - ae2wtlib:wireless_pattern_access_terminal
---

# Terminaux sans fil

<ItemGrid>
  <ItemIcon id="ae2wtlib:wireless_universal_terminal" />
  <ItemIcon id="ae2:wireless_crafting_terminal" />
  <ItemIcon id="ae2wtlib:wireless_pattern_encoding_terminal" />
  <ItemIcon id="ae2wtlib:wireless_pattern_access_terminal" />
</ItemGrid>

En plus de la <ItemLink id="ae2:energy_card" />, tous les terminaux sans fil d'AE2WTLib peuvent être améliorés avec la <ItemLink id="ae2wtlib:quantum_bridge_card" />
et combinés en un <ItemLink id="ae2wtlib:wireless_universal_terminal" />.

Comme le <ItemLink id="ae2:wireless_terminal" /> d'AE2, il est accessible via un raccourci clavier et peut être placé dans un emplacement de curio
(si un mod implémentant l'API curio est installé).

Les terminaux sans fil peuvent aussi être associés comme un <ItemLink id="ae2:wireless_terminal" /> normal, à l'aide d'un <ItemLink id="ae2:wireless_access_point" />

## Terminal universel sans fil

<ItemImage id="ae2wtlib:wireless_universal_terminal" scale="3" />

Le <ItemLink id="ae2wtlib:wireless_universal_terminal" /> réunit plusieurs terminaux sans fil en un seul objet.

## Terminal de fabrication sans fil

<ItemImage id="ae2:wireless_crafting_terminal" scale="3" />

Le <ItemLink id="ae2:wireless_crafting_terminal" /> est une version sans fil du terminal de fabrication.
Il offre quelques [fonctionnalités supplémentaires](wireless_crafting_terminal.md) par rapport à AE2 de base.

## Terminal d'encodage de modèles sans fil

<ItemImage id="ae2wtlib:wireless_pattern_encoding_terminal" scale="3" />

Une version sans fil du <ItemLink id="ae2:pattern_encoding_terminal" />

<RecipeFor id="ae2wtlib:wireless_pattern_encoding_terminal" />

## Terminal d'accès aux modèles sans fil

<ItemImage id="ae2wtlib:wireless_pattern_access_terminal" scale="3" />

Une version sans fil du <ItemLink id="ae2:pattern_access_terminal" />

<RecipeFor id="ae2wtlib:wireless_pattern_access_terminal" />

## Terminaux des add-ons

La plupart des terminaux sans fil d'autres add-ons fonctionnent également avec le <ItemLink id="ae2wtlib:wireless_universal_terminal" />.

## Terminaux qui ne fonctionnent pas dans le terminal universel

Le <ItemLink id="ae2:wireless_terminal" /> ne peut pas être utilisé dans le <ItemLink id="ae2wtlib:wireless_universal_terminal" />,
car il n'apporterait aucun avantage par rapport à un <ItemLink id="ae2:wireless_crafting_terminal" />.
Il ne peut pas non plus utiliser la <ItemLink id="ae2wtlib:quantum_bridge_card" />
