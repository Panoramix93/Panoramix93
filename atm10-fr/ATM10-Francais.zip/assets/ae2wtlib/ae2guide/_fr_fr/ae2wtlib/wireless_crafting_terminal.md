---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Terminal de fabrication sans fil
  icon: ae2:wireless_crafting_terminal
  position: 100
categories:
- ae2wtlib
item_ids:
  - ae2:wireless_crafting_terminal
---

# Terminal de fabrication sans fil

<ItemImage id="ae2:wireless_crafting_terminal" scale="3" />

Le <ItemLink id="ae2:wireless_crafting_terminal" /> est une version [sans fil](wireless_terminals.md) du <ItemLink id="ae2:crafting_terminal" />.
AE2WTLib ajoute un [réapprovisionnement](restock.md) automatique depuis le réseau ME, et permet à « sélectionner le bloc » de puiser des objets dans le réseau ME.   
Avec une <ItemLink id="ae2wtlib:magnet_card" />, il fait également office d'aimant.

Il peut être combiné avec d'autres [terminaux sans fil](wireless_terminals.md) pour former un <ItemLink id="ae2wtlib:wireless_universal_terminal" />

AE2WTLib améliore la fonction `Pick Block` de Minecraft : elle puise les objets dans le réseau s'ils ne sont pas trouvés dans votre inventaire.
(Elle essaie aussi de stocker les objets si l'emplacement sélectionné se trouve être plein)

## L'interface

Voir [Terminaux](ae2:items-blocks-machines/terminals.md)

## Améliorations

Le <ItemLink id="ae2:wireless_crafting_terminal" /> accepte les [améliorations](ae2:items-blocks-machines/upgrade_cards.md) suivantes :

*   <ItemLink id="ae2:energy_card" /> pour augmenter la capacité de la batterie
*   <ItemLink id="ae2wtlib:quantum_bridge_card" /> qui donne au terminal une portée illimitée, y compris à travers les dimensions, et le recharge automatiquement depuis le réseau ME 
*   <ItemLink id="ae2wtlib:magnet_card" /> pour ajouter la fonction d'aimant

## Recette

<RecipeFor id="ae2:wireless_crafting_terminal" />
