---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Réapprovisionnement
  position: 110
categories:
- ae2wtlib
---

# Réapprovisionnement

Si le réapprovisionnement est activé, votre <ItemLink id="ae2:wireless_crafting_terminal" /> tentera de remplacer les objets que vous utilisez par des objets pris dans le système ME.

Vous pouvez l'activer dans l'interface, ou à l'aide d'un raccourci clavier.

Lorsqu'il est activé, il tente de maintenir la pile que vous utilisez à sa taille maximale, soit 64 pour la plupart des objets.
Il prendra les objets manquants dans votre système ME,
ou y rangera les objets en excès si vous en ramassez davantage.
Cela signifie que si vous posez quelques objets puis les cassez à nouveau, l'objet ne débordera pas dans une autre case,
même si vous n'avez pas de <ItemLink id="ae2wtlib:magnet_card" /> active.

Il ne réapprovisionnera **PAS** les piles qui ne contenaient qu'un seul objet avant utilisation.

Il modifie aussi le nombre d'objets affiché dans votre barre d'action,
pour indiquer la quantité présente sur le réseau (+ les objets réellement présents dans votre barre d'action).

Cela ne fonctionne que tant que vous êtes à portée d'un point d'accès,
ou si votre terminal est [relié par lien quantique](quantum_bridge_card.md).

En mode créatif, cette fonction est automatiquement désactivée, puisque vous n'épuisez de toute façon pas vos objets.

Le réapprovisionnement fonctionne pour la plupart des actions comme poser des blocs, manger ou tirer à l'arc,
mais d'autres actions (surtout celles venant d'autres mods) peuvent ne pas être reconnues, et les objets utilisés ne seront alors pas réapprovisionnés.
