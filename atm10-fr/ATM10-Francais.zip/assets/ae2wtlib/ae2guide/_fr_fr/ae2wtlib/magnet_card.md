---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Carte magnétique
  icon: ae2wtlib:magnet_card
  position: 220
categories:
- ae2wtlib
item_ids:
- ae2wtlib:magnet_card
---

# Carte magnétique

<ItemImage id="ae2wtlib:magnet_card" scale="3" />

La <ItemLink id="ae2wtlib:magnet_card" /> est une [carte d'amélioration](ae2:items-blocks-machines/upgrade_cards.md) pour le <ItemLink id="ae2:wireless_crafting_terminal" />.
Elle ajoute un aimant au <ItemLink id="ae2:wireless_crafting_terminal" />, que l'on peut activer ou filtrer depuis l'interface.
Un raccourci clavier permet aussi de l'activer ou de le désactiver.

La <ItemLink id="ae2wtlib:magnet_card" /> fait deux choses :

1. Ramasser les objets dans un rayon plus large (configurable, 16 par défaut)
2. Envoyer les objets ramassés dans le système ME au lieu de votre inventaire

Les deux fonctions s'activent séparément et se filtrent séparément (filtre de ramassage et filtre d'insertion).
Chacun des deux filtres peut être réglé en mode liste noire ou liste blanche.

## Recette

<RecipeFor id="ae2wtlib:magnet_card" />
