---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Carte de pont quantique
  icon: ae2wtlib:quantum_bridge_card
  position: 210
categories:
- ae2wtlib
item_ids:
- ae2wtlib:quantum_bridge_card
---

# Carte de pont quantique

<ItemImage id="ae2wtlib:quantum_bridge_card" scale="3" />

La carte de pont quantique est une [carte d'amélioration](ae2:items-blocks-machines/upgrade_cards.md) destinée aux [terminaux sans fil AE2wtlib](wireless_terminals.md).
Elle permet de lier vos [terminaux sans fil](wireless_terminals.md) à un [pont quantique](ae2:items-blocks-machines/quantum_bridge.md).

Placez une carte de pont quantique et une <ItemLink id="ae2:quantum_entangled_singularity" /> dans votre terminal sans fil,
puis placez l'autre singularité dans un [pont quantique](ae2:items-blocks-machines/quantum_bridge.md) connecté à votre réseau.

Votre terminal sans fil est désormais lié quantiquement, peut accéder à votre réseau depuis n'importe où, même à travers les dimensions (à condition que les chunks contenant le réseau soient chargés, par exemple avec une <ItemLink id="ae2:spatial_anchor" />),
et se rechargera automatiquement avec l'énergie de votre réseau.
(assurez-vous que votre réseau dispose d'assez de [stockage d'énergie](ae2:items-blocks-machines/energy_cells.md))

## Recette

<RecipeFor id="ae2wtlib:quantum_bridge_card" />
