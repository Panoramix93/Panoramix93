---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Cristal d'Entro
    icon: extendedae:entro_crystal
categories:
- entro system
item_ids:
- extendedae:entro_crystal
---

# Le cristal d'Entro

<Row>
<ItemImage id="extendedae:entro_crystal" scale="4"></ItemImage>
</Row>

*« Les cristaux d'Entro manifestent une affinité dimensionnelle extrêmement forte après injection de poussière d'Ender
dans des cristaux de Fluix, et peuvent entrer en résonance à travers l'espace-temps. »*

C'est le principal ingrédient de fabrication de la plupart des objets et machines d'ExtendedAE. Vous devez utiliser une
<ItemLink id="extendedae:entro_seed" /> pour transformer un <ItemLink id="ae2:fluix_block" /> en
[Fluix bourgeonnant entroïsé](./entro_budding.md), puis récolter les grappes d'Entro pour obtenir des cristaux d'Entro.
