---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Bus d'exportation précis ME
    icon: extendedae:precise_export_bus
categories:
- extended devices
item_ids:
- extendedae:precise_export_bus
---

# Bus d'exportation précis ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_precise_export_bus.snbt"></ImportStructure>
</GameScene>

Le Bus d'exportation précis ME exporte des objets ou des fluides en quantités déterminées. Il n'exporte que si le conteneur peut accepter la totalité de la sortie.

## Exemple

![Interface](../pic/pre_bus_gui1.png)

Ici, 3 pierres taillées sont exportées par opération. L'exportation s'arrête dès que la quantité de pierre taillée présente dans le réseau est inférieure à 3.

![Interface](../pic/pre_bus_gui2.png)

L'exportation s'arrête également lorsque le conteneur cible ne peut pas accueillir la totalité de la sortie. Le coffre ne peut plus accueillir que 2 pierres taillées, le bus d'exportation s'arrête donc.
