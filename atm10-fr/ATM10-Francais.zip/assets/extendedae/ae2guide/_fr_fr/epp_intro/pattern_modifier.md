---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Modificateur de modèles
    icon: extendedae:pattern_modifier
categories:
- extended items
item_ids:
- extendedae:pattern_modifier
---

# Modificateur de modèles

Le Modificateur de modèles est un outil permettant de modifier des modèles en masse.

<ItemImage id="extendedae:pattern_modifier" scale="4"></ItemImage>

Faites un clic droit dessus pour ouvrir son interface.

## Mode Multiplication

Vous pouvez multiplier ou diviser les quantités d'entrée et de sortie d'un modèle de traitement par un facteur x en cliquant sur le bouton correspondant.

![PM](../pic/pm.png)

Modèle d'origine :

![PM1](../pic/pm1.png)

Après ×10 :

![PM2](../pic/pm2.png)

Il peut aussi effacer le contenu de tous les modèles et les transformer en modèles vierges, en cliquant sur le bouton Effacer.

### Remarques

 - Le bouton de division ne fonctionne que si la quantité concernée est divisible sans reste. Par exemple, le bouton ÷2 ne fonctionnera pas si un modèle demande 3
 pierres taillées en entrée, car 3 ÷ 2 fait 1,5.

 - Le bouton de multiplication est plafonné à 999999. Il ne peut pas augmenter la quantité d'un ingrédient au-delà de ce nombre.

## Mode Remplacement

Remplacez un ingrédient d'entrée ou de sortie précis d'un modèle par un autre objet.

![PM3](../pic/pm4.png)

L'emplacement A correspond à l'objet à remplacer, et l'emplacement B à l'objet de remplacement.

Par exemple, le réglage suivant remplacera les planches par du charbon.

![PM4](../pic/pm6.png)

![PM5](../pic/pm5.png)

Cliquez sur le bouton Remplacer pour effectuer le remplacement.

![PM6](../pic/pm7.png)

## Mode Propriétés

Modifiez les modes Substitutions et Substitutions de fluides d'un modèle de fabrication.

![PM8](../pic/pm8.png)

## Mode Copie

Ce mode vous permet de faire une copie de n'importe quel modèle.

![PM7](../pic/pm3.png)


