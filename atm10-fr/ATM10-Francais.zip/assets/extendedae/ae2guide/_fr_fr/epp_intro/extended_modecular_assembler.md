---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Assembleur moléculaire étendu
    icon: extendedae:ex_molecular_assembler
categories:
- extended devices
item_ids:
- extendedae:ex_molecular_assembler
---

# Assembleur moléculaire étendu

<Row gap="20">
<BlockImage id="extendedae:ex_molecular_assembler" scale="8"></BlockImage>
</Row>

L'Assembleur moléculaire étendu est une version avancée de l'<ItemLink id="ae2:molecular_assembler" />.

Il peut exécuter huit tâches de fabrication en parallèle (à condition que votre réseau ME dispose de <ItemLink id="ae2:crafting_accelerator" />)
et travaille deux fois plus vite que la version normale.

En revanche, il ne prend en charge que les tâches de fabrication provenant d'un <ItemLink id="ae2:pattern_provider" />. Vous ne pouvez donc pas y placer un modèle directement.
