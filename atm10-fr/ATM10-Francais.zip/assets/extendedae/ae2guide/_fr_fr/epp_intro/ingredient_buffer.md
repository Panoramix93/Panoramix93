---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Tampon d'ingrédients ME
    icon: extendedae:ingredient_buffer
categories:
- extended devices
item_ids:
- extendedae:ingredient_buffer
---

# Tampon d'ingrédients ME

<BlockImage id="extendedae:ingredient_buffer" scale="8"></BlockImage>

Un bloc de stockage capable de contenir 36 types de contenus différents, des objets comme des fluides.
