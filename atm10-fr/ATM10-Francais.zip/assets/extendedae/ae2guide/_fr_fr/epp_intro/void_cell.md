---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Cellule du vide ME
    icon: extendedae:void_cell
categories:
- extended items
item_ids:
- extendedae:void_cell
---

# Cellule du vide ME

Un condenseur de poche à utiliser dans un range-disque.

<ItemImage id="extendedae:void_cell" scale="4"></ItemImage>

La Cellule du vide doit être partitionnée dans un <ItemLink id="ae2:cell_workbench" /> avant utilisation. Elle supprime tout ce qui
correspond à son filtre, ou condense les objets correspondants en <ItemLink id="ae2:matter_ball" /> ou en <ItemLink id="ae2:singularity" /> comme le <ItemLink id="ae2:condenser" />.

Faites un clic droit pour ouvrir l'interface de configuration.

![Interface](../pic/void_cell.png)
