---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Bus d'exportation/importation étendu ME
    icon: extendedae:ex_import_bus_part
categories:
- extended devices
item_ids:
- extendedae:ex_import_bus_part
- extendedae:ex_export_bus_part
---

# Bus d'importation/exportation étendu ME

<Row gap="20">
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_import_bus.snbt"></ImportStructure>
</GameScene>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_export_bus.snbt"></ImportStructure>
</GameScene>
</Row>

Les Bus d'importation/exportation étendus ME fonctionnent plus vite que les <ItemLink id="ae2:import_bus" /> et <ItemLink id="ae2:export_bus" /> normaux
(le multiplicateur de vitesse par défaut est de 8 ; il est configurable).

Ils disposent également de plus d'emplacements d'amélioration que les versions normales.
