---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Matrice d'assemblage
    icon: extendedae:assembler_matrix_frame
categories:
- extended devices
item_ids:
- extendedae:assembler_matrix_frame
- extendedae:assembler_matrix_wall
- extendedae:assembler_matrix_glass
- extendedae:assembler_matrix_pattern
- extendedae:assembler_matrix_crafter
- extendedae:assembler_matrix_speed
---

# Matrice d'assemblage

<Row>
<BlockImage id="extendedae:assembler_matrix_frame" p:formed="true" p:powered="true" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_wall" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_glass" scale="5"></BlockImage>
</Row>
<Row>
<BlockImage id="extendedae:assembler_matrix_pattern" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_crafter" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_speed" scale="5"></BlockImage>
</Row>

La matrice d'assemblage est une structure multibloc. Elle combine l'<ItemLink id="ae2:molecular_assembler" /> et le <ItemLink id="ae2:pattern_provider" />.
Elle peut exécuter de nombreuses tâches de fabrication en parallèle (si votre réseau ME contient assez d'<ItemLink id="ae2:crafting_accelerator" />) et vous fait économiser des canaux.

## Structure

<GameScene zoom="3" background="transparent" interactive={true}>
  <ImportStructure src="../structure/assembler_matrix.snbt"></ImportStructure>
</GameScene>

C'est un pavé droit dont les arêtes mesurent entre 3 et 7 blocs.
- Les arêtes sont constituées de cadres de matrice d'assemblage.
- Les faces sont constituées de murs ou de vitres de matrice d'assemblage.
- L'intérieur est constitué de cœurs de modèles, de fabrication ou de vitesse de matrice d'assemblage.

Une matrice d'assemblage valide doit contenir au moins un cœur de modèles et un cœur de fabrication.
Elle doit être entièrement remplie et ne peut pas être creuse.
Lorsque la matrice d'assemblage est correctement formée et alimentée, les lignes des cadres de matrice d'assemblage deviennent bleues.

## Les cœurs de matrice d'assemblage

Il existe 3 cœurs de matrice d'assemblage différents.

- Le cœur de modèles de matrice d'assemblage

La matrice d'assemblage ne prend ses modèles que dans ses cœurs de modèles. Chaque cœur de modèles fournit 36 emplacements de modèles à la matrice d'assemblage.

- Le cœur de fabrication de matrice d'assemblage

La matrice d'assemblage répartit les tâches de fabrication reçues entre ses cœurs de fabrication. Chaque cœur de fabrication peut exécuter 8 tâches de fabrication en parallèle.

- Le cœur de vitesse de matrice d'assemblage

C'est l'équivalent de la <ItemLink id="ae2:speed_card" /> pour la matrice d'assemblage. 5 cœurs de vitesse permettent à la matrice d'assemblage de tourner à pleine vitesse.
Installer plus de 5 cœurs de vitesse n'apporte aucun gain supplémentaire.

## Interface

Un clic droit sur une matrice d'assemblage formée et en ligne ouvre son interface.

![Interface](../pic/assembler_matrix.png)

Vous pouvez y ajouter ou y rechercher des modèles, et voir combien de tâches de fabrication elle exécute.
