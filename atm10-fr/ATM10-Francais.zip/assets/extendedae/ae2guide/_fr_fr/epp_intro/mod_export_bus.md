---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Bus d'exportation ME par mod
    icon: extendedae:mod_export_bus
categories:
- extended devices
item_ids:
- extendedae:mod_export_bus
---

# Bus d'exportation ME par mod

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_mod_export_bus.snbt"></ImportStructure>
</GameScene>

Le Bus d'exportation ME par mod est un <ItemLink id="ae2:export_bus" /> qui peut être filtré par nom de mod ou par identifiant de mod.

Séparez les identifiants de mods par des virgules lorsque vous voulez filtrer plusieurs mods.

![PIC](../pic/mod_bus_name2.png)
