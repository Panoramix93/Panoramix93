---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Bus de stockage ME par tag
    icon: extendedae:tag_storage_bus
categories:
- extended devices
item_ids:
- extendedae:tag_storage_bus
---

# Bus de stockage ME par tag

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_tag_storage_bus.snbt"></ImportStructure>
</GameScene>

Le bus de stockage ME par tag est un <ItemLink id="ae2:storage_bus" /> que l'on peut filtrer par tags d'objets ou de fluides et qui prend en charge quelques opérateurs logiques de base.

Voici quelques exemples :

- N'accepter que les minerais bruts

c:raw_materials/*

- Accepter tous les lingots et toutes les gemmes

c:ingots/* | c:gems/*

