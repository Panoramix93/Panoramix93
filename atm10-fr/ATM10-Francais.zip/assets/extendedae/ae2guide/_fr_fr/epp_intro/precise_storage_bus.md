---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Bus de stockage ME précis
    icon: extendedae:precise_storage_bus
categories:
- extended devices
item_ids:
- extendedae:precise_storage_bus
---

# Bus de stockage ME précis

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_precise_storage_bus.snbt"></ImportStructure>
</GameScene>

Le bus de stockage ME précis est un <ItemLink id="ae2:storage_bus" /> auquel on peut fixer une limite numérique : il n'insère des objets que jusqu'à cette limite.

![Interface](../pic/pre_storage_bus.png)
