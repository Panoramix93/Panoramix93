---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Interface surdimensionnée ME
    icon: extendedae:oversize_interface
categories:
- extended devices
item_ids:
- extendedae:oversize_interface
- extendedae:oversize_interface_part
---

# Interface surdimensionnée ME

<Row gap="20">
<BlockImage id="extendedae:oversize_interface" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_oversize_interface.snbt"></ImportStructure>
</GameScene>
</Row>

L'interface surdimensionnée ME possède le même nombre d'emplacements que l'<ItemLink id="extendedae:ex_interface" />, mais elle peut contenir 16 fois plus
d'objets par emplacement (configurable). Elle peut donc contenir 1024 objets (64 × 16) par emplacement.

Certains objets d'autres mods peuvent se voir attribuer un multiplicateur spécifique dans la configuration.
