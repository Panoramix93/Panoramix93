---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Port d'E/S étendu ME
    icon: extendedae:ex_io_port
categories:
- extended devices
item_ids:
- extendedae:ex_io_port
---

# Port d'E/S étendu ME

<Row gap="20">
<BlockImage id="extendedae:ex_io_port" p:powered="true" scale="8"></BlockImage>
</Row>

Le port d'E/S étendu ME fonctionne huit fois plus vite que le <ItemLink id="ae2:io_port" /> normal.

Il possède également plus d'emplacements d'amélioration que la version normale.
