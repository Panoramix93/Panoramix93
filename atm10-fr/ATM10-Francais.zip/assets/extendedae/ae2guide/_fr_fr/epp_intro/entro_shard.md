---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Éclat d'Entro
    icon: extendedae:entro_shard
categories:
- entro system
item_ids:
- extendedae:entro_shard
---

# Éclat d'Entro

<Row>
<ItemImage id="extendedae:entro_shard" scale="4"></ItemImage>
</Row>

Vous obtenez un Éclat d'Entro si vous cassez un [Bourgeon d'Entro](./entro_budding.md) avant qu'il n'ait fini de pousser. Huit Éclats d'Entro peuvent être retransformés en
<ItemLink id="extendedae:entro_crystal" /> par fabrication.
