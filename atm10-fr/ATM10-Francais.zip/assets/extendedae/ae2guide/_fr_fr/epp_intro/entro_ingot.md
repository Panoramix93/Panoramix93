---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Lingot d'Entro
    icon: extendedae:entro_ingot
categories:
- entro system
item_ids:
- extendedae:entro_ingot
---

# Lingot d'Entro

<Row>
<ItemImage id="extendedae:entro_ingot" scale="4"></ItemImage>
</Row>

*« Le cristal d'Entro est trop friable pour être utilisé dans un châssis de machine, mais nous pouvons le fusionner avec un lingot d'or pour améliorer sa ductilité. »*

Il sert à fabriquer le <ItemLink id="extendedae:machine_frame" /> et quelques autres objets d'ExtendedAE.
