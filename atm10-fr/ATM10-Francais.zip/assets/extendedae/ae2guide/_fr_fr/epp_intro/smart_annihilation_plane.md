---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Plan d'annihilation ME intelligent
    icon: extendedae:smart_annihilation_plane
categories:
- extended devices
item_ids:
- extendedae:smart_annihilation_plane
---

# Plan d'annihilation ME intelligent

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_smart_annihilation_plane.snbt"></ImportStructure>
</GameScene>

Le plan d'annihilation ME intelligent est un <ItemLink id="ae2:annihilation_plane" /> capable de casser des blocs ou d'absorber des objets selon son inventaire de configuration.

Vous n'avez pas besoin de lui monter un sous-réseau. Il fonctionne comme un <ItemLink id="ae2:import_bus" />, mais il casse des blocs au lieu de
les importer depuis un coffre.
