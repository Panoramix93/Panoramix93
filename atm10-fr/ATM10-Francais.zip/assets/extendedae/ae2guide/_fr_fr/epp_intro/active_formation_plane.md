---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Plan de formation ME actif
    icon: extendedae:active_formation_plane
categories:
- extended devices
item_ids:
- extendedae:active_formation_plane
---

# Plan de formation ME actif

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_active_formation_plane.snbt"></ImportStructure>
</GameScene>

Le plan de formation ME actif est un <ItemLink id="ae2:formation_plane" /> capable de placer activement des blocs ou de faire tomber des objets.

Vous n'avez pas besoin de mettre en place un sous-réseau pour lui. Il fonctionne comme un <ItemLink id="ae2:export_bus" />, mais place les blocs au lieu de
les déposer dans un coffre.
