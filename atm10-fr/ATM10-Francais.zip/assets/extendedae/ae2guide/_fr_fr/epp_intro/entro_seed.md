---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Graine d'Entro
    icon: extendedae:entro_seed
categories:
- entro system
item_ids:
- extendedae:entro_seed
---

# Graine d'Entro

<Row>
<ItemImage id="extendedae:entro_seed" scale="4"></ItemImage>
</Row>

Ces graines contiennent une forte énergie Entro. Faites un clic droit sur un <ItemLink id="ae2:fluix_block" /> avec une graine d'Entro pour le transformer en [fluix bourgeonnant entroïsé](./entro_budding.md).
Vous pouvez aussi utiliser un <ItemLink id="extendedae:crystal_assembler" /> pour injecter la graine, mais il produit un [fluix bourgeonnant entroïsé](./entro_budding.md) de moindre qualité que
la méthode manuelle.
