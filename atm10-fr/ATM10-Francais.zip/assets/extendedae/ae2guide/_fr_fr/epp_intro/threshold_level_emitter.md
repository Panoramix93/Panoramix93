---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Émetteur de niveau à seuils ME
    icon: extendedae:threshold_level_emitter
categories:
- extended devices
item_ids:
- extendedae:threshold_level_emitter
---

# Émetteur de niveau à seuils ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_threshold_level_emitter.snbt"></ImportStructure>
</GameScene>

Il fonctionne comme une bascule RS. Il coupe le signal de redstone lorsque la quantité d'un objet dans le réseau est inférieure
au seuil bas, et l'active lorsque la quantité dépasse le seuil haut.

Par exemple, supposons que le seuil bas soit réglé sur 100 et le seuil haut sur 150.

Au départ, le réseau est vide : l'émetteur est donc inactif.

Lorsque la quantité de l'objet dépasse 150, l'émetteur envoie un signal de redstone.

Lorsque la quantité redescend sous 150, l'émetteur continue d'envoyer un signal.

Enfin, lorsque la quantité passe sous 100, l'émetteur s'éteint.
