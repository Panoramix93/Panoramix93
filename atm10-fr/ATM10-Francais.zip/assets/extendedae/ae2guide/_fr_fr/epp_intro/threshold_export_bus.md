---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Bus d'exportation ME à seuil
    icon: extendedae:threshold_export_bus
categories:
- extended devices
item_ids:
- extendedae:threshold_export_bus
---

# Bus d'exportation ME à seuil

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_threshold_export_bus.snbt"></ImportStructure>
</GameScene>

Le Bus d'exportation ME à seuil fonctionne lorsque la quantité d'un objet stocké dans le réseau ME est supérieure ou inférieure au seuil.

## Exemple

![GUI](../pic/thr_bus_gui1.png)

Le seuil du cuivre est fixé à 128, le bus exporte donc du cuivre quand la quantité de cuivre stockée dans le réseau dépasse 128.

![GUI](../pic/thr_bus_gui2.png)

Le seuil est le même que ci-dessus, mais le mode est réglé sur INFÉRIEUR. Le bus exporte du cuivre quand la quantité de cuivre stockée est inférieure à 128.
