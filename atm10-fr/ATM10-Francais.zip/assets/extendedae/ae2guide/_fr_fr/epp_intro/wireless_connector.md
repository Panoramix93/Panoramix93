---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Connecteur sans fil ME
    icon: extendedae:wireless_connect
categories:
- extended devices
item_ids:
- extendedae:wireless_connect
- extendedae:wireless_tool
---

# Connecteur sans fil ME

<Row gap="20">
<BlockImage id="extendedae:wireless_connect" scale="6"></BlockImage>
<ItemImage id="extendedae:wireless_tool" scale="6"></ItemImage>
</Row>

Le connecteur sans fil ME peut relier deux réseaux comme le <ItemLink id="ae2:quantum_link" />, mais sa portée est limitée et il ne peut pas
franchir les dimensions. Le connecteur sans fil ME ne gère que les liaisons un à un. Utilisez le <ItemLink id="extendedae:wireless_hub" />
si vous voulez des liaisons multiples.

## Relier les connecteurs sans fil

Utilisez le kit de configuration sans fil ME pour cliquer sur les deux connecteurs sans fil que vous voulez relier.

Accroupissez-vous et cliquez pour effacer le réglage actuel du kit de configuration sans fil ME.

Le connecteur sans fil ME change de texture lorsqu'une liaison est établie avec succès.

Connecteurs sans fil ME non reliés

<GameScene zoom="5" background="transparent">
  <ImportStructure src="../structure/wireless_connector_off.snbt"></ImportStructure>
</GameScene>

Connecteurs sans fil ME reliés

<GameScene zoom="5" background="transparent">
  <ImportStructure src="../structure/wireless_connector_on.snbt"></ImportStructure>
</GameScene>

## Couleur

Les connecteurs sans fil peuvent être colorés comme les câbles et ne se connectent qu'aux câbles/connecteurs de la même couleur.

Vous avez besoin d'un <ItemLink id="ae2:color_applicator" /> pour colorer un connecteur.

Vous pouvez donc organiser vos connecteurs sans fil de cette manière :

<GameScene zoom="3" background="transparent" interactive={true}>
  <ImportStructure src="../structure/wireless_connector_setup.snbt"></ImportStructure>
</GameScene>

## Consommation d'énergie

Plus les connecteurs sans fil ME sont éloignés les uns des autres, plus ils consomment d'énergie. Comme la courbe coût/distance n'est pas linéaire, le coût en énergie
peut devenir très élevé lorsqu'ils sont trop éloignés.

Vous pouvez utiliser des <ItemLink id="ae2:energy_card" /> pour économiser de l'énergie ; chaque carte réduit le coût en énergie de 10 %.

