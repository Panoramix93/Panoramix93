---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Châssis de machine étendu
    icon: extendedae:machine_frame
categories:
- extended foundation
item_ids:
- extendedae:machine_frame
---

# Les débuts d'ExtendedAE

<Row>
<BlockImage id="extendedae:machine_frame" scale="8"></BlockImage>
</Row>

Après avoir rassemblé assez de <ItemLink id="extendedae:entro_crystal" />, vous pouvez enfin fabriquer votre premier châssis de machine étendu.
Ces châssis sont la base d'ExtendedAE, et la plupart des machines sous forme de bloc d'ExtendedAE en ont besoin.
