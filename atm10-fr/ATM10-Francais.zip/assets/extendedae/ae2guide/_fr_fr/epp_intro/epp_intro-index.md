---
navigation:
    title: Introduction à Extended AE
    position: 60
---

# Étendez votre installation AE !

Extended AE ramène dans l'AE moderne certaines fonctionnalités d'AE 1.7.10/1.12.2.

[GitHub d'Extended AE](https://github.com/GlodBlock/ExtendedAE) 

## Système de cristal d'entro
<CategoryIndex category="entro system"></CategoryIndex>

## Fondation étendue
<CategoryIndex category="extended foundation"></CategoryIndex>

## Appareils étendus
<CategoryIndex category="extended devices"></CategoryIndex>

## Objets étendus
<CategoryIndex category="extended items"></CategoryIndex>
