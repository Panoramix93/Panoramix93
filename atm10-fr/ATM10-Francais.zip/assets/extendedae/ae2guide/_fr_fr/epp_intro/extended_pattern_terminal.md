---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Terminal d'accès aux modèles ME étendu
    icon: extendedae:ex_pattern_access_part
categories:
- extended devices
item_ids:
- extendedae:ex_pattern_access_part
- extendedae:wireless_ex_pat
---

# Terminal d'accès aux modèles ME étendu

Le terminal d'accès aux modèles ME étendu offre trois fonctions supplémentaires par rapport au <ItemLink id="ae2:pattern_access_terminal" />.

<Row gap="20">
<GameScene zoom="6" background="transparent">
<ImportStructure src="../structure/cable_ex_pattern_terminal.snbt"></ImportStructure>
<IsometricCamera yaw="180"></IsometricCamera>
</GameScene>
<ItemImage id="extendedae:wireless_ex_pat" scale="4"></ItemImage>
</Row>

## Une meilleure recherche de modèles

Vous pouvez rechercher des modèles par le nom de leurs ingrédients d'entrée ou de sortie.

![EPA1](../pic/epa_gui1.png)

## Mise en évidence des modèles

Il reste parfois difficile de trouver le modèle voulu, car les modèles sont toujours affichés par groupes. Le terminal d'accès
aux modèles étendu peut mettre en évidence le modèle correspondant dans l'interface graphique.

![EPA2](../pic/epa_gui2.png)

## Mise en évidence du fournisseur de modèles dans le monde

Il peut être difficile de déterminer quel fournisseur de modèles est bloqué lors de grosses tâches de fabrication. Le terminal d'accès aux modèles étendu
peut mettre en évidence le fournisseur de modèles dans le monde, afin que vous le repériez facilement.

![EPA3](../pic/epa_gui3.png)

