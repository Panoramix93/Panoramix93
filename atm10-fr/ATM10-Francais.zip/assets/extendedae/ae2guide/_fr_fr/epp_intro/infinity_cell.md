---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Disque infini ME
    icon: extendedae:infinity_water_cell
categories:
- extended items
item_ids:
- extendedae:infinity_water_cell
- extendedae:infinity_cobblestone_cell
---

# Disque infini ME

Un simple puits à eau et à pierre, sous forme de disque de stockage.

<Row>
<ItemImage id="extendedae:infinity_water_cell" scale="4"></ItemImage>
<ItemImage id="extendedae:infinity_cobblestone_cell" scale="4"></ItemImage>
</Row>

Ils contiennent 2,1 milliards d'objets ou de fluides, et vous pouvez en extraire une quantité illimitée de pierre ou d'eau, ou y insérer une quantité
illimitée de pierre ou d'eau.
