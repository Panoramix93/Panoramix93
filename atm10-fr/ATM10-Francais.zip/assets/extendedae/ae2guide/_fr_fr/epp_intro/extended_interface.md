---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Interface ME étendue
    icon: extendedae:ex_interface
categories:
- extended devices
item_ids:
- extendedae:ex_interface
- extendedae:ex_interface_part
---

# Interface ME étendue

<Row gap="20">
<BlockImage id="extendedae:ex_interface" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_interface.snbt"></ImportStructure>
</GameScene>
</Row>

L'interface ME étendue est une <ItemLink id="ae2:interface" /> dotée d'un inventaire de configuration plus grand.

*En ai-je vraiment besoin ?*

![EIGui](../pic/ei_gui.png)
