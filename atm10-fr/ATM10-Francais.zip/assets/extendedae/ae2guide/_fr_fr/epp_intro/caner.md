---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Encapsuleur ME
    icon: extendedae:caner
categories:
- extended devices
item_ids:
- extendedae:caner
---

# Encapsuleur ME

<BlockImage id="extendedae:caner" scale="8"></BlockImage>

L'Encapsuleur ME est une machine qui « met en bidon » des matières : fluides, gaz de Mekanism, mana de Botania et même énergie !

Le premier emplacement contient la matière de remplissage, et le second l'objet à remplir.

Il a besoin d'énergie pour fonctionner et chaque opération coûte 80 AE.

![GUI](../pic/caner_gui.png)

Par défaut, il ne remplit que des fluides ; installez l'add-on correspondant pour lui faire remplir d'autres matières.

### Add-ons pris en charge :
- Applied Flux
- Applied Mekanistics
- Applied Botanics Addon

## Fabrication automatique avec l'Encapsuleur ME

Seules les faces du dessus et du dessous peuvent accepter l'énergie et se connecter au réseau.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/caner_example.snbt"></ImportStructure>
</GameScene>

Une configuration simple pour l'Encapsuleur ME. L'Encapsuleur ME éjecte automatiquement l'objet rempli lorsqu'il reçoit des ingrédients du <ItemLink id="ae2:pattern_provider" />.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/caner_auto.snbt"></ImportStructure>
</GameScene>

Le modèle ne doit contenir que la matière de remplissage et le récipient à remplir. Voici quelques exemples :

Remplir un seau d'eau :

![P1](../pic/fill_water.png)

Charger une tablette d'énergie (nécessite Applied Flux) :

![P1](../pic/fill_energy.png)


## Vidange

L'Encapsuleur ME peut aussi extraire les matières d'un récipient en mode Vidange. Vous devez inverser les entrées et les sorties dans le modèle.
