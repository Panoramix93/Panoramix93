---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Bus de stockage ME par mod
    icon: extendedae:mod_storage_bus
categories:
- extended devices
item_ids:
- extendedae:mod_storage_bus
---

# Bus de stockage ME par mod

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_mod_storage_bus.snbt"></ImportStructure>
</GameScene>

Le bus de stockage ME par mod est un <ItemLink id="ae2:storage_bus" /> que l'on peut filtrer par nom de mod ou par identifiant de mod.

Utilisez des virgules pour séparer plusieurs identifiants de mod si vous voulez filtrer plusieurs mods.

![PIC](../pic/mod_bus_name.png)
