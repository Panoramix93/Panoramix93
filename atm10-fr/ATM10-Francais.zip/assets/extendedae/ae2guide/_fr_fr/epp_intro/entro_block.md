---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Bloc d'entro
    icon: extendedae:entro_block
categories:
- entro system
item_ids:
- extendedae:entro_block
---

# Le bloc d'entro

<Row>
<BlockImage id="extendedae:entro_block" scale="8"></BlockImage>
</Row>

Un bloc de stockage pour le <ItemLink id="extendedae:entro_crystal" />.
