---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Fluix entroïsé bourgeonnant
    icon: extendedae:entro_budding_fully
categories:
- entro system
item_ids:
- extendedae:entro_budding_fully
- extendedae:entro_budding_mostly
- extendedae:entro_budding_half
- extendedae:entro_budding_hardly
- extendedae:entro_cluster_small
- extendedae:entro_cluster_medium
- extendedae:entro_cluster_large
- extendedae:entro_cluster
---

# Fluix entroïsé bourgeonnant

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/budding_entro.snbt"></ImportStructure>
  <IsometricCamera yaw="195" pitch="30"></IsometricCamera>
</GameScene>

C'est une source de <ItemLink id="extendedae:entro_crystal" />, et vous pouvez créer du Fluix entroïsé bourgeonnant en injectant une <ItemLink id="extendedae:entro_seed" /> dans un <ItemLink id="ae2:fluix_block" />.

Le mécanisme de croissance des bourgeons d'entro est semblable à celui du [quartz de certus](ae2:items-blocks-machines/budding_certus.md). La dégradation
du Fluix entroïsé bourgeonnant est toutefois inévitable, et il finit par se transformer en <ItemLink id="ae2:quartz_block" />.
En théorie, vous pouvez obtenir environ 10 <ItemLink id="extendedae:entro_crystal" /> à partir d'un Fluix entroïsé complet sans enchantement Fortune.

Le Fluix entroïsé bourgeonnant lâche toujours **une** <ItemLink id="extendedae:entro_dust" /> lorsqu'il est cassé, quel que soit son état.
Un bourgeon d'entro lâche un <ItemLink id="extendedae:entro_shard" /> lorsqu'il n'est pas arrivé à maturité.
