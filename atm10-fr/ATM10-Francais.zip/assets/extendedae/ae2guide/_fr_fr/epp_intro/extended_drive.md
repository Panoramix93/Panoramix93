---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Range-disque ME étendu
    icon: extendedae:ex_drive
categories:
- extended devices
item_ids:
- extendedae:ex_drive
---

# Range-disque ME étendu

<Row gap="20">
<BlockImage id="extendedae:ex_drive" scale="8"></BlockImage>
</Row>

Le range-disque ME étendu est un <ItemLink id="ae2:drive" /> doté d'un inventaire de cellules plus grand. Il peut accueillir 20 disques de stockage.
