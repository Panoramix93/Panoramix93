---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Réparateur de cristaux ME
    icon: extendedae:crystal_fixer
categories:
- extended devices
item_ids:
- extendedae:crystal_fixer
---

# Réparateur de cristaux ME

<BlockImage id="extendedae:crystal_fixer" scale="8"></BlockImage>

Le réparateur de cristaux ME peut réparer un bloc de Budding Certus Quartz et l'améliorer.

Il a besoin d'un <ItemLink id="ae2:charged_certus_quartz_crystal" /> et d'énergie pour fonctionner. Faites un clic droit dessus avec un <ItemLink id="ae2:charged_certus_quartz_crystal" /> pour l'insérer.

<Row gap="20">
<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/crystal_fixer.snbt"></ImportStructure>
</GameScene>
</Row>
