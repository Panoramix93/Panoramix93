---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Modificateur de configuration
    icon: extendedae:config_modifier
categories:
- extended items
item_ids:
- extendedae:config_modifier
---

# Modificateur de configuration

Le Modificateur de configuration est un outil de modification en masse des inventaires de configuration.

<ItemImage id="extendedae:config_modifier" scale="4"></ItemImage>

Faites un clic droit pour ouvrir son interface.

## Utilisation

Le Modificateur de configuration permet de modifier rapidement des inventaires de configuration, comme celui d'une interface, selon ses réglages ; par exemple,
en portant la quantité des objets configurés à la valeur maximale ou en les supprimant tous.

Vous pouvez cliquer sur le dispositif cible (bloc ou sous-partie) dans le monde avec le Modificateur de configuration pour modifier sa configuration.

## Réglages

Il possède deux réglages principaux : le **mode de modification** et la **quantité de modification (X)**.

Vous pouvez cliquer sur un bouton pour changer de mode.

![Interface](../pic/cm.png)

- Additionner/Soustraire/Multiplier/Diviser : additionne, soustrait, multiplie ou divise la quantité configurée par X.
- Maximiser : porte la quantité configurée à la valeur maximale.
- Minimiser : ramène la quantité configurée à la valeur minimale.
- Définir : règle la quantité configurée sur X.
- Effacer : efface tous les objets configurés.
