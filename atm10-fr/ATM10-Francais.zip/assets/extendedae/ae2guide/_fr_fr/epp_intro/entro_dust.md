---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Poudre d'Entro
    icon: extendedae:entro_dust
categories:
- entro system
item_ids:
- extendedae:entro_dust
---

# Poudre d'Entro

<Row>
<ItemImage id="extendedae:entro_dust" scale="4"></ItemImage>
</Row>

Vous pouvez en obtenir en broyant un <ItemLink id="extendedae:entro_crystal" /> ou en cassant un [bloc de fluix entroïsé bourgeonnant](./entro_budding.md).

Elle sert à fabriquer certaines machines d'ExtendedAE ainsi que le <ItemLink id="extendedae:entro_ingot" />.
