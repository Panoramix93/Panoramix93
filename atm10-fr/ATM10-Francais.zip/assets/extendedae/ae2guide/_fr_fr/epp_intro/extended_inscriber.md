---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Presse étendue
    icon: extendedae:ex_inscriber
categories:
- extended devices
item_ids:
- extendedae:ex_inscriber
---

# Presse étendue

<Row gap="20">
<BlockImage id="extendedae:ex_inscriber" scale="8"></BlockImage>
</Row>

La Presse étendue est une version avancée de la <ItemLink id="ae2:inscriber" />.

Elle peut exécuter 4 travaux de gravure en même temps.

Un bouton permet de changer la taille de pile maximale de son inventaire, comme sur la presse normale.

Il est recommandé de régler la taille de pile sur 1 lorsque vous l'utilisez avec un <ItemLink id="ae2:pattern_provider" />, afin d'éviter d'éventuels problèmes.
