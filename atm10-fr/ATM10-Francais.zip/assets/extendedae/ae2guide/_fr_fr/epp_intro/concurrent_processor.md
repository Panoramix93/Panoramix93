---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Processeur concurrent
    icon: extendedae:concurrent_processor
categories:
- extended foundation
item_ids:
- extendedae:concurrent_processor
- extendedae:concurrent_processor_press
- extendedae:concurrent_processor_print
---

# Processeur concurrent

<Row>
<ItemImage id="extendedae:concurrent_processor" scale="4"></ItemImage>
<ItemImage id="extendedae:concurrent_processor_press" scale="4"></ItemImage>
<ItemImage id="extendedae:concurrent_processor_print" scale="4"></ItemImage>
</Row>

Les Processeurs concurrents sont couramment utilisés dans les machines multi-thread, ce qui leur permet de traiter plusieurs tâches simultanément.
