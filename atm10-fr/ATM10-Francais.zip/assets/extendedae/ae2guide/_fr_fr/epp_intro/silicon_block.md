---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: Bloc de silicium
  icon: extendedae:silicon_block
categories:
  - extended foundation
item_ids:
  - extendedae:silicon_block
---

# Bloc de silicium

<Row>
<BlockImage id="extendedae:silicon_block" scale="8"></BlockImage>
</Row>

Un bloc de stockage pour le <ItemLink id="ae2:silicon" />.
