---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Assembleur de cristaux
    icon: extendedae:crystal_assembler
categories:
- extended foundation
item_ids:
- extendedae:crystal_assembler
---

# Assembleur de cristaux

<Row>
<BlockImage id="extendedae:crystal_assembler" scale="8"></BlockImage>
</Row>

Ces appareils étendus sont trop complexes pour être fabriqués dans une table de fabrication : il vous faudra donc un assembleur de cristaux pour produire la plupart d'entre eux.

**Remarque : la face portant l'écran ne peut pas se connecter au réseau.**

Il peut également réaliser certaines recettes de transformation dans le monde, comme la transformation du fluix.
