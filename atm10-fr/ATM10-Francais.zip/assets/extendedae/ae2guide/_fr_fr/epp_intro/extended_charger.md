---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Chargeur étendu
    icon: extendedae:ex_charger
categories:
- extended devices
item_ids:
- extendedae:ex_charger
---

# Chargeur étendu

<Row gap="20">
<BlockImage id="extendedae:ex_charger" scale="8"></BlockImage>
</Row>

Le Chargeur étendu est un <ItemLink id="ae2:charger" /> amélioré.

Il peut charger 4 objets en même temps.
