---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Fournisseur de pattern ME étendu
    icon: extendedae:ex_pattern_provider
categories:
- extended devices
item_ids:
- extendedae:ex_pattern_provider
- extendedae:ex_pattern_provider_part
---

# Fournisseur de pattern ME étendu

<Row gap="20">
<BlockImage id="extendedae:ex_pattern_provider" scale="8"></BlockImage>
<BlockImage id="extendedae:ex_pattern_provider" p:push_direction="up" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_pattern_provider.snbt"></ImportStructure>
</GameScene>
</Row>

Le Fournisseur de pattern ME étendu est un <ItemLink id="ae2:pattern_provider" /> doté d'un inventaire de
patterns plus grand.

*Qui a besoin d'un sous-réseau quand on peut mettre tous ses patterns dans un seul bloc ?*

![EPPGui](../pic/epp_gui.png)
