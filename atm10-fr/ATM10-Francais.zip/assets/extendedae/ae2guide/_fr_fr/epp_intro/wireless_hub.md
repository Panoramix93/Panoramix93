---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Concentrateur sans fil ME
    icon: extendedae:wireless_hub
categories:
- extended devices
item_ids:
- extendedae:wireless_hub
---

# Concentrateur sans fil ME

<Row gap="20">
<BlockImage id="extendedae:wireless_hub" scale="6"></BlockImage>
</Row>

Le Concentrateur sans fil ME fonctionne exactement comme le <ItemLink id="extendedae:wireless_connect" />, mais il peut relier jusqu'à 8 concentrateurs ou connecteurs
en même temps.

## Configuration des connexions

Le Concentrateur sans fil ME possède 8 ports. Il trouve automatiquement un port disponible lorsque vous l'associez à l'aide de l'<ItemLink id="extendedae:wireless_tool" />.

En revanche, lorsque tous ses ports sont occupés, vous devez déconnecter manuellement une connexion existante en cliquant sur le bouton « X » avant d'en établir une nouvelle.
