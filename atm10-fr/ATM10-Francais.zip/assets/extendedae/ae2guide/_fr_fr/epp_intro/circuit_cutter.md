---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Découpeur de circuits
    icon: extendedae:circuit_cutter
categories:
- extended devices
item_ids:
- extendedae:circuit_cutter
---

# Découpeur de circuits

<Row gap="20">
<BlockImage id="extendedae:circuit_cutter" scale="8"></BlockImage>
</Row>

Vous ne supportez pas la lenteur de la presse ? Le découpeur de circuits peut découper des blocs de matériaux directement en
[impressions](ae2:items-blocks-machines/processors.md) de processeur, ce qui le rend jusqu'à neuf fois plus rapide qu'une presse.

**Remarque : les faces en verre sans port ne peuvent pas se connecter au réseau.**

