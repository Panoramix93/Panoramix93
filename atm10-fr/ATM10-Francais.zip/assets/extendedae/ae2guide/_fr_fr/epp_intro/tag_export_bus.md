---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Bus d'exportation par tag ME
    icon: extendedae:tag_export_bus
categories:
- extended devices
item_ids:
- extendedae:tag_export_bus
---

# Bus d'exportation par tag ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_tag_export_bus.snbt"></ImportStructure>
</GameScene>

Le Bus d'exportation par tag ME est un <ItemLink id="ae2:export_bus" /> que l'on peut filtrer par tags d'objets ou de fluides.

Sa règle de filtrage est la même que celle du <ItemLink id="extendedae:tag_storage_bus" />.
