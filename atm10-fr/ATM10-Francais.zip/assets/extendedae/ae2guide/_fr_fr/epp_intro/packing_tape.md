---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Ruban d'emballage ME
    icon: extendedae:me_packing_tape
categories:
- extended items
item_ids:
- extendedae:me_packing_tape
- extendedae:package
---

# Ruban d'emballage ME

Le ruban d'emballage ME permet d'emballer un appareil ME posé dans le monde sous la forme d'un objet « appareil emballé ».

<Row>
<ItemImage id="extendedae:me_packing_tape" scale="4"></ItemImage>
<ItemImage id="extendedae:package" scale="4"></ItemImage>
</Row>

## Emballage

Accroupissez-vous et faites un clic droit sur un appareil ME avec le ruban pour en obtenir un colis. Tous les réglages et le contenu de l'appareil sont
conservés. C'est très pratique lorsque vous déplacez votre installation ME.

Notez que le ruban d'emballage ME ne prend en charge que les appareils de la liste ; cette liste est configurable.

### Liste par défaut

|                                     Appareil                                      |                                  Nom                                  |
|:---------------------------------------------------------------------------------:|:---------------------------------------------------------------------:|
|    <ItemImage id="extendedae:ex_interface_part" scale="3"></ItemImage>     |    <ItemLink id="extendedae:ex_interface_part"></ItemLink>     |
| <ItemImage id="extendedae:ex_pattern_provider_part" scale="3"></ItemImage> | <ItemLink id="extendedae:ex_pattern_provider_part"></ItemLink> |
|       <ItemImage id="extendedae:ex_interface" scale="3"></ItemImage>       |       <ItemLink id="extendedae:ex_interface"></ItemLink>       |
|   <ItemImage id="extendedae:ex_pattern_provider" scale="3"></ItemImage>    |   <ItemLink id="extendedae:ex_pattern_provider"></ItemLink>    |
|            <ItemImage id="ae2:cable_interface" scale="3"></ItemImage>             |            <ItemLink id="ae2:cable_interface"></ItemLink>             |
|         <ItemImage id="ae2:cable_pattern_provider" scale="3"></ItemImage>         |         <ItemLink id="ae2:cable_pattern_provider"></ItemLink>         |
|               <ItemImage id="ae2:interface" scale="3"></ItemImage>                |               <ItemLink id="ae2:interface"></ItemLink>                |
|            <ItemImage id="ae2:pattern_provider" scale="3"></ItemImage>            |            <ItemLink id="ae2:pattern_provider"></ItemLink>            |
|                 <ItemImage id="ae2:drive" scale="3"></ItemImage>                  |                 <ItemLink id="ae2:drive"></ItemLink>                  |

## Déballage

Faites un clic droit avec le colis comme s'il s'agissait du bloc ou du sous-élément d'appareil ; l'appareil emballé est alors restitué depuis le
colis.
