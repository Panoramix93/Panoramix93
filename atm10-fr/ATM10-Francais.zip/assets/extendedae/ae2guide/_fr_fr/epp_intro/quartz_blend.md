---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: Mélange de quartz
  icon: extendedae:quartz_blend
categories:
  - extended foundation
item_ids:
  - extendedae:quartz_blend
---

# Mélange de quartz

<Row>
<ItemImage id="extendedae:quartz_blend" scale="4"></ItemImage>
</Row>

Un mélange de quartz, de charbon et de sable. Sa cuisson produit davantage de <ItemLink id="ae2:silicon" /> que la cuisson directe
de poudre de Certus Quartz.
