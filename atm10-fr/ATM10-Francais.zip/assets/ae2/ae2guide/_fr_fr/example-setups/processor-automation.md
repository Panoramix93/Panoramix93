---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automatisation des processeurs
  icon: logic_processor
---

# Automatisation de la production de processeurs

Il existe de nombreuses façons d'automatiser la fabrication des [processeurs](../items-blocks-machines/processors.md) ; en voici une.

Cette disposition générale peut être réalisée avec n'importe quel type de tuyau, conduit, gaine ou autre système de logistique
d'objets, du moment que vous pouvez le filtrer.

![Le schéma du processus](../assets/diagrams/processor_flow_diagram.png)

Vous trouverez ici le détail de la réalisation avec AE2 seul, à l'aide de [sous-réseaux « tuyau »](pipe-subnet.md).

Notez que, puisque ce montage utilise un <ItemLink id="pattern_provider" />, il est destiné à s'intégrer à votre installation
de [fabrication automatique](../ae2-mechanics/autocrafting.md). Si vous souhaitez simplement automatiser les processeurs de façon autonome, remplacez le fournisseur de modèles par un autre tonneau et placez directement les ingrédients dans le tonneau du haut.

Ce montage se trouve être rétrocompatible
avec les versions précédentes d'AE2, car même si les <ItemLink id="inscriber" /> sont orientés, les sous-réseaux « tuyau » insèrent et
extraient toujours par les bonnes faces.

## Une leçon d'encodage de modèles

Souvent, le [modèle](../items-blocks-machines/patterns.md) que vous devez encoder **NE CORRESPONDRA PAS À CE QUE VOUS VOYEZ DANS JEI**, ni à ce que JEI produit quand vous cliquez sur le bouton +.
Dans ce cas, JEI produira 2 modèles distincts, l'un pour les composants imprimés et l'autre pour l'assemblage final, et le modèle
des composants imprimés inclura une [presse](../items-blocks-machines/presses.md). Ce n'est pas ce que nous voulons, car ce n'est pas ce que fait l'installation. Nous voulons 1 seul modèle qui
prend les ressources brutes en entrée et produit le processeur terminé, et comme la presse se trouve déjà dans le graveur, nous ne devons pas la mettre dans le modèle.

---

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/processor_automation.snbt" />

  <BoxAnnotation color="#dddddd" min="5 1 0" max="6 2 1" thickness=".05">
        (1) Fournisseur de modèles : dans sa configuration par défaut, avec les modèles de traitement correspondants.

        <Row>
            ![Modèle logique](../assets/diagrams/logic_pattern_small.png)
            ![Modèle de calcul](../assets/diagrams/calculation_pattern_small.png)
            ![Modèle d'ingénierie](../assets/diagrams/engineering_pattern_small.png)
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.7 2 0" max="5 3 1" thickness=".05">
        (2) Bus de stockage ME n° 1 : dans sa configuration par défaut.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="4.3 2 1" thickness=".05">
        (3) Bus d'exportation ME n° 1 : filtré sur le silicium, avec 2 cartes d'accélération
        <Row><ItemImage id="silicon" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="4.3 3 1" thickness=".05">
        (4) Bus d'exportation ME n° 2 : filtré sur le lingot d'or, avec 2 cartes d'accélération
        <Row><ItemImage id="minecraft:gold_ingot" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="4.3 4 1" thickness=".05">
        (5) Bus d'exportation ME n° 3 : filtré sur le cristal de Certus Quartz, avec 2 cartes d'accélération
        <Row><ItemImage id="certus_quartz_crystal" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 6 0" max="4.3 5 1" thickness=".05">
        (6) Bus d'exportation ME n° 4 : filtré sur le diamant, avec 2 cartes d'accélération
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 0" max="2 2 1" thickness=".05">
        (7) Bus d'exportation ME n° 5 : filtré sur la poudre de redstone, avec 2 cartes d'accélération
        <Row><ItemImage id="minecraft:redstone" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 0" max="3 2 1" thickness=".05">
        (8) Graveur n° 1 : dans sa configuration par défaut. Contient une presse à silicium et 4 cartes d'accélération
        <Row><ItemImage id="silicon_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 3 0" max="3 4 1" thickness=".05">
        (9) Graveur n° 2 : dans sa configuration par défaut. Contient une presse logique et 4 cartes d'accélération
        <Row><ItemImage id="logic_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 4 0" max="3 5 1" thickness=".05">
        (10) Graveur n° 3 : dans sa configuration par défaut. Contient une presse de calcul et 4 cartes d'accélération
        <Row><ItemImage id="calculation_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 5 0" max="3 6 1" thickness=".05">
        (11) Graveur n° 4 : dans sa configuration par défaut. Contient une presse d'ingénierie et 4 cartes d'accélération
        <Row><ItemImage id="engineering_processor_press" scale="2" /> <ItemImage id="speed_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 0" max="1 3 1" thickness=".05">
        (12) Graveur n° 5 : dans sa configuration par défaut. Contient 4 cartes d'accélération
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 2 0" max="3 1 1" thickness=".05">
        (13) Bus d'importation ME n° 1 : dans sa configuration par défaut, avec 2 cartes d'accélération
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 4 0" max="3 3 1" thickness=".05">
        (14) Bus d'importation ME n° 2 : dans sa configuration par défaut, avec 2 cartes d'accélération
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 5 0" max="3 4 1" thickness=".05">
        (15) Bus d'importation ME n° 3 : dans sa configuration par défaut, avec 2 cartes d'accélération
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 6 0" max="3 5 1" thickness=".05">
        (16) Bus d'importation ME n° 4 : dans sa configuration par défaut, avec 2 cartes d'accélération
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 3 0" max="1 3.3 1" thickness=".05">
        (17) Bus de stockage ME n° 2 : dans sa configuration par défaut.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1.7 0" max="1 2 1" thickness=".05">
        (18) Bus de stockage ME n° 3 : dans sa configuration par défaut.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 0" max="0.7 3 1" thickness=".05">
        (19) Bus d'importation ME n° 5 : dans sa configuration par défaut, avec 2 cartes d'accélération
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="5 0.7 0" max="6 1 1" thickness=".05">
        (20) Bus de stockage ME n° 4 : dans sa configuration par défaut.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.3 2.7 0.3" max="3.7 3 0.7" thickness=".05">
        La fibre de quartz alimente les 3 graveurs, car les graveurs se comportent comme des câbles et transmettent donc l'énergie
  </BoxAnnotation>

<DiamondAnnotation pos="7 1.5 0.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="185" pitch="5" />
</GameScene>

## Configurations

* Le <ItemLink id="pattern_provider" /> (1) est dans sa configuration par défaut, avec les <ItemLink id="processing_pattern" /> correspondants.
  Notez que les modèles passent directement des ressources brutes au processeur terminé et n'incluent **PAS** la [presse](../items-blocks-machines/presses.md).

  ![Modèle logique](../assets/diagrams/logic_pattern.png)
  ![Modèle de calcul](../assets/diagrams/calculation_pattern.png)
  ![Modèle d'ingénierie](../assets/diagrams/engineering_pattern.png)

* Les <ItemLink id="storage_bus" /> (2, 17, 18, 20) sont dans leur configuration par défaut.
* Les <ItemLink id="export_bus" /> (3-7) sont filtrés sur l'ingrédient correspondant. Ils contiennent 2 <ItemLink id="speed_card" />.
    <Row>
      <ItemImage id="silicon" scale="2" />
      <ItemImage id="minecraft:gold_ingot" scale="2" />
      <ItemImage id="certus_quartz_crystal" scale="2" />
      <ItemImage id="minecraft:diamond" scale="2" />
      <ItemImage id="minecraft:redstone" scale="2" />
    </Row>
* Les <ItemLink id="import_bus" /> (13-16, 19) sont dans leur configuration par défaut. Ils contiennent 2 <ItemLink id="speed_card" />.
* Les <ItemLink id="inscriber" /> sont dans leur configuration par défaut. Ils contiennent la [presse](../items-blocks-machines/presses.md) correspondante
   et 4 <ItemLink id="speed_card" />.
   <Row>
     <ItemImage id="silicon_press" scale="2" />
     <ItemImage id="logic_processor_press" scale="2" />
     <ItemImage id="calculation_processor_press" scale="2" />
     <ItemImage id="engineering_processor_press" scale="2" />
   </Row>

## Comment ça fonctionne

1. Le <ItemLink id="pattern_provider" /> pousse les ingrédients dans le tonneau.
2. Le premier [sous-réseau « tuyau »](pipe-subnet.md) (orange) extrait du tonneau le silicium, la poudre de redstone et l'ingrédient propre au processeur concerné
   (lingot d'or, cristal de Certus Quartz ou diamant) et les place dans le <ItemLink id="inscriber" /> correspondant.
3. Les quatre premiers <ItemLink id="inscriber" /> fabriquent le <ItemLink id="printed_silicon" />, ainsi que le <ItemLink id="printed_logic_processor" />,
   le <ItemLink id="printed_calculation_processor" /> ou le <ItemLink id="printed_engineering_processor" />.
4. Les deuxième et troisième [sous-réseaux « tuyau »](pipe-subnet.md) (verts) récupèrent les circuits imprimés dans les quatre premiers <ItemLink id="inscriber" />
    et les placent dans le cinquième <ItemLink id="inscriber" />, celui de l'assemblage final.
5. Le cinquième <ItemLink id="inscriber" /> assemble le [processeur](../items-blocks-machines/processors.md).
6. Le quatrième [sous-réseau « tuyau »](pipe-subnet.md) (violet) place le processeur dans le fournisseur de modèles, ce qui le renvoie vers le réseau principal.
