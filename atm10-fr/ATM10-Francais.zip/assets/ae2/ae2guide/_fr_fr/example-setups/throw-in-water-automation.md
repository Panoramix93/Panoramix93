---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automatisation du jet dans l'eau
  icon: fluix_crystal
---

# Automatisation des recettes par jet dans l'eau

Notez que, puisque cette installation utilise un <ItemLink id="pattern_provider" />, elle est destinée à s'intégrer à votre installation de
[fabrication automatique](../ae2-mechanics/autocrafting.md).

Certaines recettes exigent de jeter des objets dans l'eau (une installation similaire peut d'ailleurs servir à jeter des objets ailleurs).
Cela peut être automatisé avec un <ItemLink id="formation_plane" />, un <ItemLink id="annihilation_plane" /> et un peu
d'infrastructure autour (il s'agit en fait de 2 [sous-réseaux tuyau](pipe-subnet.md) modifiés).

Cette installation est conçue pour être utilisée avec l'[automatisation du chargeur](charger-automation.md), qui fournit les <ItemLink id="charged_certus_quartz_crystal" />s.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
        (1) Fournisseur de pattern : dans sa configuration par défaut, avec les patterns de traitement correspondants.

        ![Fluix Pattern](../assets/diagrams/fluix_pattern_small.png) ![Flawed Budding Pattern](../assets/diagrams/flawed_budding_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 1" max="2 1 2">
        (2) Interface : dans sa configuration par défaut.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 .7 1" max="2 1 2">
        (3) Plan de formation : réglé pour lâcher les entrées sous forme d'objets.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 2 1" max="2 2.3 2">
        (4) Plan d'annihilation : pas d'interface à configurer.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        (5) Bus de stockage : filtré sur les résultats des patterns
        <Row><ItemImage id="fluix_crystal" scale="2" /><BlockImage id="flawless_budding_quartz" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="3.9 0.5 1.5" color="#00ff00">
        Vers le réseau principal et l'automatisation du chargeur
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
    </DiamondAnnotation>

  <IsometricCamera yaw="180" pitch="0" />
</GameScene>

## Configurations et patterns

* Le <ItemLink id="pattern_provider" /> (1) est dans sa configuration par défaut, avec les <ItemLink id="processing_pattern" />s correspondants
  * Pour le <ItemLink id="fluix_crystal" />, la recette par défaut de JEI/REI convient très bien :

    ![Fluix Pattern](../assets/diagrams/fluix_pattern.png)

  * Pour le <ItemLink id="flawed_budding_quartz" />, il vaut probablement mieux le fabriquer directement à partir du <ItemLink id="quartz_block" />,
    ce qui évite les problèmes liés au fait que l'entrée d'une recette soit la sortie d'une autre, ce qui empêcherait le bus de stockage de filtrer correctement :

    ![Flawed Budding Pattern](../assets/diagrams/flawed_budding_pattern.png)

* L'<ItemLink id="interface" /> (2) est dans sa configuration par défaut.
* Le <ItemLink id="formation_plane" /> (3) est réglé pour lâcher les entrées sous forme d'objets.
* Le <ItemLink id="annihilation_plane" /> (4) n'a pas d'interface et ne peut pas être configuré.
* Le <ItemLink id="storage_bus" /> (5) est filtré sur les résultats des patterns.

## Comment ça marche

1.  Le <ItemLink id="pattern_provider" /> pousse les ingrédients dans l'<ItemLink id="interface" /> placée sur son côté, sur le sous-réseau vert
2.  L'interface (configurée pour ne rien stocker par défaut) essaie de pousser son contenu vers le [stockage du réseau](../ae2-mechanics/import-export-storage.md)
3.  Le seul stockage du sous-réseau vert est le <ItemLink id="formation_plane" />, qui lâche dans l'eau les objets qu'il reçoit
4.  Le <ItemLink id="annihilation_plane" /> du sous-réseau orange essaie de ramasser les objets qui viennent d'être lâchés, mais il n'y parvient pas, car
    le <ItemLink id="storage_bus" /> posé sur le fournisseur de pattern (le seul stockage du sous-réseau orange) est filtré pour n'accepter que les résultats des fabrications possibles
5.  Les objets subissent leur transformation dans le monde.
6.  Le plan d'annihilation peut désormais ramasser les objets situés devant lui, puisque le bus de stockage est autorisé à les stocker.
7.  Le bus de stockage range les objets obtenus dans le fournisseur de pattern, ce qui les renvoie vers le réseau.
