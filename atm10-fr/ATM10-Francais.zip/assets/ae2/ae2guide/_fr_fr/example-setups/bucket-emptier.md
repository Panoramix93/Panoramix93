---
navigation:
  parent: example-setups/example-setups-index.md
  title: Vide-seaux
  icon: minecraft:bucket
---

# Vide-seaux

Voir aussi [Remplisseur de seaux](bucket-filler.md).

Notez que, puisque ce montage utilise un <ItemLink id="pattern_provider" />, il est destiné à s'intégrer à votre installation
de [fabrication automatique](../ae2-mechanics/autocrafting.md).

Parfois, la vie est mal faite : vous avez besoin du fluide lui-même, mais vous ne pouvez le produire qu'en seau. Parfois une machine peut s'en charger pour vous
(comme le Fluid Transposer de Thermal Expansion), mais vous n'aurez pas toujours un mod qui le fait commodément à votre place. Heureusement,
Minecraft vanilla propose une méthode un peu moins pratique : le <ItemLink id="minecraft:dispenser" />.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/bucket_emptier.snbt" />

<BoxAnnotation color="#dddddd" min="2 1 0" max="3 2 1">
        (1) Fournisseur de modèles : réglé pour verrouiller la fabrication « Avec un signal de redstone » et avec le mode de blocage activé, avec les modèles de traitement correspondants.

        <Row>
        ![Modèle de vidage](../assets/diagrams/water_empty_pattern_small.png)
        ![Modèle de vidage](../assets/diagrams/lava_empty_pattern_small.png)
        </Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2.1 2 0.1" max="2.9 2.2 0.9">
        (2) Interface : dans sa configuration par défaut.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.1 2 1.1" max="3.9 2.2 1.9">
        (3) Bus de stockage ME n° 1 : dans sa configuration par défaut.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="4.05 1.05 0.8" max="4.95 1.95 1">
        (4) Plan d'annihilation : aucune interface à configurer.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.2 1.2 0.8" max="3.8 1.8 1">
        (5) Bus d'importation ME : filtré sur les seaux.
        <ItemImage id="minecraft:bucket" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1.1 0.1" max="3.2 1.9 0.9">
        (6) Bus de stockage ME n° 2 : dans sa configuration par défaut.
  </BoxAnnotation>

<DiamondAnnotation pos="0 1.5 0.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="225" pitch="45" />
</GameScene>

## Configurations

* Le <ItemLink id="pattern_provider" /> (1) est réglé pour verrouiller la fabrication « Avec un signal de redstone » et le mode de blocage est activé,
  avec les <ItemLink id="processing_pattern" /> correspondants.
  
    ![Modèle de vidage](../assets/diagrams/water_empty_pattern.png)
    ![Modèle de vidage](../assets/diagrams/lava_empty_pattern.png)

* L'<ItemLink id="interface" /> (2) est dans sa configuration par défaut.
* Le premier <ItemLink id="storage_bus" /> (3) est dans sa configuration par défaut.
* Le <ItemLink id="annihilation_plane" /> (4) n'a pas d'interface et ne peut pas être configuré.
* Le <ItemLink id="import_bus" /> (5) est filtré sur les seaux.
  <ItemImage id="minecraft:bucket" scale="2" />
* Le second <ItemLink id="storage_bus" /> (6) est dans sa configuration par défaut.

## Comment ça fonctionne

1. Le <ItemLink id="pattern_provider" /> pousse les ingrédients dans l'<ItemLink id="interface" />.
   (En réalité, par optimisation, il pousse directement à travers le bus de stockage comme s'il s'agissait d'une extension des faces du fournisseur. Les objets n'entrent jamais réellement dans l'interface.)
2. Par les mécanismes décrits dans [sous-réseaux « tuyau »](pipe-subnet.md#providing-to-multiple-places),
   le seau finit dans le <ItemLink id="minecraft:dispenser" />.
3. Le <ItemLink id="minecraft:comparator" /> détecte le seau dans le distributeur et alimente donc simultanément le distributeur et verrouille
   le <ItemLink id="pattern_provider" />.
4. Le distributeur déverse le fluide contenu dans le seau ; il contient désormais un seau vide.
5. Le <ItemLink id="import_bus" /> extrait le seau vide du distributeur et le stocke à travers le
   <ItemLink id="storage_bus" /> dans le fournisseur de modèles, ce qui le renvoie vers le réseau principal.
6. Le comparateur constate que le distributeur est vide, ce qui déverrouille le fournisseur.
