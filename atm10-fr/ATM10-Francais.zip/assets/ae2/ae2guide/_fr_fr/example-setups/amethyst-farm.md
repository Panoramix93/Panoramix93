---
navigation:
  parent: example-setups/example-setups-index.md
  title: Ferme d'améthyste
  icon: minecraft:amethyst_shard
---

# Culture de l'améthyste

Si l'<ItemLink id="growth_accelerator" /> fonctionne sur l'améthyste, les méthodes habituelles de filtrage des [bourgeons de certus](../items-blocks-machines/budding_certus.md)
avec un <ItemLink id="annihilation_plane" /> ne fonctionnent pas sur les bourgeons d'améthyste. Contrairement aux bourgeons de certus non matures qui laissent tomber
de la <ItemLink id="certus_quartz_dust" />, les bourgeons d'améthyste non matures ne laissent rien tomber : un plan d'annihilation les cassera donc toujours,
puisqu'un réseau peut toujours stocker « rien ».

La solution consiste à enchanter le plan d'annihilation avec Toucher de soie. Dans ce cas, les bourgeons d'améthyste non matures laissent *bien* tomber quelque chose
(les différents stades des blocs de bourgeon), et peuvent donc être filtrés.

Le <ItemLink id="minecraft:amethyst_cluster" /> doit ensuite être reposé par un <ItemLink id="formation_plane" />, pour être
recassé par un <ItemLink id="annihilation_plane" /> sans Toucher de soie, afin d'obtenir des <ItemLink id="minecraft:amethyst_shard" />.

Notez qu'en raison de l'orientation de l'amas, il doit y avoir une face de bloc solide directement à l'opposé du plan de formation.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/amethyst_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 1 1" max="3 2 2">
        (1) Plan d'annihilation n°1 : aucune interface à configurer, mais enchanté avec Toucher de soie.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1 1" max="2.3 2 2">
        (2) Plan de formation : filtré sur l'amas d'améthyste.
        <ItemImage id="minecraft:amethyst_cluster" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 0.7 1" max="2 1 2">
        (3) Plan d'annihilation n°2 : aucune interface à configurer, mais peut être enchanté avec Fortune.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="1.3 1 2">
        (4) Bus de stockage ME n°1 : filtré sur l'éclat d'améthyste.
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 .7" max="1 1 1">
        (5) Bus de stockage ME n°2 : filtré sur l'éclat d'améthyste. Sa priorité est réglée plus haut que celle de votre stockage principal.
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurations

* Le premier <ItemLink id="annihilation_plane" /> (1) n'a pas d'interface et ne peut pas être configuré, mais il doit être enchanté avec Toucher de soie.
* Le <ItemLink id="formation_plane" /> (2) est filtré sur l'<ItemLink id="minecraft:amethyst_cluster" />.
* Le second <ItemLink id="annihilation_plane" /> (3) n'a pas d'interface et ne peut pas être configuré, mais il peut être enchanté avec Fortune.
* Le premier <ItemLink id="storage_bus" /> (4) est filtré sur l'<ItemLink id="minecraft:amethyst_shard" />.
* Le second <ItemLink id="storage_bus" /> (5) est filtré sur l'<ItemLink id="minecraft:amethyst_shard" />, et sa
  [priorité](../ae2-mechanics/import-export-storage.md#storage-priority) est réglée plus haut que celle de votre stockage principal.

## Comment cela fonctionne

1. Le premier <ItemLink id="annihilation_plane" /> essaie de casser ce qui se trouve devant lui, mais il ne peut casser que l'<ItemLink id="minecraft:amethyst_cluster" />,
    car le seul stockage du sous-réseau est le <ItemLink id="formation_plane" />, filtré sur l'amas d'améthyste. Cela ne fonctionne que parce que
le plan est enchanté avec Toucher de soie ; sinon, il pourrait casser les bourgeons non matures, puisque ceux-ci ne laissent rien tomber.
2. Le <ItemLink id="formation_plane" /> place l'amas sur le bloc qui lui fait face.
3. Le second <ItemLink id="annihilation_plane" /> casse l'amas, ce qui produit des <ItemLink id="minecraft:amethyst_shard" />.
4. Le premier <ItemLink id="storage_bus" /> stocke les éclats dans le baril. Techniquement, il n'a pas besoin d'être filtré, car la seule
chose que le second plan d'annihilation est censé rencontrer, ce sont des amas arrivés à maturité.
5. Le second <ItemLink id="storage_bus" /> donne au réseau principal accès à tous les éclats d'améthyste contenus dans le baril. Il est réglé sur une
[priorité](../ae2-mechanics/import-export-storage.md#storage-priority) élevée afin que les éclats d'améthyste soient
replacés en priorité dans le baril plutôt que dans votre stockage principal.
