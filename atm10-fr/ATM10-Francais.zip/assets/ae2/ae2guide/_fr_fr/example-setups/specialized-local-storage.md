---
navigation:
  parent: example-setups/example-setups-index.md
  title: Stockage local spécialisé
  icon: drive
---

# Stockage local spécialisé

En exploitant l'un des [comportements particuliers de l'interface](../items-blocks-machines/interface.md#special-interactions), un
[sous-réseau](../ae2-mechanics/subnetworks.md) peut présenter le contenu de son stockage au réseau principal sans pouvoir
voir le stockage du réseau principal, et en n'occupant qu'1 [canal](../ae2-mechanics/channels.md).

C'est pratique pour le stockage local au niveau d'une ferme, afin que les objets ne débordent pas dans votre stockage principal.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/local_storage.snbt" />

<BoxAnnotation color="#dddddd" min="4 0 0" max="5 2 1">
        (1) Un moyen quelconque d'importer les objets (ici une interface)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 0 0" max="4 1 1">
        (2) Range-disque ME : il contient quelques disques. Ces disques doivent être filtrés sur ce que produit la ferme.
        Les disques peuvent recevoir des cartes de répartition équitable et des cartes de destruction du surplus.
        <Row><ItemImage id="item_storage_cell_4k" scale="2" /> <ItemImage id="equal_distribution_card" scale="2" /> <ItemImage id="void_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1 0" max="4 2 0.3">
        (3) Terminal de fabrication : il voit le contenu du range-disque ME du sous-réseau, mais pas le contenu du stockage de votre réseau principal.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
        (4) Interface nº 2 : dans sa configuration par défaut.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 0" max="2 1 1">
        (5) Bus de stockage ME : sa priorité est réglée plus haut que celle du stockage principal ; il peut être filtré sur ce que produit la ferme.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 0.3">
        Terminal de fabrication : il voit à la fois le contenu du stockage du réseau principal *et* celui du sous-réseau.
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurations

* La première <ItemLink id="interface" /> (1) se contente d'accepter les objets de la ferme que vous avez et de les pousser dans le sous-réseau.
* Le <ItemLink id="drive" /> (2) contient quelques [disques](../items-blocks-machines/storage_cells.md). Ces disques doivent être
  [partitionnés](../items-blocks-machines/cell_workbench.md) sur ce que produit la ferme.
  Ils peuvent recevoir des <ItemLink id="equal_distribution_card" /> et des <ItemLink id="void_card" />.
* La seconde <ItemLink id="interface" /> (4) est dans sa configuration par défaut.
* La [priorité](../ae2-mechanics/import-export-storage.md#storage-priority) du <ItemLink id="storage_bus" /> est réglée
  plus haut que celle du stockage principal. Il peut être filtré sur ce que produit la ferme.

## Fonctionnement

* L'<ItemLink id="interface" /> du sous-réseau montre au <ItemLink id="storage_bus" /> du réseau principal le contenu du
<ItemLink id="drive" />. Le bus de stockage peut donc extraire directement des objets des disques du range-disque ME et en insérer dedans.
* Le bus de stockage est réglé sur une [priorité](../ae2-mechanics/import-export-storage.md#storage-priority) élevée, afin que les objets soient
  replacés en priorité dans le sous-réseau plutôt que dans votre stockage principal.
* Point important : si les disques du sous-réseau se remplissent, les objets ne débordent pas dans le réseau principal. Si la ferme est d'un type
qui se bloque lorsqu'elle sature, des <ItemLink id="void_card" /> peuvent être utilisées pour supprimer le surplus d'objets à la place. 
* Si la ferme produit plusieurs objets, des <ItemLink id="equal_distribution_card" /> évitent qu'un seul objet remplisse tous les disques
et empêche le stockage des autres objets.
