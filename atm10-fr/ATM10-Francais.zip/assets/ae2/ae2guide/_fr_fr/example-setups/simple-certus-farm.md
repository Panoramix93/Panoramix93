---
navigation:
  parent: example-setups/example-setups-index.md
  title: Ferme de certus simple
  icon: certus_quartz_crystal
  position: 110
---

# Ferme de certus simple

Comme indiqué dans [Croissance du certus](../ae2-mechanics/certus-growth.md), l'automatisation de la récolte de
<ItemLink id="certus_quartz_crystal" /> repose sur des <ItemLink id="annihilation_plane" /> et des <ItemLink id="storage_bus" />. 
Les <ItemLink id="growth_accelerator" /> servent à accélérer massivement la croissance des bourgeons de quartz de certus, puis les plans
cassent le <ItemLink id="quartz_cluster" /> arrivé à maturité. Le filtrage exploite le trait étrangement pratique selon lequel les bourgeons de
certus non mûrs lâchent de la <ItemLink id="certus_quartz_dust" /> au lieu de ne rien lâcher.

Cette ferme fonctionne de façon entièrement automatique avec du <ItemLink id="flawless_budding_quartz" />, mais avec du quartz de certus bourgeonnant
imparfait, ébréché ou endommagé, vous devrez remplacer le bloc bourgeonnant à la main. Ou, comme décrit dans [Ferme de certus semi-automatique](semiauto-certus-farm.md)
et [Ferme de certus avancée](advanced-certus-farm.md), automatiquement.

Voir [Croissance du certus](../ae2-mechanics/certus-growth.md) pour des estimations de vitesse.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/simple_certus_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="3.7 1 1" max="4 2 2">
        (1) Plan d'annihilation : aucune interface à configurer, mais il peut être enchanté avec Fortune.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="3.3 2 2">
        (2) Bus de stockage ME n° 1 : filtré sur le cristal de quartz de certus.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 .7" max="2 2 1">
        (3) Bus de stockage ME n° 2 : filtré sur le cristal de quartz de certus. Sa priorité est réglée plus haut que celle du stockage principal.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurations

* Le premier <ItemLink id="annihilation_plane" /> (1) n'a pas d'interface et ne peut pas être configuré, mais il peut être enchanté avec Fortune.
* Le premier <ItemLink id="storage_bus" /> (2) est filtré sur le <ItemLink id="certus_quartz_crystal" />.
* Le second <ItemLink id="storage_bus" /> (3) est filtré sur le <ItemLink id="certus_quartz_crystal" /> et sa
  [priorité](../ae2-mechanics/import-export-storage.md#storage-priority) est réglée plus haut que celle du stockage principal.

## Fonctionnement

1. Le <ItemLink id="annihilation_plane" /> tente de casser ce qui se trouve devant lui, mais il ne peut casser que le <ItemLink id="quartz_cluster" />
   parce que le seul stockage du sous-réseau est le <ItemLink id="storage_bus" />, filtré sur le <ItemLink id="certus_quartz_crystal" />.
4. Le premier <ItemLink id="storage_bus" /> stocke les cristaux de quartz de certus dans le baril.
5. Le second <ItemLink id="storage_bus" /> donne au réseau principal accès à tous les cristaux de quartz de certus du baril. Il est réglé sur une
   [priorité](../ae2-mechanics/import-export-storage.md#storage-priority) élevée afin que les cristaux de quartz de certus soient de préférence
   remis dans le baril plutôt que dans votre stockage principal.
