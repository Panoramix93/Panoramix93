---
navigation:
  parent: example-setups/example-setups-index.md
  title: Fabrication récursive
  icon: minecraft:netherite_upgrade_smithing_template
---

# Une installation de fabrication récursive

Comme indiqué dans la page [fabrication automatique](../ae2-mechanics/autocrafting.md), l'algorithme de planification de la fabrication automatique ne sait pas gérer les recettes dont
la sortie principale fait partie des entrées. Par exemple, il ne sait pas gérer le clonage des <ItemLink id="minecraft:netherite_upgrade_smithing_template" />.

Une solution consiste à exploiter la capacité d'un <ItemLink id="level_emitter" /> à se faire passer pour un [modèle](../items-blocks-machines/patterns.md).

Celui-ci servira ensuite à activer une petite installation qui effectue la fabrication en continu. Dans ce cas précis, nous allons voir une installation
qui clone des <ItemLink id="minecraft:netherite_upgrade_smithing_template" />.

<RecipeFor id="minecraft:netherite_upgrade_smithing_template" />

***

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/recursive_recipe_setup.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Interface : configurée pour stocker les ingrédients supplémentaires requis, à savoir du diamant et de la netherrack.
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="minecraft:netherrack" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 1 0.3" max="2.7 1.3 0.7">
        (2) Émetteur de niveau : configuré sur « netherite smithing template », réglé sur « Émettre un signal de redstone pour fabriquer l'objet ».
        <Row><ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
        (3) Bus d'importation nº 1 : filtré sur les objets que l'interface stocke. Il contient une carte de redstone. Mode redstone réglé sur
        « Actif avec un signal ».
        <Row>
        <ItemImage id="minecraft:diamond" scale="2" />
        <ItemImage id="minecraft:netherrack" scale="2" />
        <ItemImage id="redstone_card" scale="2" />
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
        (4) Bus de stockage ME nº 1 : réglé sur une priorité plus élevée que l'autre bus de stockage. TRÈS IMPORTANT.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 0 1" max="4 1 2">
        (5) Assembleur moléculaire : il contient le modèle permettant de dupliquer un modèle de forge.

        ![Pattern](../assets/diagrams/smithing_template_pattern_small.png)

        Il contient aussi un modèle de forge que vous y avez inséré manuellement lors de la première construction de l'installation.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        (6) Bus d'importation nº 2 : dans sa configuration par défaut.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="2 1 1.3">
        (7) Bus de stockage ME nº 2 : filtré sur « netherite smithing template ». Réglé sur une priorité plus basse que l'autre bus de stockage.
        <ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

## Configurations

* L'<ItemLink id="interface" /> (1) est configurée pour stocker les ingrédients supplémentaires requis : du diamant et de la netherrack.
* L'<ItemLink id="level_emitter" /> (2) est configuré sur « netherite smithing template » et réglé sur « Émettre un signal de redstone pour fabriquer l'objet ».
* Le premier <ItemLink id="import_bus" /> (3) est filtré sur les objets que l'interface stocke. Il contient une carte de redstone. Le mode redstone est réglé sur « Actif avec un signal ».
* Le premier <ItemLink id="storage_bus" /> (4) est réglé sur une [priorité](../ae2-mechanics/import-export-storage.md#storage-priority) *plus élevée* que le second bus de stockage.
* L'<ItemLink id="molecular_assembler" /> (5) contient le modèle permettant de dupliquer le modèle de forge, ainsi qu'un modèle de forge déjà inséré manuellement.

  ![Pattern](../assets/diagrams/smithing_template_pattern.png)

* Le second <ItemLink id="import_bus" /> (6) est dans sa configuration par défaut.
* Le second <ItemLink id="storage_bus" /> (7) est filtré sur « netherite smithing template ». Il a une [priorité](../ae2-mechanics/import-export-storage.md#storage-priority) *plus basse* que le premier bus de stockage.

## Fonctionnement

1. L'<ItemLink id="level_emitter" /> se fait passer pour un [modèle](../items-blocks-machines/patterns.md) grâce à la
   <ItemLink id="crafting_card" /> insérée et au réglage « Émettre un signal de redstone pour fabriquer l'objet ». Ainsi, « netherite smithing template » apparaît dans
   les [terminaux](../items-blocks-machines/terminals.md) comme un objet valide pour la [fabrication automatique](../ae2-mechanics/autocrafting.md).
2. Lorsqu'il reçoit une demande de fabrication de cet objet, qu'elle vienne d'un joueur ou du système lui-même, l'émetteur de niveau s'active.
3. Le premier <ItemLink id="import_bus" /> est activé par l'émetteur de niveau et extrait les ingrédients stockés dans l'<ItemLink id="interface" />.
4. Le seul <ItemLink id="storage_bus" /> du réseau capable de stocker ces ingrédients est celui qui se trouve sur l'assembleur.
5. L'<ItemLink id="molecular_assembler" /> reçoit les ingrédients (en ayant déjà 1 modèle de forge à l'intérieur), effectue la fabrication et produit 2 modèles de forge.
6. Le second <ItemLink id="import_bus" /> extrait 1 modèle de forge.
7. Le premier bus de stockage a une priorité plus élevée, donc ce modèle de forge retourne dans l'assembleur.
8. Le second <ItemLink id="import_bus" /> extrait 1 modèle de forge.
9. L'assembleur ne peut pas recevoir un autre modèle de forge, donc le second modèle part vers le bus de stockage de priorité inférieure, qui l'insère dans l'interface.
10. L'<ItemLink id="interface" />, qui n'est pas configurée pour stocker des modèles de forge, l'insère dans le réseau.
