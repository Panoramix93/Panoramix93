---
navigation:
  parent: example-setups/example-setups-index.md
  title: Remplisseur de seaux
  icon: minecraft:water_bucket
---

# Remplisseur de seaux

Voyez aussi [Videur de seaux](bucket-emptier.md).

Notez que, comme cette installation utilise un <ItemLink id="pattern_provider" />, elle est destinée à s'intégrer à votre installation de
[fabrication automatique](../ae2-mechanics/autocrafting.md).

Parfois, la vie est mal faite et vous avez besoin de seaux de fluide plutôt que du fluide lui-même. Une machine peut parfois le faire pour vous
(comme le Fluid Transposer de Thermal Expansion), mais vous n'avez pas toujours un mod qui s'en charge commodément. Heureusement,
Minecraft vanilla propose une méthode un peu moins commode : le <ItemLink id="minecraft:dispenser" />.

**Notez que vous n'avez souvent pas besoin de faire ça, car les substitutions de fluides dans un
[terminal d'encodage de patterns](../items-blocks-machines/terminals.md#pattern-encoding-terminal) permettent d'utiliser le fluide lui-même dans
une recette de fabrication au lieu d'un seau.**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/bucket_filler.snbt" />

<BoxAnnotation color="#dddddd" min="2 1 0" max="3 2 1">
        (1) Fournisseur de pattern : verrouillage de fabrication réglé sur « Avec un signal de redstone », avec les patterns de traitement correspondants.

        <Row>
        ![Pattern de remplissage](../assets/diagrams/water_fill_pattern_small.png)
        ![Pattern de remplissage](../assets/diagrams/lava_fill_pattern_small.png)
        </Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1.1 0.1" max="3.2 1.9 0.9">
        (2) Interface : dans sa configuration par défaut.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.1 1.1 0.8" max="3.9 1.9 1">
        (3) Bus de stockage ME n° 1 : dans sa configuration par défaut.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="4.05 1.05 0.8" max="4.95 1.95 1">
        (4) Plan de formation : filtré pour exclure les seaux, à l'aide d'une carte d'inversion.
        <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.2 2 1.2" max="3.8 2.2 1.8">
        (5) Bus d'importation ME : filtré pour exclure les seaux, à l'aide d'une carte d'inversion.
        <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2.1 2 0.1" max="2.9 2.2 0.9">
        (6) Bus de stockage ME n° 2 : dans sa configuration par défaut.
  </BoxAnnotation>

<DiamondAnnotation pos="0 1.5 0.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="225" pitch="45" />
</GameScene>

## Configurations

* Le <ItemLink id="pattern_provider" /> (1) a son verrouillage de fabrication réglé sur « Avec un signal de redstone », avec les <ItemLink id="processing_pattern" /> correspondants.

    ![Pattern du chargeur](../assets/diagrams/water_fill_pattern.png)
    ![Pattern du chargeur](../assets/diagrams/lava_fill_pattern.png)

* L'<ItemLink id="interface" /> (2) est dans sa configuration par défaut.
* Le premier <ItemLink id="storage_bus" /> (3) est dans sa configuration par défaut.
* Le <ItemLink id="formation_plane" /> (4) est filtré pour exclure les seaux, à l'aide d'une carte d'inversion.
  <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
* Le <ItemLink id="import_bus" /> (5) est filtré pour exclure les seaux, à l'aide d'une carte d'inversion.
  <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
* Le second <ItemLink id="storage_bus" /> (6) est dans sa configuration par défaut.

## Fonctionnement

1. Le <ItemLink id="pattern_provider" /> pousse les ingrédients dans l'<ItemLink id="interface" />.
   (En réalité, par optimisation, il pousse directement à travers le bus de stockage et le plan de formation comme s'ils étaient des extensions de ses propres faces. Les objets n'entrent jamais vraiment dans l'interface.)
2. Par les mécanismes décrits dans [sous-réseaux en tuyau](pipe-subnet.md#providing-to-multiple-places) et <ItemLink id="formation_plane" />,
   le seau finit dans le <ItemLink id="minecraft:dispenser" /> et le fluide est placé par le plan de formation.
3. Le <ItemLink id="minecraft:comparator" /> détecte le seau dans le distributeur et alimente donc simultanément le distributeur et verrouille
   le <ItemLink id="pattern_provider" />.
4. Le distributeur ramasse le fluide avec le seau, il contient maintenant un seau rempli.
5. Le <ItemLink id="import_bus" /> extrait le seau rempli du distributeur et le range à travers le
   <ItemLink id="storage_bus" /> dans le fournisseur de pattern, ce qui le renvoie au réseau principal.
6. Le comparateur voit que le distributeur est vide, ce qui déverrouille le fournisseur.
