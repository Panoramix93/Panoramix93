---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automatisation du four
  icon: minecraft:furnace
---

# Automatisation du four

Notez que, puisque ce montage utilise un <ItemLink id="pattern_provider" />, il est destiné à s'intégrer à votre installation de
[fabrication automatique](../ae2-mechanics/autocrafting.md). Si vous voulez seulement automatiser un four de façon autonome, utilisez des entonnoirs, des coffres, etc.

L'automatisation d'un <ItemLink id="minecraft:furnace" /> est un peu plus complexe que celle de machines plus simples comme le [chargeur](../example-setups/charger-automation.md).
Un four exige une entrée sur deux faces différentes et une extraction sur une troisième. L'objet à fondre doit être poussé par la face du dessus,
le combustible doit être poussé par une face latérale et le résultat doit être retiré par le dessous. 

On pourrait le faire avec un <ItemLink id="pattern_provider" />
sur le dessus, un <ItemLink id="export_bus" /> sur le côté pour pousser du combustible en continu et un <ItemLink id="import_bus" /> en
dessous pour importer les résultats dans le réseau. Cela consomme toutefois 3 [canaux](../ae2-mechanics/channels.md).

Voici comment faire avec un seul canal :

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Fournisseur de modèles : la variante directionnelle, obtenue avec une clé en quartz de certus, avec les modèles de traitement voulus.

        ![Iron Pattern](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (2) Interface : dans sa configuration par défaut.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        (3) Bus de stockage ME n° 1 : filtré sur le charbon.
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        (4) Bus de stockage ME n° 2 : filtré pour exclure le charbon, à l'aide d'une carte d'inversion.
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurations

* Le <ItemLink id="pattern_provider" /> (1) est dans sa configuration par défaut, avec les <ItemLink id="processing_pattern" /> voulus.
    Il est rendu directionnel en utilisant une <ItemLink id="certus_quartz_wrench" /> dessus.

  ![Iron Pattern](../assets/diagrams/furnace_pattern.png)

* L'<ItemLink id="interface" /> (2) est dans sa configuration par défaut.
* Le premier <ItemLink id="storage_bus" /> (3) est filtré sur le charbon, ou sur le combustible que vous voulez utiliser.
* Le second <ItemLink id="storage_bus" /> (4) est filtré pour exclure le combustible que vous utilisez, à l'aide d'une <ItemLink id="inverter_card" />.

## Fonctionnement

1. Le <ItemLink id="pattern_provider" /> pousse les ingrédients dans l'<ItemLink id="interface" />.
   (En réalité, par optimisation, il les pousse directement à travers les bus de stockage comme s'ils étaient des extensions des faces du fournisseur. Les objets n'entrent jamais vraiment dans l'interface.)
2. L'interface est réglée pour ne rien stocker : elle tente donc de pousser les ingrédients dans le [stockage du réseau](../ae2-mechanics/import-export-storage.md).
3. Le seul stockage du sous-réseau vert est constitué des <ItemLink id="storage_bus" />. Le bus filtré sur le charbon place le charbon dans l'emplacement de combustible du four par la face latérale.
    Le bus filtré sur « tout sauf le charbon » place les objets à fondre dans l'emplacement du haut, par la face supérieure.
4. Le four fait son travail de four
5. L'entonnoir retire les résultats par le dessous du four et les place dans les emplacements de retour du fournisseur, ce qui les renvoie vers le réseau principal.
