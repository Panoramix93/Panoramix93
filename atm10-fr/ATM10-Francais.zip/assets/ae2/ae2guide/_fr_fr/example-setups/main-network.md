---
navigation:
  parent: example-setups/example-setups-index.md
  title: Un exemple de « réseau principal »
  icon: controller
---

# Un exemple de « réseau principal »

De nombreuses autres installations font référence à un « réseau principal ». Vous vous demandez peut-être aussi comment tous ces [appareils](../ae2-mechanics/devices.md) s'assemblent
pour former un système fonctionnel. En voici un exemple :

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/small_base_network.snbt" />

    <BoxAnnotation color="#33dd33" min="5 1 10" max="9 7 14" thickness="0.05">
        Un grand groupe de fournisseurs de modèles et d'assembleurs offre beaucoup de place pour les modèles de fabrication, de taille de pierre et de forge.
        La disposition en damier permet aux fournisseurs d'utiliser plusieurs assembleurs en parallèle tout en restant compact.
        Les groupes de 8 rendent tout mauvais routage des canaux impossible.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 10 12" max="14 11 14" thickness="0.05">
        Vous n'avez pas vraiment besoin d'un contrôleur aussi gros ; tous ces immenses anneaux et cubes que vous voyez dans les bases des autres
        servent surtout à faire joli.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 12 13" max="14 13 14" thickness="0.05">
        Tout bon réseau possède une cellule d'énergie, pour accepter une entrée d'énergie plus élevée par tick de jeu et
        lisser les variations de courant.
    </BoxAnnotation>
    
    <BoxAnnotation color="#33dd33" min="2 1 10" max="4 4 13" thickness="0.05">
        Vous voudrez probablement utiliser la source d'énergie d'un autre mod : un réacteur, un panneau solaire, un générateur ou
        autre. Les chambres à vibration font l'affaire, mais AE2 est conçu pour être utilisé dans un modpack et tirer parti
        du générateur principal de votre base.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="15 1 9" max="16 3 14" thickness="0.05">
        Les façades permettent de cacher des éléments derrière les murs.
    </BoxAnnotation>
    <BoxAnnotation color="#33dd33" min="15 3 12" max="16 10 14" thickness="0.05">
        Les façades permettent de cacher des éléments derrière les murs.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 9 7" max="14 10 9" thickness="0.05">
        Vous n'avez pas besoin d'autant de baies de range-disque et de disques pour votre stockage général : de quoi remplir 2 à 4 range-disques ME
        de disques 4k ou 16k suffit presque toujours.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 9 10" max="14 11 11" thickness="0.05">
        Pour le stockage en masse, utilisez de gros disques filtrés sur des objets précis, dans des range-disques ME séparés réglés sur une priorité
        plus élevée.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="10 9 13" max="11.7 13 14" thickness="0.05">
        Approvisionnement automatique à base d'interfaces.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="6 10 12" max="9 12 15" thickness="0.05">
        L'extension logique de l'automatisation du chargeur à plusieurs chargeurs.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="2 10 12" max="5 11 15" thickness="0.05">
        Une autre façon d'automatiser les processeurs, puisque les graveurs peuvent désormais éjecter automatiquement leur résultat depuis la 1.20.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="3 10 10" max="4 12 11" thickness="0.05">
        Une autre façon d'automatiser les processeurs, puisque les graveurs peuvent désormais éjecter automatiquement leur résultat depuis la 1.20.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="7.2 9.2 8.2" max="7.8 10 8.8" thickness="0.05">
        Le point d'accès sans fil est placé au centre, car sa portée est sphérique.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="14 1 2" max="16 5 7" thickness="0.05">
        En général, vous aurez 1 ou 2 gros CPU de fabrication pour les grosses tâches et quelques plus petits pour traiter les tâches
        secondaires pendant que les gros CPU sont occupés.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="5 3 6" max="6 4 7" thickness="0.05">
        Il arrive qu'un sous-réseau ait besoin de son propre contrôleur s'il comporte plus de 8 appareils (par exemple pour distribuer vers plus
        de 8 endroits).
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="7.3 1 3.3" max="9.7 4 6" thickness="0.05">
        Ferme de certus.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="10.3 1 2.3" max="12.7 3.7 5" thickness="0.05">
        Automatisation par jet dans l'eau.
    </BoxAnnotation>

  <IsometricCamera yaw="135" pitch="15" />
</GameScene>
