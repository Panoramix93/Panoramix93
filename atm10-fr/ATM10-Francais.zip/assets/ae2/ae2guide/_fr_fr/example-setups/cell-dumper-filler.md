---
navigation:
  parent: example-setups/example-setups-index.md
  title: Videur ou remplisseur de disque
  icon: io_port
---

# Videur ou remplisseur de disque

On peut se demander : « Comment vider rapidement un disque dans un coffre, un ensemble de tiroirs ou un sac à dos, ou inversement le remplir depuis l'un d'eux ? »

La réponse consiste à utiliser un <ItemLink id="io_port" /> et un peu de sous-réseau pour restreindre l'endroit où il peut déposer les objets, ou d'où il peut les extraire.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/cell_dumper_filler.snbt" />

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 1">
        (1) Port d'E/S ME : peut être réglé sur « Transférer les données vers le réseau » ou « Transférer les données vers le disque de stockage » à l'aide du bouton fléché
        au milieu de l'interface. Contient 3 cartes d'accélération.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0.7 0" max="1 1 1">
        (2) Bus de stockage ME : dans sa configuration par défaut.
  </BoxAnnotation>

<BoxAnnotation color="#33dd33" min="0 1 0" max="1 2 1">
        Placez ici ce que vous voulez remplir ou vider.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0.35 0.35" max="2.3 0.65 0.65">
        Fibre de quartz : nécessaire uniquement si la source d'énergie est un autre réseau.
  </BoxAnnotation>

<DiamondAnnotation pos="3 0.5 0.5" color="#00ff00">
        Vers une source d'énergie, comme un autre réseau ou un accepteur d'énergie.
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurations

* Le <ItemLink id="io_port" /> (1) peut être réglé sur « Transférer les données vers le réseau » ou « Transférer les données vers le disque de stockage » à l'aide du bouton fléché
  au milieu de l'interface. Il contient 3 cartes d'accélération pour une vitesse maximale.
* Le <ItemLink id="storage_bus" /> (2) est dans sa configuration par défaut.

## Fonctionnement

### En mode « Transférer vers le réseau »

1. Le <ItemLink id="io_port" /> tente de déverser le contenu du [disque de stockage](../items-blocks-machines/storage_cells.md) inséré
    dans le [stockage du réseau](../ae2-mechanics/import-export-storage.md).
2. Le seul stockage du sous-réseau est le <ItemLink id="storage_bus" />, qui place les objets, fluides ou autres dans ce que
    vous avez posé devant lui.
* La <ItemLink id="energy_cell" /> fournit une réserve d'[énergie](../ae2-mechanics/energy.md) suffisante pour que le réseau ne tombe
    pas en panne sous la consommation liée au transfert d'autant d'objets par tick de jeu.

### En mode « Transférer vers le disque de stockage »

1. Le <ItemLink id="io_port" /> tente de déverser le contenu du [stockage du réseau](../ae2-mechanics/import-export-storage.md)
   dans le [disque de stockage](../items-blocks-machines/storage_cells.md) inséré.
2. Le seul stockage du sous-réseau est le <ItemLink id="storage_bus" />, qui extrait les objets, fluides ou autres de ce que
   vous avez posé devant lui.
* La <ItemLink id="energy_cell" /> fournit une réserve d'[énergie](../ae2-mechanics/energy.md) suffisante pour que le réseau ne tombe
  pas en panne sous la consommation liée au transfert d'autant d'objets par tick de jeu.
