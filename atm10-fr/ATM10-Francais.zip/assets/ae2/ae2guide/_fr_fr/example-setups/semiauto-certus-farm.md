---
navigation:
  parent: example-setups/example-setups-index.md
  title: Ferme de Certus semi-automatique
  icon: certus_quartz_crystal
  position: 115
---

# Ferme de Certus semi-automatique

Malheureusement, la [ferme de Certus simple](simple-certus-farm.md) nécessite un <ItemLink id="flawless_budding_quartz" /> pour fonctionner de manière
entièrement automatique. Cela demande soit le [Spatial IO](../ae2-mechanics/spatial-io.md), soit de construire la ferme sur place, à la [météorite](../ae2-mechanics/meteorites.md).

Cependant, AE2 sait placer et casser des blocs, il est donc peut-être
possible de faire en sorte que votre ferme *remplace elle-même le certus bourgeonnant*. (Vous devrez insérer périodiquement des
<ItemLink id="flawed_budding_quartz" /> dans le tonneau d'entrée et extraire les <ItemLink id="quartz_block" /> du tonneau de
certus bourgeonnant épuisé.)

Pour y parvenir de façon totalement automatique, voyez la [ferme de Certus avancée](advanced-certus-farm.md).

Cette ferme est un peu plus complexe que la [ferme de Certus simple](simple-certus-farm.md), car il s'agit en réalité de
3 installations distinctes entassées ensemble.

Voyez [Croissance du Certus](../ae2-mechanics/certus-growth.md) pour une estimation des vitesses.

**CETTE CONSTRUCTION EST COMPLEXE ET CERTAINS ÉLÉMENTS SONT CACHÉS DERRIÈRE D'AUTRES, TOURNEZ AUTOUR POUR LA VOIR SOUS TOUS LES ANGLES**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/semiauto_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
        (1) Plan d'annihilation n° 1 : aucune interface à configurer, mais il peut être enchanté avec Fortune.
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1" max="2.3 3 2">
        (2) Bus de stockage ME n° 1 : filtré sur le cristal de quartz Certus.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
    Sous-réseau casseur de grappes
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
        (3) Plan d'annihilation n° 2 : aucune interface à configurer, mais enchanté avec Toucher de soie.
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1" max="2.3 2 2">
        (4) Bus de stockage ME n° 2 : filtré sur le bloc de quartz Certus.
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
    Sous-réseau casseur de blocs de Certus
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
        (5) Plan de formation : dans sa configuration par défaut.
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0 1" max="2.3 1 2">
        (6) Bus d'importation ME : dans sa configuration par défaut.
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
    Sous-réseau placeur de blocs bourgeonnants
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="0.7 2 1" max="1 3 2">
        (7) Bus de stockage ME n° 3 : filtré sur le cristal de quartz Certus. Sa priorité est réglée plus haut que celle de votre stockage principal.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

    <DiamondAnnotation pos="1.5 0.5 1.5" color="#00ff00">
        Insérez manuellement du quartz Certus bourgeonnant imparfait.
        <BlockImage id="flawed_budding_quartz" scale="2" />
    </DiamondAnnotation>

    <DiamondAnnotation pos="1.5 1.5 1.5" color="#00ff00">
        Extrayez manuellement les blocs de quartz Certus.
        <BlockImage id="quartz_block" scale="2" />
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## Configurations

### Casseur de grappes :

* Le premier <ItemLink id="annihilation_plane" /> (1) n'a pas d'interface et ne peut pas être configuré, mais il peut être enchanté avec Fortune.
* Le premier <ItemLink id="storage_bus" /> (2) est filtré sur le <ItemLink id="certus_quartz_crystal" />.

### Casseur de blocs de Certus :

* Le second <ItemLink id="annihilation_plane" /> (3) n'a pas d'interface et ne peut pas être configuré, mais il doit être enchanté avec Toucher de soie.
* Le second <ItemLink id="storage_bus" /> (4) est filtré sur le <ItemLink id="quartz_block" />.

### Placeur de blocs bourgeonnants :

* Le <ItemLink id="formation_plane" /> (5) est dans sa configuration par défaut.
* Le <ItemLink id="import_bus" /> (6) est dans sa configuration par défaut.

### Sur le réseau principal :

* Le troisième <ItemLink id="storage_bus" /> (7) est filtré sur le <ItemLink id="certus_quartz_crystal" />, et sa
  [priorité](../ae2-mechanics/import-export-storage.md#storage-priority) est réglée plus haut que celle de votre stockage principal.

## Fonctionnement

### Casseur de grappes :

Le sous-réseau casseur de grappes fonctionne de façon très semblable à celui de la [ferme de Certus simple](simple-certus-farm.md).

1. Le <ItemLink id="annihilation_plane" /> tente de casser ce qui se trouve devant lui, mais il ne peut casser que les <ItemLink id="quartz_cluster" />
   car le seul stockage du sous-réseau est le <ItemLink id="storage_bus" />, filtré sur le <ItemLink id="certus_quartz_crystal" />.
2. Le <ItemLink id="storage_bus" /> range les cristaux de quartz Certus dans le tonneau.

### Casseur de blocs de Certus

Le sous-réseau casseur de blocs de Certus sert à casser le bloc bourgeonnant épuisé dès qu'il se transforme en simple <ItemLink id="quartz_block" />.
Il fonctionne comme le casseur de grappes.

1. Le <ItemLink id="annihilation_plane" /> tente de casser ce qui se trouve devant lui, mais il ne peut casser que les <ItemLink id="quartz_block" />
   car le seul stockage du sous-réseau est le <ItemLink id="storage_bus" />, filtré sur le <ItemLink id="quartz_block" />.
   Le plan doit avoir Toucher de soie, pour que le bloc bourgeonnant ne se dégrade pas en étant cassé, et donc que le plan ne le casse pas prématurément.
2. Le <ItemLink id="storage_bus" /> range le bloc de quartz Certus dans le tonneau de
   certus bourgeonnant épuisé ; vous devrez le jeter manuellement dans l'eau avec des <ItemLink id="charged_certus_quartz_crystal" /> pour le régénérer.

### Placeur de blocs bourgeonnants

Le sous-réseau placeur de blocs bourgeonnants sert à placer un nouveau <ItemLink id="flawed_budding_quartz" /> quand le sous-réseau casseur détruit l'ancien, épuisé.

1. Le <ItemLink id="import_bus" /> importe un bloc bourgeonnant depuis le tonneau d'entrée.
2. Le seul stockage du sous-réseau est le <ItemLink id="formation_plane" />, qui place le bloc bourgeonnant.

### Sur le réseau principal

* Le <ItemLink id="storage_bus" /> donne au réseau principal (et aussi à l'[automatisation du chargeur](charger-automation.md)) accès à tous les cristaux de quartz Certus du tonneau. Il est réglé sur une
  [priorité](../ae2-mechanics/import-export-storage.md#storage-priority) élevée afin que les cristaux de quartz Certus soient de préférence
  remis dans le tonneau plutôt que dans votre stockage principal.