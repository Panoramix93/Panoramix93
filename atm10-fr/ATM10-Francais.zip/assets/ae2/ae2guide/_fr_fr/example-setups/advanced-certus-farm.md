---
navigation:
  parent: example-setups/example-setups-index.md
  title: Ferme de certus avancée
  icon: certus_quartz_crystal
  position: 120
---

# Ferme de certus avancée

Il s'agit tout simplement de la [Ferme de certus semi-automatique](semiauto-certus-farm.md), à ceci près qu'elle a été entièrement intégrée à
votre système ME.

Au lieu de garder un gros stock de blocs bourgeonnants et de les renouveler à la main de temps en temps,
cette installation utilise l'[Automatisation du chargeur](charger-automation.md) et l'[Automatisation du jet dans l'eau](throw-in-water-automation.md)
pour le faire automatiquement.

Voir [Croissance du certus](../ae2-mechanics/certus-growth.md) pour une estimation des vitesses.

**IL S'AGIT D'UNE CONSTRUCTION COMPLEXE OÙ CERTAINS ÉLÉMENTS SONT CACHÉS DERRIÈRE D'AUTRES, TOURNEZ AUTOUR POUR LA VOIR SOUS TOUS LES ANGLES**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/advanced_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
        (1) Plan d'annihilation n°1 : pas d'interface à configurer, mais peut être enchanté avec Fortune.
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1.7" max="3 3 2">
        (2) Bus de stockage n°1 : filtré sur le cristal de quartz certus.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
    Sous-réseau casseur de grappes
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
        (3) Plan d'annihilation n°2 : pas d'interface à configurer, mais enchanté avec Toucher de soie.
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1.7" max="3 2 2">
        (4) Bus de stockage n°2 : filtré sur le bloc de quartz certus.
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
    Sous-réseau casseur de blocs de certus
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
        (5) Plan de formation : dans sa configuration par défaut.
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0.7 2" max="3 1 3">
        (6) Bus d'importation : filtré sur le quartz certus bourgeonnant imparfait.
        <BlockImage id="flawed_budding_quartz" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
    Sous-réseau poseur de blocs bourgeonnants
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="1.7 2 2" max="2 3 3">
        (7) Bus de stockage n°3 : filtré sur le cristal de quartz certus. Sa priorité est plus élevée que celle de votre stockage principal.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#aaaadd" min="2 1 2" max="3 2 3">
        (8) Interface : réglée pour conserver 1 quartz certus bourgeonnant imparfait en elle, équipée d'une carte de fabrication.
        <Row><BlockImage id="flawed_budding_quartz" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="1.5 0.5 0" color="#00ff00">
        Vers le réseau principal, l'Automatisation du chargeur et l'Automatisation du jet dans l'eau
        <Row>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/charger_automation.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        <GameScene zoom="3" background="transparent">
          <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />
          <IsometricCamera yaw="195" pitch="30" />
        </GameScene>
        </Row>
    </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## Configurations

### Casseur de grappes :

* Le premier <ItemLink id="annihilation_plane" /> (1) n'a pas d'interface et ne peut pas être configuré, mais il peut être enchanté avec Fortune.
* Le premier <ItemLink id="storage_bus" /> (2) est filtré sur le <ItemLink id="certus_quartz_crystal" />.

### Casseur de blocs de certus :

* Le second <ItemLink id="annihilation_plane" /> (3) n'a pas d'interface et ne peut pas être configuré, mais il doit être enchanté avec Toucher de soie.
* Le second <ItemLink id="storage_bus" /> (4) est filtré sur le <ItemLink id="quartz_block" />.

### Poseur de blocs bourgeonnants :

* Le <ItemLink id="formation_plane" /> (5) est dans sa configuration par défaut.
* Le <ItemLink id="import_bus" /> (6) est filtré sur le <ItemLink id="flawed_budding_quartz" />.

### Sur le réseau principal :

* Le troisième <ItemLink id="storage_bus" /> (7) est filtré sur le <ItemLink id="certus_quartz_crystal" />, et sa
  [priorité](../ae2-mechanics/import-export-storage.md#storage-priority) est plus élevée que celle de votre stockage principal.
* L'<ItemLink id="interface" /> (8) est réglée pour conserver 1 quartz certus bourgeonnant imparfait en elle, et est équipée d'une <ItemLink id="crafting_card" />.

## Comment ça marche

### Casseur de grappes :

Le sous-réseau casseur de grappes fonctionne à peu près comme le sous-réseau de la [ferme de certus simple](simple-certus-farm.md).

1. Le <ItemLink id="annihilation_plane" /> essaie de casser ce qui se trouve devant lui, mais il ne peut casser que les <ItemLink id="quartz_cluster" />
   car le seul stockage du sous-réseau est le <ItemLink id="storage_bus" />, filtré sur le <ItemLink id="certus_quartz_crystal" />.
2. Le <ItemLink id="storage_bus" /> stocke les cristaux de quartz certus dans le baril.

### Casseur de blocs de certus

Le sous-réseau casseur de blocs de certus sert à casser le bloc bourgeonnant épuisé lorsqu'il devient un simple <ItemLink id="quartz_block" />.
Il fonctionne comme le casseur de grappes.

1. Le <ItemLink id="annihilation_plane" /> essaie de casser ce qui se trouve devant lui, mais il ne peut casser que le <ItemLink id="quartz_block" />
   car le seul stockage du sous-réseau est le <ItemLink id="storage_bus" />, filtré sur le <ItemLink id="quartz_block" />. 
   Le plan doit avoir Toucher de soie, afin que le bloc bourgeonnant ne se dégrade pas quand il est cassé, et donc que le plan ne le casse pas prématurément.
2. Le <ItemLink id="storage_bus" /> stocke le bloc de quartz certus dans l'<ItemLink id="interface" />, ce qui permet à
   l'[Automatisation du jet dans l'eau](throw-in-water-automation.md) de s'en servir pour fabriquer un nouveau <ItemLink id="flawed_budding_quartz" />.

### Poseur de blocs bourgeonnants

Le sous-réseau poseur de blocs bourgeonnants sert à poser un nouveau <ItemLink id="flawed_budding_quartz" /> quand le sous-réseau casseur casse l'ancien, épuisé.

1. Le <ItemLink id="import_bus" /> importe un bloc bourgeonnant depuis l'<ItemLink id="interface" /> vers le [stockage du réseau](../ae2-mechanics/import-export-storage.md)
2. Le seul stockage du sous-réseau est le <ItemLink id="formation_plane" />, qui pose le bloc bourgeonnant.

### Sur le réseau principal

* Le <ItemLink id="storage_bus" /> donne au réseau principal (et aussi à l'[Automatisation du chargeur](charger-automation.md)) accès à tous les cristaux de quartz certus du baril. Sa
  [priorité](../ae2-mechanics/import-export-storage.md#storage-priority) est élevée afin que les cristaux de quartz certus soient
  remis en priorité dans le baril plutôt que dans votre stockage principal.
* L'<ItemLink id="interface" /> donne au sous-réseau poseur de blocs bourgeonnants accès à un <ItemLink id="flawed_budding_quartz" />, et
    donne au sous-réseau casseur de blocs de certus un moyen de renvoyer les blocs épuisés vers le réseau principal. La
    <ItemLink id="crafting_card" /> permet à l'interface de demander de nouveaux blocs bourgeonnants à la [fabrication automatique](../ae2-mechanics/autocrafting.md) du réseau principal.
