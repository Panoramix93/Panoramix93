---
navigation:
  parent: example-setups/example-setups-index.md
  title: Mise en stock automatique par émetteur de niveau
  icon: level_emitter
---

# Mise en stock automatique par émetteur de niveau

On peut se demander « comment maintenir en stock une certaine quantité d'un objet, en en fabriquant davantage au besoin ? »

Une solution consiste à utiliser un <ItemLink id="export_bus" />, un <ItemLink id="level_emitter" /> et une <ItemLink id="crafting_card" /> pour demander automatiquement de nouveaux objets
à la [fabrication automatique](../ae2-mechanics/autocrafting.md) de votre réseau. Cette installation sert à maintenir une grande quantité d'un seul objet.

Vous pouvez bien sûr faire fabriquer votre réseau en continu, en omettant l'émetteur de niveau et la carte de redstone.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/level_emitter_autostocking.snbt" />

  <BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (1) Bus d'exportation : filtré sur l'objet souhaité. Équipé d'une carte de redstone et d'une carte de fabrication. Mode redstone réglé sur
        « Actif avec un signal », comportement de fabrication réglé sur « Ne pas utiliser les objets en stock ».
        <Row><ItemImage id="redstone_card" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0.7 1 0" max="1 2 1">
        (2) Émetteur de niveau : configuré avec l'objet et la quantité souhaités, réglé sur « Émettre quand le niveau est sous la limite ».
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (3) Interface : dans sa configuration par défaut.
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurations

* Le <ItemLink id="export_bus" /> (1) est filtré sur l'objet souhaité. Il est équipé d'une <ItemLink id="redstone_card" /> et d'une <ItemLink id="crafting_card" />.
  Le « mode redstone » est réglé sur « Actif avec un signal », le « comportement de fabrication » est réglé sur « Ne pas utiliser les objets en stock ».
* Le <ItemLink id="level_emitter" /> (2) est configuré avec l'objet et la quantité souhaités, et réglé sur « Émettre quand le niveau est sous la limite ».
* L'<ItemLink id="interface" /> (3) est dans sa configuration par défaut.

## Fonctionnement

1. Si la quantité de l'objet souhaité dans le [stockage réseau](../ae2-mechanics/import-export-storage.md) est inférieure à la quantité indiquée dans l'
   <ItemLink id="level_emitter" />, celui-ci émet un signal de redstone.
2. En recevant ce signal de redstone (et grâce à la <ItemLink id="crafting_card" /> et au réglage « ne pas utiliser les objets en stock »),
   le <ItemLink id="export_bus" /> demande à la [fabrication automatique](../ae2-mechanics/autocrafting.md) du réseau de produire
   davantage de l'objet souhaité, puis l'exporte.
3. Lorsqu'un objet y est inséré (et comme elle n'est pas configurée pour conserver quoi que ce soit dans son inventaire interne), l'<ItemLink id="interface" /> renvoie cet objet vers le stockage réseau.
