---
navigation:
  parent: example-setups/example-setups-index.md
  title: Automatisation du chargeur
  icon: charger
---

# Automatisation du chargeur

Notez que, comme cette installation utilise un <ItemLink id="pattern_provider" />, elle est destinée à s'intégrer à votre installation de
[fabrication automatique](../ae2-mechanics/autocrafting.md). Si vous voulez simplement automatiser un <ItemLink id="charger" /> de façon autonome, utilisez des entonnoirs, des coffres et compagnie.

L'automatisation d'un <ItemLink id="charger" /> est assez simple. Un <ItemLink id="pattern_provider" /> pousse l'ingrédient dans le chargeur, puis un [sous-réseau en tuyau](pipe-subnet.md)
ou un autre tuyau à objets renvoie le résultat dans le fournisseur.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/charger_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Fournisseur de pattern : dans sa configuration par défaut, avec les patterns de traitement correspondants. Il alimente aussi le chargeur en énergie.

        ![Pattern du chargeur](../assets/diagrams/charger_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="1 1.3 1">
        (2) Bus d'importation ME : dans sa configuration par défaut.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (3) Bus de stockage ME : dans sa configuration par défaut.
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurations

* Le <ItemLink id="pattern_provider" /> (1) est dans sa configuration par défaut, avec les <ItemLink id="processing_pattern" /> correspondants.
  Il fournit aussi au <ItemLink id="charger" /> de l'[énergie](../ae2-mechanics/energy.md) car il se comporte comme un [câble](../items-blocks-machines/cables.md).

    ![Pattern du chargeur](../assets/diagrams/charger_pattern.png)

* Le <ItemLink id="import_bus" /> (2) est dans sa configuration par défaut.
* Le <ItemLink id="storage_bus" /> (3) est dans sa configuration par défaut.

## Fonctionnement

1. Le <ItemLink id="pattern_provider" /> pousse les ingrédients dans le <ItemLink id="charger" />.
2. Le chargeur fait son travail de charge.
3. Le <ItemLink id="import_bus" /> du sous-réseau vert extrait le résultat du chargeur et tente de le ranger dans le
   [stockage du réseau](../ae2-mechanics/import-export-storage.md).
4. Le seul stockage du sous-réseau vert est le <ItemLink id="storage_bus" />, qui range les objets obtenus dans le fournisseur de pattern, ce qui les renvoie au réseau principal.
