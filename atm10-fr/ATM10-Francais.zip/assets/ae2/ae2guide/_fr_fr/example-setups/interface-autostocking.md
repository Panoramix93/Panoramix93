---
navigation:
  parent: example-setups/example-setups-index.md
  title: Approvisionnement automatique par interface
  icon: interface
---

# Approvisionnement automatique par interface

On peut se demander : « Comment garder en stock une certaine quantité de différents objets, en en fabriquant davantage au besoin ? »

Une solution consiste à utiliser une <ItemLink id="interface" /> et une <ItemLink id="crafting_card" /> pour demander automatiquement de nouveaux objets
à l'[autofabrication](../ae2-mechanics/autocrafting.md) de votre réseau. Ce montage est plutôt adapté au maintien d'une petite quantité d'une grande
variété d'objets.

Ce montage de démonstration est volontairement raccourci pour ne pas être trop large ; il est probablement plus optimal d'utiliser 4 <ItemLink id="interface" /> et 4 <ItemLink id="storage_bus" />,
afin d'exploiter les 8 [canaux](../ae2-mechanics/channels.md) d'un [câble](../items-blocks-machines/cables.md) ordinaire.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_autostocking.snbt" />

<BoxAnnotation color="#dddddd" min="0 0 0" max="2 1 1">
        (1) Interfaces : réglées pour garder en elles les objets souhaités. Elles contiennent des cartes de fabrication.
        <ItemImage id="crafting_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="2 1.3 1">
        (2) Bus de stockage ME : « Mode d'entrée/sortie » réglé sur « Extraction uniquement ».
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurations

* Les <ItemLink id="interface" /> (1) sont réglées pour garder en elles les objets souhaités : cliquez l'objet voulu dans leurs
   emplacements du haut ou glissez-le depuis JEI dans ces emplacements, puis cliquez sur l'icône de clé au-dessus des emplacements pour régler la quantité. Elles contiennent des <ItemLink id="crafting_card" />.
* Les <ItemLink id="storage_bus" /> (2) sont réglés de sorte que le « Mode d'entrée/sortie » soit sur « Extraction uniquement ».

## Fonctionnement

1. Si une <ItemLink id="interface" /> ne parvient pas à récupérer assez d'un objet configuré depuis le [stockage du réseau](../ae2-mechanics/import-export-storage.md),
   (et qu'elle contient une <ItemLink id="crafting_card" />), elle demande à l'[autofabrication](../ae2-mechanics/autocrafting.md) du réseau de fabriquer davantage de cet objet.
2. Les <ItemLink id="storage_bus" /> permettent au réseau d'accéder au contenu des interfaces.
