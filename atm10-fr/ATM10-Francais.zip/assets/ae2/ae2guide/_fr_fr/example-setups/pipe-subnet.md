---
navigation:
  parent: example-setups/example-setups-index.md
  title: Sous-réseau "tuyau" pour objets/fluides
  icon: storage_bus
---

# Sous-réseau "tuyau" pour objets/fluides

Une méthode simple pour imiter un tuyau à objets et/ou à fluides avec les [appareils](../ae2-mechanics/devices.md) AE2, utile pour, eh bien, tout ce pour quoi vous utiliseriez un tuyau à objets ou à fluides.
Cela inclut le renvoi du résultat d'une fabrication vers un <ItemLink id="pattern_provider" />.

Il existe généralement deux méthodes différentes pour y parvenir :

## Bus d'importation -> Bus de stockage

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        (1) Bus d'importation : peut être filtré.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        (2) Bus de stockage : peut être filtré. Celui-ci (et les autres bus de stockage que vous voulez comme destination)
        doit être le seul stockage du réseau.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
        Source
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
        Destination
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Le <ItemLink id="import_bus" /> (1) posé sur l'inventaire source importe les objets ou le fluide et tente de les ranger dans le [stockage du réseau](../ae2-mechanics/import-export-storage.md).
Comme le seul stockage du réseau est le <ItemLink id="storage_bus" /> (2) (c'est pourquoi il s'agit d'un sous-réseau et non de votre réseau principal), les objets ou le fluide
sont placés dans l'inventaire de destination, et se trouvent donc transférés. L'énergie est fournie par une <ItemLink id="quartz_fiber" />.
Le bus d'importation et le bus de stockage peuvent tous les deux être filtrés, mais l'installation transférera tout ce à quoi elle a accès si aucun filtre n'est appliqué.
Cette installation fonctionne aussi avec plusieurs bus d'importation et plusieurs bus de stockage.

## Bus de stockage -> Bus d'exportation

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        (1) Bus de stockage : peut être filtré. Celui-ci (et les autres bus de stockage que vous voulez comme source)
        doit être le seul stockage du réseau.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        (2) Bus d'exportation : doit être filtré.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
        Source
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
        Destination
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Le <ItemLink id="export_bus" /> posé sur l'inventaire de destination tente de tirer du [stockage du réseau](../ae2-mechanics/import-export-storage.md) les objets présents dans son filtre.
Comme le seul stockage du réseau est le <ItemLink id="storage_bus" /> (c'est pourquoi il s'agit d'un sous-réseau et non de votre réseau principal), les objets ou le fluide
sont tirés de l'inventaire source, et se trouvent donc transférés. L'énergie est fournie par une <ItemLink id="quartz_fiber" />.
Comme les bus d'exportation doivent être filtrés pour fonctionner, cette installation ne fonctionne que si vous filtrez le bus d'exportation.
Cette installation fonctionne aussi avec plusieurs bus de stockage et plusieurs bus d'exportation.

## Une installation qui ne fonctionne pas (bus d'importation -> bus d'exportation)

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_export_pipe.snbt" />

<BoxAnnotation color="#dd3333" min="3.7 0 0" max="4 1 1">
        Bus d'importation : comme le réseau n'a aucun stockage, il n'a nulle part où importer.
  </BoxAnnotation>

<BoxAnnotation color="#dd3333" min="1 0 0" max="1.3 1 1">
        (2) Bus d'exportation : comme le réseau n'a aucun stockage, il n'a rien à exporter.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#ff0000">
        Source
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#ff0000">
        Destination
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Une installation composée uniquement d'un bus d'importation et d'un bus d'exportation ne fonctionnera pas. Le bus d'importation tentera de tirer de l'inventaire source
et de ranger les objets ou le fluide dans le stockage du réseau. Le bus d'exportation tentera de tirer du stockage du réseau et de placer les
objets ou le fluide dans l'inventaire de destination. Mais comme ce réseau **n'a aucun stockage**, le bus d'importation ne peut pas importer
et le bus d'exportation ne peut pas exporter, donc rien ne se passe.

## Entrée et sortie par une seule face

Imaginons que vous ayez une machine qui peut recevoir une entrée et dont la sortie peut être tirée par une seule face. (Comme un <ItemLink id="charger" />)
Vous pouvez à la fois pousser les ingrédients et récupérer le résultat en combinant les 2 méthodes de sous-réseau tuyau :

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="4 1 1" max="5 1.3 2">
        (1) Bus d'importation : peut être filtré.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        (2) Bus de stockage : peut être filtré. Celui-ci (et les autres bus de stockage dans lesquels vous voulez pousser et tirer des objets)
        doit être le seul stockage du réseau.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
        (3) Ce dans quoi vous voulez pousser et tirer : dans ce cas un chargeur.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 1" max="1 1.3 2">
        (4) Bus d'exportation : doit être filtré.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 1.5" color="#00ff00">
        Source
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 1.5" color="#00ff00">
        Destination
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Interfaces

Il se trouve qu'il existe d'autres [appareils](../ae2-mechanics/devices.md) que les bus d'importation et les bus d'exportation qui poussent des objets dans
le [stockage du réseau](../ae2-mechanics/import-export-storage.md) et en tirent des objets !
Celui qui nous intéresse ici est l'<ItemLink id="interface" />. Si un objet que l'interface n'est pas réglée pour stocker y est inséré, l'interface le
poussera vers le stockage du réseau, ce que nous pouvons exploiter de la même manière que le tuyau bus d'importation -> bus de stockage. Régler une interface pour
qu'elle stocke un objet le tirera du stockage du réseau, comme le tuyau bus de stockage -> bus d'exportation. Les interfaces peuvent être réglées pour
stocker certaines choses et pas d'autres, ce qui vous permet de pousser et de tirer à distance à travers des bus de stockage, si pour une raison quelconque vous voulez faire cela.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/interface_pipes.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        Interface
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        Bus de stockage
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.7 0 2" max="4 1 3">
        Bus de stockage
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 2" max="1 1.3 3">
        Interface
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Un-vers-plusieurs et plusieurs-vers-un (et plusieurs-vers-plusieurs)

Bien sûr, vous n'êtes pas obligé de n'utiliser qu'un seul <ItemLink id="import_bus" /> ou <ItemLink id="export_bus" /> ou <ItemLink id="storage_bus" />

<GameScene zoom="3" background="transparent">
<ImportStructure src="../assets/assemblies/many_to_many_pipe.snbt" />

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## Fournir à plusieurs endroits

De tout ceci, nous pouvons déduire une méthode pour envoyer les ingrédients d'une seule face de <ItemLink id="pattern_provider" /> vers de nombreux
endroits différents, comme un ensemble de machines, ou plusieurs faces d'une même machine.

Nous ne voulons pas d'un tuyau importation -> stockage ni d'un tuyau stockage -> exportation, car le <ItemLink id="pattern_provider" /> ne
contient jamais réellement les ingrédients. À la place, les fournisseurs *poussent* les ingrédients dans les inventaires adjacents, il nous faut donc un
inventaire adjacent qui sache aussi importer des objets.

Cela ressemble à... une <ItemLink id="interface" /> !
Assurez-vous que le fournisseur est en mode directionnel ou en mode sous-partie plate, et/ou que l'interface est en mode sous-partie plate, afin que les deux ne forment pas de
connexion réseau.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Interface (doit être plate, pas en bloc plein)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Bus de stockage
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        Endroits où vous voulez fournir vos patterns (plusieurs machines, ou plusieurs faces d'une même machine)
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>
