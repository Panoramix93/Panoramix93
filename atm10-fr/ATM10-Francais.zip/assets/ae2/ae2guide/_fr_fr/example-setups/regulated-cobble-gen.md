---
navigation:
  parent: example-setups/example-setups-index.md
  title: Générateur de pierre auto-régulé
  icon: minecraft:cobblestone
---

# Générateur de pierre auto-régulé

Automatiser un générateur de pierre est simple : il suffit d'orienter un <ItemLink id="annihilation_plane" /> vers un
générateur de pierre manuel vanilla classique. En procédant ainsi, vous finirez toutefois par saturer votre réseau de
pierre : une régulation est donc souhaitable.

À cause du fonctionnement des plans d'annihilation (ils se comportent comme des <ItemLink id="import_bus" />), nous ne
pouvons pas simplement placer un <ItemLink id="level_emitter" /> face à un <ItemLink id="export_bus" /> muni d'une
<ItemLink id="redstone_card" /> (puisqu'on ne peut pas aller directement de l'import à l'export sans stockage
intermédiaire). Il faut s'y prendre de façon un peu plus détournée.

Les <ItemLink id="toggle_bus" /> permettent de connecter et déconnecter des parties de votre réseau avec des signaux de
redstone, mais ils provoquent un redémarrage du réseau à chaque fois. Il existe une astuce simple : placer le bus
d'activation sur un [sous-réseau](../ae2-mechanics/subnetworks.md) pour qu'il ne redémarre que ce sous-réseau.

Nous pouvons faire en sorte qu'un [sous-réseau](../ae2-mechanics/subnetworks.md) autonome, composé d'un
<ItemLink id="annihilation_plane" /> et d'un <ItemLink id="storage_bus" />, pousse les objets dans une
<ItemLink id="interface" /> du réseau principal. Le bus d'activation connecte et déconnecte le sous-réseau d'une
<ItemLink id="quartz_fiber" />, ce qui coupe l'alimentation des plans.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/regulated_cobble_gen.snbt" />

<BoxAnnotation color="#dddddd" min="3 2 2" max="7 2.3 3">
        (1) Plans d'annihilation : aucune interface à configurer, mais ils peuvent être enchantés avec Efficacité et Solidité pour réduire leur consommation d'énergie.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 2" max="2.3 3 3">
        (2) Bus de stockage ME : dans sa configuration par défaut.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 2.3 2" max="2.7 2.7 2.3">
        (3) Bus d'activation : il est très important que le bus d'activation soit sur le
        sous-réseau, et non sur le réseau principal.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 2.3" max="2.7 3.3 2.7">
        (4) Émetteur de niveau : configuré avec de la pierre et la quantité souhaitée, réglé sur « Émettre quand le niveau est sous la limite ».
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 3" max="2 3 2">
        (5) Interface : dans sa configuration par défaut.
  </BoxAnnotation>

<DiamondAnnotation pos="0 2.5 1.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

<DiamondAnnotation pos="5 1.5 3.5" color="#00ff00">
        Les escaliers gorgés d'eau empêchent l'eau de couler et de transformer la lave en obsidienne.
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurations

* Les <ItemLink id="annihilation_plane" /> (1) n'ont aucune interface à configurer, mais peuvent être enchantés avec Efficacité et Solidité pour réduire leur consommation d'énergie.
* Le <ItemLink id="storage_bus" /> (2) est dans sa configuration par défaut.
* Le <ItemLink id="toggle_bus" /> (3) doit se trouver du côté sous-réseau de la fibre de quartz, et non sur le réseau
  principal, sinon le réseau principal redémarrera à chaque basculement.
* L'<ItemLink id="level_emitter" /> (4) est configuré avec l'objet et la quantité souhaités, et réglé sur « Émettre quand le niveau est sous la limite ».
* L'<ItemLink id="interface" /> (5) est dans sa configuration par défaut.

## Comment ça fonctionne

1. Le générateur de pierre produit de la pierre.
2. Les <ItemLink id="annihilation_plane" /> cassent la pierre. 
3. Le <ItemLink id="storage_bus" /> stocke la pierre dans l'<ItemLink id="interface" />, ce qui l'envoie dans le réseau principal.
4. Quand la quantité de pierre dans le réseau principal dépasse la valeur définie, l'<ItemLink id="level_emitter" />
   cesse d'émettre un signal, ce qui désactive le <ItemLink id="toggle_bus" />.
5. L'alimentation du sous-réseau est alors coupée, ce qui arrête le fonctionnement des plans d'annihilation.
