---
navigation:
  parent: example-setups/example-setups-index.md
  title: Types de stockage et propreté du réseau
  icon: drive
---

# Les différents types de stockage et comment garder un réseau bien rangé

Avec les filtres, les [partitions](../items-blocks-machines/cell_workbench.md) et la [priorité de stockage](../ae2-mechanics/import-export-storage.md#storage-priority),
vous pouvez mettre en place plusieurs niveaux de stockage pour différents types de contenus.

Les types de stockage sont généralement les suivants :
* Le stockage général, pour tout ce dont vous possédez de quelques unités à quelques milliers d'exemplaires. Il utilise de petits [disques](../items-blocks-machines/storage_cells.md),
du 4k ou du 16k par exemple.
* Le stockage en vrac, pour tout ce dont vous possédez plus de quelques milliers d'exemplaires, comme la pierre ou le fer. Il utilise de gros disques, du 256k
ou les disques de l'add-on MEGA.
* Le stockage local au niveau des fermes, comme décrit dans [Stockage local spécialisé](specialized-local-storage.md) et dans les
[différentes](simple-certus-farm.md) [fermes](semiauto-certus-farm.md) [de certus](advanced-certus-farm.md).

Les priorités sont réglées de telle sorte que, lorsque des objets sont déversés dans le réseau principal, celui-ci tente d'abord de les ranger dans le stockage
spécialisé (en vrac ou local) et, si ce n'est pas possible (à cause des filtres et des partitions), place alors les objets dans le stockage général.
Cela signifie que les objets NE SE DÉPLACERONT PAS ACTIVEMENT d'un stockage à l'autre, mais qu'ils « migreront » au fil de leurs entrées et sorties du réseau.
Pour déplacer activement des objets, utilisez un <ItemLink id="io_port" />.

<GameScene zoom="3" interactive={true}>
  <ImportStructure src="../assets/assemblies/network_storage_types.snbt" />

    <BoxAnnotation color="#33dd33" min="11 0 1" max="12 1.3 2" thickness="0.05">
        Stockage en vrac. Ici, un bus de stockage ME filtré sur un inventaire de grande capacité comme un casier. Ce bus de stockage est filtré sur
        le charbon. Il a une priorité élevée : chaque fois que du charbon entre dans le réseau, il part vers ce bus de stockage, et chaque fois que du charbon est
        retiré du réseau, il est pris *partout sauf ici*, de sorte que le charbon « migre » vers ce casier.

        REMARQUE IMPORTANTE : les gros inventaires optimisés comme les casiers conviennent très bien, mais les gros inventaires *non* optimisés comportant de nombreux emplacements, comme les
        coffres colossaux, sont désastreux pour les performances lorsqu'ils sont utilisés avec des bus de stockage.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="11 0 3" max="12 1 4" thickness="0.05">
        Stockage en vrac. Ici, un disque 256k partitionné, placé dans un range-disque de priorité élevée. Ce disque est partitionné sur
        la pierre et le fer. Il dispose d'une carte de répartition égale, ce qui évite qu'il soit entièrement rempli de pierre et qu'il ne reste
        plus de place pour le fer. Le range-disque a une priorité élevée : chaque fois que de la pierre ou du fer entre dans le réseau, cela part vers ce bus de stockage,
        et chaque fois que de la pierre ou du fer est retiré du réseau, c'est pris *partout sauf ici*, de sorte que la pierre et le fer « migrent » vers ce disque.
    </BoxAnnotation>

    <BoxAnnotation color="#33dddd" min="11 0 5" max="12 1 6" thickness="0.05">
        Stockage général. Ici, un range-disque rempli de disques 16k. Ces disques ne sont pas partitionnés. Le range-disque a une priorité neutre
        (0 dans ce cas) : chaque fois que quelque chose entre dans le réseau, cela part d'abord vers le stockage spécialisé, en vrac ou local,
        et chaque fois que quelque chose est retiré du réseau, c'est pris ici en premier, de sorte que les objets disposant d'un stockage spécialisé
        « migrent » naturellement hors du stockage général.
    </BoxAnnotation>

    <BoxAnnotation color="#88ff88" min="11 0 8" max="12 1 9" thickness="0.05">
        Ce port d'E/S joue un rôle important pour garder le réseau bien rangé. Comme la priorité de stockage ne déplace pas *activement*
        les objets, les disques utilisés dans le stockage général doivent être « brassés » régulièrement dans un port d'E/S afin que les objets ayant
        leur place dans un stockage spécialisé y soient effectivement transférés. Cela « défragmente » le stockage et garantit que les choses ne sont
        pas rangées à plusieurs endroits à la fois.
    </BoxAnnotation>

    <BoxAnnotation color="#dd3333" min="14 0 11" max="15 1 12" thickness="0.05">
        Stockage local au niveau d'une ferme à monstres. Ce range-disque contient des disques partitionnés sur les butins que vous voulez conserver, comme les os et les flèches.
        Le range-disque lui-même ne reçoit pas de priorité, car ce qui détermine la priorité est le bus de stockage par lequel le réseau principal accède au sous-réseau.
        Les disques disposent de cartes de répartition égale et de cartes de destruction du surplus.
    </BoxAnnotation>

    <BoxAnnotation color="#dd3333" min="14 1 10" max="15 2.3 11" thickness="0.05">
        Stockage local au niveau d'une ferme à monstres. Ce montage bus de stockage - interface permet au réseau principal d'accéder au stockage de ce sous-réseau.
        Le bus de stockage reçoit une priorité élevée et est filtré sur les contenus rangés dans les disques du sous-réseau.

        IMPORTANT : à cause de la poubelle installée sur le sous-réseau, pensez bien à filtrer ce bus de stockage, sans quoi il va détruire
        *absolument chaque objet, fluide, etc. qui entre dans le réseau* !
    </BoxAnnotation>

    <BoxAnnotation color="#dd3333" min="14 0 9" max="15 1.3 10" thickness="0.05">
        Stockage local au niveau d'une ferme à monstres. Ce bus de stockage posé sur un Matter Condenser est réglé sur une priorité plus basse que le range-disque. Ainsi,
        les butins de monstres qui ne peuvent pas entrer dans les disques du range-disque débordent vers ici et sont détruits. C'est important
        pour éviter que le sous-réseau se retrouve engorgé de bric-à-brac, comme des arcs presque cassés.
    </BoxAnnotation>

    <BoxAnnotation color="#dd33dd" min="8 1 11.7" max="9 2.3 13" thickness="0.05">
        Stockage local au niveau d'une ferme à melons. Ce montage reprend une méthode semblable à celle des différents exemples de fermes de certus. Un bus de stockage
        sur le sous-réseau insère la production de la ferme dans un tonneau. Un autre bus de stockage sur le réseau principal (filtré sur les tranches
        de melon et de priorité élevée) donne au réseau principal accès à cette production.
    </BoxAnnotation>

  <IsometricCamera yaw="270" pitch="30" />
</GameScene>
