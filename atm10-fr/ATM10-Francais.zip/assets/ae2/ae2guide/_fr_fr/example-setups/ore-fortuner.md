---
navigation:
  parent: example-setups/example-setups-index.md
  title: Fortune automatique sur les minerais
  icon: minecraft:raw_iron
---

# Automatisation de l'enchantement Fortune sur les minerais

Le <ItemLink id="annihilation_plane" /> peut recevoir n'importe quel enchantement de pioche, Fortune comprise : un usage évident consiste donc à
appliquer Fortune à quelques-uns d'entre eux, et à faire poser et casser les minerais à toute vitesse par des <ItemLink id="formation_plane" />s et des <ItemLink id="annihilation_plane" />s.

Notez que, comme les <ItemLink id="import_bus" />s « montent progressivement en régime », l'installation démarre lentement puis atteint sa pleine vitesse en quelques secondes.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 0 2" max="3 1 3">
        (1) Bus d'importation : contient quelques cartes d'accélération.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 2" max="2 1 2.3">
        (2) Plans de formation : dans leur configuration par défaut.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 0.7" max="2 1 1">
        (3) Plans d'annihilation : pas d'interface à configurer, mais enchantés avec Fortune.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 0" max="3 1 1">
        (4) Bus de stockage : dans sa configuration par défaut.
  </BoxAnnotation>

<DiamondAnnotation pos="3.5 0.5 2.5" color="#00ff00">
        Entrée
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 0.5 0.5" color="#00ff00">
        Sortie
    </DiamondAnnotation>

<DiamondAnnotation pos="4 0.5 1.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Configurations

*   Le <ItemLink id="import_bus" /> (1) contient quelques <ItemLink id="speed_card" />s. Il en faut d'autant plus que le nombre de plans de formation
    de l'ensemble est élevé, car ils poussent le bus d'importation à récupérer davantage d'objets à la fois.
*   Les <ItemLink id="formation_plane" />s (2) sont dans leur configuration par défaut.
*   Les <ItemLink id="annihilation_plane" />s (3) n'ont pas d'interface et ne peuvent pas être configurés, mais ils sont enchantés avec Fortune.
*   Le <ItemLink id="storage_bus" /> (4) est dans sa configuration par défaut.

## Comment ça marche

1.  Le <ItemLink id="import_bus" /> du sous-réseau vert importe les blocs du premier baril vers le [stockage du réseau](../ae2-mechanics/import-export-storage.md)
2.  Le seul stockage du sous-réseau vert est le <ItemLink id="formation_plane" />, qui pose les blocs.
3.  Le <ItemLink id="annihilation_plane" /> du sous-réseau orange casse les blocs, en leur appliquant Fortune.
4.  Le <ItemLink id="storage_bus" /> du sous-réseau orange stocke le produit de la casse dans le second baril.
