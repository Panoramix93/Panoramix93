---
navigation:
  title: Index/Table des matières
  position: 0
---

![Logo](assets/logo.png)

# Qu'est-ce qu'Applied Energistics 2 ?

# Comment utiliser ce guide

* Ouvrez la barre latérale à gauche pour accéder à la table des matières
* Beaucoup de pages contiennent des scènes interactives. Si une scène comporte les boutons ![Plus](assets/diagrams/plus.png)
et ![Minus](assets/diagrams/minus.png) (zoom) à côté d'elle, vous pouvez faire tourner et déplacer la caméra.
Clic gauche maintenu pour tourner, clic droit maintenu pour déplacer.

# Qu'est-ce qu'Applied Energistics 2 ?

Applied Energistics 2 ajoute des composants et des mécaniques qui apportent des solutions de logistique et de stockage. Vous pouvez remplacer votre
immense salle remplie de coffres par un réseau ME compact, mais ce n'est que le début.
Applied Energistics est conçu pour fonctionner avec les autres mods d'un modpack et permettre de les automatiser. Vous pouvez configurer votre système pour,
d'un seul clic, fabriquer tous les prérequis (et le résultat final) d'une chaîne de fabrication complexe, pour garder certaines
quantités d'objets en stock en en fabriquant d'autres au besoin, ou simplement pour transférer des objets dans votre base.

* [Pour commencer](getting-started.md)
* [Trucs et astuces](tips-and-tricks.md)
* [Mécaniques d'AE2](ae2-mechanics/ae2-mechanics-index.md)
* [Exemples de montages](example-setups/example-setups-index.md)
* [Objets, blocs et machines](items-blocks-machines/items-blocks-machines-index.md)

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>