---
navigation:
  title: Premiers pas (1.20+)
  position: 10
---

<div class="notification is-info">
  Les informations suivantes ne s'appliquent qu'à Applied Energistics 2 sous Minecraft 1.20 et versions ultérieures.
</div>

# Premiers pas

## Obtenir les premiers matériaux

<GameScene zoom="4" background="transparent">
  <ImportStructure src="assets/assemblies/meteor_interior.snbt" />
</GameScene>

Pour débuter avec Applied Energistics 2, vous devez d'abord trouver une [météorite](ae2-mechanics/meteorites.md). Elles sont assez courantes et laissent généralement d'énormes cratères dans le terrain, vous en avez donc probablement déjà croisé une au cours de vos voyages.
Si ce n'est pas le cas, vous pouvez fabriquer une <ItemLink id="meteorite_compass" />, qui pointe vers le <ItemLink id="mysterious_cube" /> le plus proche.

Une fois la météorite trouvée, creusez jusqu'à son centre. Vous y trouverez des amas de quartz certus, des bourgeons de quartz certus, des [blocs de certus bourgeonnant](items-blocks-machines/budding_certus.md) de différents niveaux, ainsi qu'un Cube mystérieux en son centre.

Minez les amas de quartz certus et tous les blocs de quartz certus que vous trouvez. Vous pouvez aussi récupérer les blocs de certus bourgeonnant, mais sans Toucher de soie ils perdront un niveau.

Ne cassez aucun certus bourgeonnant parfait : même avec Toucher de soie, il se dégradera en certus bourgeonnant imparfait, et il est impossible de le ramener à l'état parfait.

Minez également le Cube mystérieux au centre de la météorite pour obtenir les 4 matrices de la presse.

## Faire pousser le quartz certus

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_1.snbt" />
</GameScene>

Des bourgeons de quartz certus poussent sur les [blocs de certus bourgeonnant](items-blocks-machines/budding_certus.md), un peu comme l'améthyste. Si vous cassez un bourgeon qui n'a pas fini
de pousser, il lâche une <ItemLink id="certus_quartz_dust" />, sans effet de Fortune. Si vous cassez un amas arrivé à maturité, il lâche quatre
<ItemLink id="certus_quartz_crystal" />, et Fortune augmente ce nombre.

Il existe 4 niveaux de blocs de certus bourgeonnant : parfait, imparfait, ébréché et endommagé.

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_blocks.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Chaque fois qu'un bourgeon passe au stade suivant, le bloc bourgeonnant a une chance de perdre un niveau, pour finir par devenir
un simple bloc de quartz certus. On peut les réparer (et créer de nouveaux blocs bourgeonnants) en jetant le bloc bourgeonnant (ou un
bloc de quartz certus) dans l'eau avec un ou plusieurs <ItemLink id="charged_certus_quartz_crystal" />.

<RecipeFor id="damaged_budding_quartz" />

Les blocs de certus bourgeonnant parfaits ne se dégradent pas et produisent du certus à l'infini. En revanche, ils ne peuvent pas être fabriqués ni déplacés
à la pioche, même avec Toucher de soie. (ils *peuvent* toutefois être déplacés avec le [stockage spatial](ae2-mechanics/spatial-io.md))

Laissés à eux-mêmes, les bourgeons de quartz certus poussent très lentement. Heureusement, l'<ItemLink id="growth_accelerator" /> accélère
massivement ce processus lorsqu'il est placé contre le bloc bourgeonnant. Vous devriez en construire quelques-uns en priorité.

<GameScene zoom="4" background="transparent">
<ImportStructure src="assets/assemblies/budding_certus_2.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Si vous n'avez pas assez de quartz pour fabriquer en plus un <ItemLink id="energy_acceptor" /> ou une <ItemLink id="vibration_chamber" />,
vous pouvez fabriquer une <ItemLink id="crank" /> et la fixer au bout de votre accélérateur.

La récolte automatique du certus est [décrite ici](example-setups/simple-certus-farm.md).

## Petite parenthèse sur le Fluix

Un autre matériau dont vous aurez besoin est le Fluix, que vous avez déjà rencontré en fabriquant les accélérateurs de croissance. Il s'obtient en jetant du certus chargé, de la redstone et du quartz du Nether dans l'eau. Automatiser cette opération est « laissé en exercice au lecteur ».

Le <ItemLink id="charger" /> est nécessaire pour produire du <ItemLink id="charged_certus_quartz_crystal" />, si vous n'en avez pas déjà fabriqué un.

## Graver quelques processeurs

En pillant une météorite, vous aurez trouvé quatre « matrices » en cassant le Cube mystérieux. Elles s'utilisent dans la <ItemLink id="inscriber" /> pour fabriquer les trois types de processeur.

<ItemGrid>
  <ItemIcon id="silicon_press" />

  <ItemIcon id="logic_processor_press" />

  <ItemIcon id="calculation_processor_press" />

  <ItemIcon id="engineering_processor_press" />
</ItemGrid>

La presse est une machine orientée, un peu comme le four vanilla. Insérer par le haut ou par le bas place les objets dans l'emplacement du haut ou du bas, et insérer par le côté ou par l'arrière place les objets dans l'emplacement central. Les résultats peuvent être extraits par le côté ou par l'arrière.

Pour faciliter l'automatisation avec des entonnoirs (et éventuellement limiter les plats de spaghettis de tuyaux), les presses peuvent être tournées avec une <ItemLink id="certus_quartz_wrench" />.

Produisez quelques exemplaires de chaque type de processeur en préparation de l'étape suivante : la mise en place d'un système ME très basique. Automatiser la production de processeurs est « [laissé en exercice au lecteur](example-setups/processor-automation.md) ».

## La technologie Matter Energy : réseaux et stockage ME

### Qu'est-ce que le stockage ME ?

Cela se prononce « èm-i » et signifie Matter Energy (matière-énergie).

Matter Energy est le composant principal d'Applied Energistics 2 ; c'est un peu la version savant fou du coffre multibloc,
et cela peut révolutionner votre stockage. Le ME est très différent des autres systèmes de stockage de Minecraft, et
il faut parfois sortir un peu du cadre habituel pour s'y habituer ; mais une fois lancé, des quantités de stockage énormes dans un espace minuscule
et plusieurs terminaux d'accès ne sont que la pointe de l'iceberg de ce qui devient possible.

### Que faut-il savoir pour commencer ?

D'abord, le ME stocke les objets à l'intérieur d'autres objets, appelés [disques de stockage](items-blocks-machines/storage_cells.md) ; il en existe 5 niveaux avec des capacités
toujours croissantes. Pour utiliser un disque de stockage, il doit être placé soit dans un <ItemLink id="chest" />,
soit dans un <ItemLink id="drive" />.

Le <ItemLink id="chest" /> affiche le contenu du disque dès qu'il est inséré, et vous
pouvez y ajouter et en retirer des objets comme s'il s'agissait d'un <ItemLink id="minecraft:chest" />, à ceci près que les objets sont
réellement stockés dans les disques de stockage, et non dans le <ItemLink id="chest" /> lui-même.

Le <ItemLink id="chest" /> est assez circonstanciel et limité en possibilités. Pour vraiment
tirer parti d'AE2, vous devez mettre en place un [réseau ME](ae2-mechanics/me-network-connections.md).

## Votre tout premier système ME

Maintenant que vous avez tous les matériaux et machines de base d'Applied Energistics 2, vous pouvez monter votre premier système ME (Matter Energy). Ce sera un système très simple : pas d'autofabrication, pas de logistique, juste un stockage agréable, simple et consultable.

<GameScene zoom="6" interactive={true}>
<ImportStructure src="assets/assemblies/tiny_me_system.snbt" />

</GameScene>

*   Votre liste d'ingrédients :
    * 1x <ItemLink id="drive" />
    * 1x <ItemLink id="terminal" /> ou <ItemLink id="crafting_terminal" />
    * 1x <ItemLink id="energy_acceptor" />
    * Quelques [câbles](items-blocks-machines/cables.md), en verre, gainés ou intelligents, mais pas denses
    * Quelques [disques de stockage](items-blocks-machines/storage_cells.md), de préférence en version 4k pour un bon compromis entre
    capacité et types (il serait plus efficace de [partitionner](items-blocks-machines/cell_workbench.md) un mélange de 4k et de 1k, mais c'est une complexité que nous laissons de côté pour l'instant)
---
1.  Posez le range-disque.
2.  L'accepteur d'énergie (comme plusieurs autres [appareils](ae2-mechanics/devices.md) d'AE2) existe en 2 formes : cube et plat. On passe de l'une à l'autre dans une grille de fabrication. Si votre accepteur d'énergie est un cube, posez-le à côté du range-disque. S'il s'agit d'une plaque plate, posez un câble sur le range-disque et placez l'accepteur dessus.
3.  Amenez de l'énergie dans l'accepteur d'énergie avec un câble/tuyau/conduit du mod de production d'énergie de votre choix.
4.  Posez un câble sur le dessus du range-disque (ou au moins à hauteur des yeux) et placez-y votre terminal ou votre terminal de fabrication.
5.  Mettez vos disques de stockage dans le range-disque
6.  Profit
7.  Amusez-vous avec les réglages du terminal
8.  Savourez votre puissance et vos capacités absolues
9.  Réalisez que ce réseau est, à l'échelle des choses, plutôt modeste

### Agrandir votre réseau

Vous avez donc un stockage de base et un accès à ce stockage : c'est un bon début, mais vous allez probablement vouloir
automatiser quelques traitements.

Un bon exemple consiste à placer un <ItemLink id="export_bus" /> sur le dessus d'un four pour
y envoyer des minerais, et un <ItemLink id="import_bus" />
sous le four pour en extraire les minerais fondus.

Le <ItemLink id="export_bus" /> permet d'exporter des objets du réseau vers l'inventaire
attaché, tandis que le <ItemLink id="import_bus" /> importe les objets de l'inventaire attaché vers
le réseau.

### Dépasser les limites

À ce stade, vous approchez probablement des 8 [appareils](ae2-mechanics/devices.md) ; dès que vous atteignez 9 appareils, vous devrez commencer à
gérer les [canaux](ae2-mechanics/channels.md). Beaucoup d'appareils, mais pas tous, nécessitent un canal pour
fonctionner.

Par défaut, un réseau peut gérer 8 canaux ; une fois cette limite franchie, vous devrez ajouter
un <ItemLink id="controller" /> à votre réseau, ce qui vous permettra de l'agrandir considérablement.
Les [câbles intelligents](items-blocks-machines/cables.md) vous permettent de voir comment les canaux sont routés dans votre réseau. Utilisez-les abondamment au début pour comprendre le comportement des canaux, ou si vous avez beaucoup de redstone et de pierre lumineuse.
