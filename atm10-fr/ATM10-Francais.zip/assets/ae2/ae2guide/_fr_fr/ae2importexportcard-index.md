---
navigation:
  title: "Add-on : AE2 Import Export Card"
  icon: ae2importexportcard:export_card
  position: 150
categories:
  - tools
item_ids:
- ae2importexportcard:export_card
- ae2importexportcard:import_card
---

# AE2 Import Export Card

<Row>
  <ItemImage id="ae2importexportcard:export_card" scale="2" />

  <ItemImage id="ae2importexportcard:import_card" scale="2" />
</Row>

Les cartes d'importation et d'exportation vous permettent d'importer et d'exporter des objets depuis votre inventaire

## Carte d'importation

<ItemImage id="ae2importexportcard:import_card" scale="2" />

La carte d'importation prend les objets situés dans des emplacements précis de votre inventaire et les déverse dans votre système ME.

![Carte d'importation](diagrams/import_card.png)

Cliquer sur un emplacement y place une coche. Tout objet se trouvant dans un emplacement coché sera importé vers votre système ME. Faites glisser des objets depuis votre inventaire vers le haut pour modifier le filtre.

### Améliorations

La carte d'importation prend en charge les [améliorations](items-blocks-machines/upgrade_cards.md) suivantes :

*   <ItemLink id="fuzzy_card" /> filtrer selon le niveau de dégâts et/ou ignorer les NBT de l'objet
*   <ItemLink id="inverter_card" /> fait passer le filtre d'une liste blanche à une liste noire

### Recette

<RecipeFor id="ae2importexportcard:import_card" />

## Carte d'exportation

<ItemImage id="ae2importexportcard:export_card" scale="2" />

La carte d'exportation fonctionne exactement de la même manière, mais tire les objets de votre système ME vers votre inventaire.

![Carte d'exportation](diagrams/export_card.png)

Pour préciser quels objets, faites glisser l'objet depuis l'inventaire vers l'un des emplacements du haut, puis cliquez sur un emplacement de votre inventaire pour le régler sur le nombre souhaité. Un clic droit remet la valeur à X.

### Améliorations

La carte d'exportation prend en charge les [améliorations](items-blocks-machines/upgrade_cards.md) suivantes :

*   <ItemLink id="fuzzy_card" /> filtrer selon le niveau de dégâts et/ou ignorer les NBT de l'objet
*   <ItemLink id="speed_card" /> améliore la vitesse de transfert, de 1 objet à une pile entière
*   <ItemLink id="crafting_card" /> demande et fabrique automatiquement les objets qui ne sont pas disponibles

### Recette

<RecipeFor id="ae2importexportcard:export_card" />