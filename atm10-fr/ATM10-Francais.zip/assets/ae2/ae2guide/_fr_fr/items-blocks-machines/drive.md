---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Range-disque ME
  icon: drive
  position: 210
categories:
- devices
item_ids:
- ae2:drive
---

# Le range-disque ME

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/drive.snbt" />
</GameScene>

Le range-disque est l'[appareil](../ae2-mechanics/devices.md) dans lequel vous insérez vos [disques de stockage](storage_cells.md) afin de les utiliser comme
[stockage réseau](../ae2-mechanics/import-export-storage.md). Il possède 10 emplacements, chacun pouvant accueillir un disque.

Si pour une raison quelconque vous le souhaitez, vous pouvez insérer et extraire les disques de son inventaire avec n'importe quel système de logistique d'objets, entonnoirs ou bus AE2 par exemple.

Il peut être tourné avec une <ItemLink id="certus_quartz_wrench" />.

## Voyants d'état des disques

Les disques placés dans le range-disque portent un voyant qui indique leur état :

| Couleur | État                                                                                   |
| :------ | :------------------------------------------------------------------------------------- |
| Vert    | Vide                                                                                   |
| Bleu    | Contient quelque chose                                                                 |
| Orange  | [Types](../ae2-mechanics/bytes-and-types.md) saturés, aucun nouveau type possible      |
| Rouge   | [Octets](../ae2-mechanics/bytes-and-types.md) saturés, plus aucun objet insérable      |
| Noir    | Pas d'alimentation, ou range-disque sans [canal](../ae2-mechanics/channels.md)         |

## Priorité

Les priorités se règlent en cliquant sur la clé en haut à droite de l'interface.
Les objets qui entrent dans le réseau se dirigent d'abord vers le stockage de priorité la plus élevée.
Lorsque deux stockages ou deux disques ont la même priorité,
si l'un contient déjà l'objet, il sera préféré à
tout autre. Tout disque [partitionné](cell_workbench.md) est considéré comme contenant déjà l'objet
lorsqu'il se trouve dans le même groupe de priorité que d'autres stockages. Les objets retirés du stockage sont
pris dans le stockage de priorité la plus basse. Ce système de priorité fait qu'au fil des insertions et des retraits
dans le stockage réseau, les stockages de priorité élevée se remplissent et ceux de priorité basse se vident.

## Recette

<RecipeFor id="drive" />
