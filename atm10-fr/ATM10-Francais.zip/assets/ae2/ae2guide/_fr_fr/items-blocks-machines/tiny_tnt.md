---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Mini TNT
  icon: tiny_tnt
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:tiny_tnt
---

# Mini TNT

<BlockImage id="tiny_tnt" scale="8" />

De la petite TNT pour de petites explosions. Utile pour fabriquer des paires de <ItemLink id="quantum_entangled_singularity" />.

Ses dégâts sur les blocs peuvent être désactivés dans la configuration afin de permettre la fabrication de singularités sans risque
de dégradation, si vous souhaitez désactiver la TNT et les creepers sur votre serveur.

## Recette

<RecipeFor id="tiny_tnt" />
