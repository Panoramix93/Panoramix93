---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fibre de quartz
  icon: quartz_fiber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quartz_fiber
---

# La fibre de quartz

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/quartz_fiber.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

La fibre de quartz sert à partager de l'énergie entre plusieurs [réseaux](../ae2-mechanics/me-network-connections.md) tout en les gardant séparés. Cela vous permet d'alimenter des
[sous-réseaux](../ae2-mechanics/subnetworks.md)
sans devoir installer des accepteurs d'énergie et des câbles d'alimentation partout. Elle peut aussi servir à empêcher des câbles de se connecter,
même si utiliser des câbles de couleurs différentes ou des <ItemLink id="cable_anchor" /> est moins coûteux et plus efficace.

Ce sont des [sous-éléments de câble](../ae2-mechanics/cable-subparts.md).

## Recette

<RecipeFor id="quartz_fiber" />
