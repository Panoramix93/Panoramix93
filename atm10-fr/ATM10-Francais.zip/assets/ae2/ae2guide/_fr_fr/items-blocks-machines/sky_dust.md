---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Poussière de pierre du ciel
  icon: sky_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_dust
---

# Poussière de pierre du ciel

<ItemImage id="sky_dust" scale="4" />

Un bloc de <ItemLink id="sky_stone_block" /> broyé par un <ItemLink id="inscriber" />. Utilisé dans la production du
<ItemLink id="cell_component_256k" /> et du <ItemLink id="sky_stone_block" />.

On peut également en obtenir en orientant un <ItemLink id="annihilation_plane" /> vers le haut à la limite de hauteur du monde.

## Recette

<RecipeFor id="sky_dust" />
