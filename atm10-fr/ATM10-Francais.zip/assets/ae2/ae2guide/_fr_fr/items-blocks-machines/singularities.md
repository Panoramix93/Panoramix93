---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Singularités
  icon: singularity
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:singularity
- ae2:quantum_entangled_singularity
---

# La singularité

<ItemImage id="singularity" scale="4" />

Une boule de matière extrêmement compacte.

Fabriquée avec 256 000 objets ou seaux dans un <ItemLink id="condenser" /> réglé en mode singularité.

## La singularité intriquée quantiquement

<ItemImage id="quantum_entangled_singularity" scale="4" />

Nécessaire pour créer une liaison entre deux [ponts réseau quantiques](quantum_bridge.md), elles sont toujours produites par
paires correspondantes. Pour créer une liaison, placez une singularité de la paire dans le <ItemLink id="quantum_link" /> du
pont de chaque côté.

Elles se fabriquent en provoquant une réaction entre une <ItemLink id="minecraft:ender_pearl" /> ou de la <ItemLink id="ender_dust" />\
et une <ItemLink id="singularity" />. N'importe quelle force explosive devrait suffire à déclencher la réaction.

<RecipeFor id="quantum_entangled_singularity" />

***Presque toutes les explosions fonctionnent, même celles des creepers.***

Toujours produites par paires, mais elles ne demandent qu'une seule <ItemLink id="singularity" />.

Ce n'est pas une mauvaise idée de les nommer dès leur fabrication, à l'aide de l'enclume vanilla.
