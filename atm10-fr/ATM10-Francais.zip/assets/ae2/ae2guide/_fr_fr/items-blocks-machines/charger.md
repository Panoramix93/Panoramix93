---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Chargeur
  icon: charger
  position: 310
categories:
- machines
item_ids:
- ae2:charger
---

# Le chargeur

<BlockImage id="charger" scale="8" />

Le chargeur permet de recharger
les outils compatibles ainsi que le <ItemLink id="certus_quartz_crystal" />.

L'énergie peut être fournie par le dessus ou par le dessous, via les [câbles](cables.md) d'AE2 ou les câbles d'énergie d'autres mods. Il
accepte aussi bien l'énergie d'AE2 (AE) que la Forge Energy (FE). Les objets peuvent être insérés ou retirés par n'importe quelle face. Seuls les résultats peuvent
être retirés, aucun filtre n'est donc nécessaire pour éviter de sortir des cristaux de Certus au lieu du Certus chargé. Il peut être pivoté avec une
<ItemLink id="certus_quartz_wrench" /> afin de faciliter l'automatisation.

Il permet de créer du <ItemLink id="charged_certus_quartz_crystal" />
à partir de <ItemLink id="certus_quartz_crystal" />, et un <ItemLink id="meteorite_compass" /> à partir d'une <ItemLink id="minecraft:compass" />.

Pour l'alimenter manuellement, placez une <ItemLink id="crank" /> sur le dessus ou le dessous et faites un clic droit dessus jusqu'à ce que l'objet soit chargé.

Il sert également de poste de travail pour le [chercheur en Fluix](fluix_researcher.md).

## Automatisation simple

Par exemple, sa capacité à être pivoté permet de semi-automatiser les chargeurs de cette façon :

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/charger_hopper.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Recette

<RecipeFor id="charger" />
