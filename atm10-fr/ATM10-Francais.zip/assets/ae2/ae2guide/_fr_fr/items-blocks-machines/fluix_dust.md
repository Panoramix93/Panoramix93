---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Poudre de Fluix
  icon: fluix_dust
  position: 010
categories:
- misc ingredients blocks
- network infrastructure
item_ids:
- ae2:fluix_dust
---

# La poudre de Fluix

<ItemImage id="fluix_dust" scale="4" />

Un <ItemLink id="fluix_crystal" /> broyé par un <ItemLink id="inscriber" />. Elle sert à produire
plusieurs machines et composants d'AE2.

## Recette

<RecipeFor id="fluix_dust" />
