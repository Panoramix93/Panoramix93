---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cristal de quartz Certus chargé
  icon: charged_certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:charged_certus_quartz_crystal
---

# Le cristal de quartz Certus chargé

<ItemImage id="charged_certus_quartz_crystal" scale="4" />

Un <ItemLink id="certus_quartz_crystal" /> qui est passé dans un <ItemLink id="charger" />. Utilisé dans la production de
<ItemLink id="fluix_crystal" /> et de [blocs de certus bourgeonnant](../items-blocks-machines/budding_certus.md).

## Recette

<RecipeFor id="charged_certus_quartz_crystal" />
