---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Manivelle
  icon: crank
  position: 310
categories:
- machines
item_ids:
- ae2:crank
---

# La Manivelle

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/crank_on_stuff.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

La manivelle sert à alimenter les machines quand vous n'avez pas d'autre accès à l'énergie (ni à un <ItemLink id="energy_acceptor" />). Les galères de début de partie, pas vrai ?

## Recette

<RecipeFor id="crank" />

