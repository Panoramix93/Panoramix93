---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Tunnels P2P
  icon: me_p2p_tunnel
  position: 210
categories:
- devices
item_ids:
- ae2:me_p2p_tunnel
- ae2:redstone_p2p_tunnel
- ae2:item_p2p_tunnel
- ae2:fluid_p2p_tunnel
- ae2:fe_p2p_tunnel
- ae2:light_p2p_tunnel
---

# Tunnels point à point

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Les tunnels P2P permettent de déplacer des choses comme des objets, des fluides, des signaux de redstone, de l'énergie,
de la lumière et des [canaux](../ae2-mechanics/channels.md) à travers un réseau sans qu'elles interagissent directement
avec lui. Il existe de nombreuses variantes de tunnel P2P, mais chacune ne transporte que son type de contenu précis.
Ils agissent essentiellement comme des portails qui relient directement deux faces de bloc à distance. Ils ne sont pas
bidirectionnels : les entrées et les sorties sont définies.

![Portal](../assets/assemblies/p2p_portal.png)

Par exemple, l'entonnoir orienté vers le tunnel P2P d'objets se comporte comme s'il était directement relié au tonneau,
et les objets circulent.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_hopper_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

En revanche, deux tonneaux placés côte à côte ne se transfèrent pas d'objets entre eux.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_barrel_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Il existe également d'autres variantes, comme le tunnel P2P de redstone.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_redstone.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Et le tunnel P2P ME, qui déplace des canaux.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_channels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Types de tunnels P2P et accord

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="180" pitch="90" />
</GameScene>

Il existe de nombreux types de tunnels P2P. Seul le tunnel P2P ME est directement fabricable, les autres s'obtiennent en
faisant un clic droit sur d'autres tunnels P2P avec certains objets :
- Les tunnels P2P ME sont sélectionnés par un clic droit avec n'importe quel [câble](../items-blocks-machines/cables.md).
- Les tunnels P2P de redstone sont sélectionnés par un clic droit avec divers composants de redstone.
- Les tunnels P2P d'objets sont sélectionnés par un clic droit avec un coffre ou un entonnoir.
- Les tunnels P2P de fluides sont sélectionnés par un clic droit avec un seau ou une bouteille.
- Les tunnels P2P d'énergie sont sélectionnés par un clic droit avec presque n'importe quel objet contenant de l'énergie.
- Les tunnels P2P de lumière sont sélectionnés par un clic droit avec une torche ou de la pierre lumineuse.

Certains types de tunnels ont leurs particularités. Par exemple, les canaux des tunnels P2P ME ne peuvent pas traverser
d'autres tunnels P2P ME, et les tunnels P2P d'énergie prélèvent indirectement une taxe de 2,5 % sur le FE qui les
traverse, en augmentant leur consommation d'[énergie](../ae2-mechanics/energy.md).

## La forme la plus utilisée du P2P

L'usage le plus courant des tunnels P2P consiste à employer un tunnel P2P ME pour densifier le transport de
[canaux](../ae2-mechanics/channels.md). Au lieu d'un faisceau de câbles denses, un seul câble dense suffit à transporter
de nombreux canaux.

Dans cet exemple, 8 entrées P2P ME prennent 256 canaux (8*32) sur le <ItemLink id="controller" /> du réseau principal et
8 sorties P2P ME les restituent ailleurs. Observez que chaque entrée ou sortie de tunnel P2P ne consomme qu'un seul
canal. Nous pouvons donc faire passer de nombreux canaux dans un câble fin. Et comme nos tunnels P2P se trouvent sur un
[sous-réseau](../ae2-mechanics/subnetworks.md) dédié, nous ne consommons même aucun canal du réseau principal pour le
faire ! Observez aussi que même si les tunnels P2P peuvent être placés directement contre un contrôleur, un
[câble intelligent dense](../items-blocks-machines/cables.md#smart-cable) peut être intercalé pour visualiser plus
facilement les canaux.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/p2p_compact_channels.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 1.3 6.3" max="2 2.7 6.7">
        La fibre de quartz partage l'énergie entre le réseau principal et le sous-réseau p2p.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.1 0 5.7" max="5 2.3 6.4">
        Vous pouvez soit placer l'entrée du tunnel directement sur un contrôleur, soit la relier par câble.
  </BoxAnnotation>

  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

Pour un autre exemple (y compris son utilisation avec les [ponts quantiques](quantum_bridge.md)), voyez ce schéma fait
sous Paint que je n'ai pas le courage de retoucher :

![P2P and quantum bridges](../assets/diagrams/p2p_quantum_network.png)

## Imbrication

Vous ne pouvez cependant pas vous en servir pour envoyer une infinité de canaux dans un seul câble. Le canal d'un tunnel
P2P ME ne traverse pas un autre tunnel P2P ME, vous ne pouvez donc pas les imbriquer de façon récursive. Observez que la
couche extérieure de tunnels P2P ME, sur les câbles rouges, est hors ligne. Notez que cela ne concerne que les tunnels
P2P ME : les autres types de tunnels P2P peuvent traverser un tunnel P2P ME, comme le montrent les tunnels P2P de
redstone qui fonctionnent sans problème.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_nesting.snbt" />
  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

## Liaison

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_linking_frequency.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Les extrémités d'une connexion de tunnel P2P se lient à l'aide d'une <ItemLink id="memory_card" />. La fréquence est
affichée sous forme d'une grille de couleurs 2x2 à l'arrière du tunnel.
- Maj + clic droit pour générer une nouvelle fréquence de liaison P2P.
- Clic droit pour coller les réglages, les cartes d'amélioration ou la fréquence de liaison.

Le tunnel sur lequel vous faites Maj + clic droit sera l'entrée, et celui sur lequel vous faites un clic droit sera la
sortie. Vous pouvez avoir plusieurs sorties, mais avec les tunnels P2P ME, les canaux entrants sont répartis entre les
sorties : vous ne pouvez donc pas dupliquer des canaux.

## Recette

<RecipeFor id="me_p2p_tunnel" />
