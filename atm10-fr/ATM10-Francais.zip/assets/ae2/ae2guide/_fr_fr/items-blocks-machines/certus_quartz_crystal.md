---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cristal de Certus Quartz
  icon: certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_crystal
---

# Le cristal de Certus Quartz

<ItemImage id="certus_quartz_crystal" scale="4" />

*« Les cristaux de Certus Quartz ont la particularité unique d'accepter de grandes quantités d'énergie dans leur matrice cristalline. »*

L'un des principaux ingrédients des blocs, [dispositifs](../ae2-mechanics/devices.md) et objets d'AE2. Il s'obtient en le faisant pousser sur du [Certus Quartz bourgeonnant](../ae2-mechanics/certus-growth.md).

## Quelques recettes alternatives

<Recipe id="misc/deconstruction_certus_quartz_block" />

<Recipe id="transform/certus_quartz_crystals" />
