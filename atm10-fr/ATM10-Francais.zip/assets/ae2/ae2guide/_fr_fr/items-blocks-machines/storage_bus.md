---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bus de stockage ME
  icon: storage_bus
  position: 220
categories:
- devices
item_ids:
- ae2:storage_bus
---

# Le bus de stockage

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/storage_bus.snbt" />
</GameScene>

Vous avez toujours voulu *garder* votre monstre de coffres au lieu de le remplacer par quelque chose de raisonnable ? Voici le bus de stockage !

Le bus de stockage transforme l'inventaire qu'il touche en [stockage réseau](../ae2-mechanics/import-export-storage.md).
Pour cela, il permet au réseau de voir le contenu de cet inventaire, et il y insère ou en extrait des objets afin de
répondre aux [appareils](../ae2-mechanics/devices.md) qui insèrent dans le stockage réseau ou en extraient.

Comme la philosophie d'AE2 est de faire émerger des mécaniques de l'interaction entre les fonctions des [appareils](../ae2-mechanics/devices.md), vous n'êtes
pas obligé d'utiliser un bus de stockage pour *stocker*. En vous servant des [sous-réseaux](../ae2-mechanics/subnetworks.md)
pour faire d'un bus de stockage (ou d'une poignée de bus de stockage) le *seul* stockage d'un réseau, vous pouvez l'utiliser comme source ou comme destination
pour un transfert d'objets. (voir le ["sous-réseau tuyau"](../example-setups/pipe-subnet.md))

REMARQUE IMPORTANTE : les gros inventaires optimisés comme les casiers conviennent très bien, mais les gros inventaires *non* optimisés comportant de nombreux emplacements, comme les
coffres colossaux, sont désastreux pour les performances lorsqu'ils sont utilisés avec des bus de stockage.

Ce sont des [sous-éléments de câble](../ae2-mechanics/cable-subparts.md).

## Filtrage

Par défaut, le bus stocke tout. Les objets placés dans ses emplacements de filtre font office de liste blanche :
seuls ces objets précis peuvent alors être stockés.

Les objets et les fluides peuvent être glissés dans les emplacements depuis JEI/REI, même si vous ne possédez aucun exemplaire de l'objet en question.

Faites un clic droit avec un conteneur de fluide (seau, cuve, etc.) pour définir ce fluide comme filtre, au lieu de l'objet seau ou cuve lui-même.

## Priorité

Les priorités se règlent en cliquant sur la clé en haut à droite de l'interface.
Les objets qui entrent dans le réseau se dirigent d'abord vers le stockage de priorité la plus élevée.
Lorsque deux stockages ont la même priorité,
si l'un contient déjà l'objet, il sera préféré à
tout autre. Tout stockage filtré est considéré comme contenant déjà l'objet
lorsqu'il se trouve dans le même groupe de priorité que d'autres stockages. Les objets retirés du stockage sont
pris dans le stockage de priorité la plus basse. Ce système de priorité fait qu'au fil des insertions et des retraits
dans le stockage réseau, les stockages de priorité élevée se remplissent et ceux de priorité basse se vident.

## Réglages

*   Le bus peut être partitionné (filtré) sur ce qui se trouve actuellement dans l'inventaire adjacent
*   On peut interdire ou autoriser le réseau à voir, dans l'inventaire adjacent, les objets que le bus ne peut pas extraire
    (par exemple, un bus de stockage ne peut pas extraire d'objets de l'emplacement d'entrée central d'un <ItemLink id="inscriber" />)
*   Le bus peut filtrer à l'insertion et à l'extraction, ou seulement à l'insertion
*   Le bus peut être bidirectionnel, en insertion seule ou en extraction seule

## Améliorations

Le bus de stockage prend en charge les [améliorations](upgrade_cards.md) suivantes :

*   <ItemLink id="capacity_card" /> augmente le nombre d'emplacements de filtre
*   <ItemLink id="fuzzy_card" /> permet au bus de filtrer selon le niveau d'usure et/ou d'ignorer le NBT des objets
*   <ItemLink id="inverter_card" /> transforme le filtre de liste blanche en liste noire
*   <ItemLink id="void_card" /> détruit les objets insérés si l'inventaire attaché est plein, pratique pour éviter qu'une ferme se bouche. Pensez bien à la partitionner !

## Recette

<RecipeFor id="storage_bus" />
