---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Disques spatiaux
  icon: spatial_storage_cell_128
  position: 410
categories:
- tools
item_ids:
- ae2:spatial_storage_cell_2
- ae2:spatial_storage_cell_16
- ae2:spatial_storage_cell_128
- ae2:spatial_cell_component_2
- ae2:spatial_cell_component_16
- ae2:spatial_cell_component_128
---

# Disques spatiaux

  <Row>
    <ItemImage id="spatial_storage_cell_2" scale="4" />

    <ItemImage id="spatial_storage_cell_16" scale="4" />

    <ItemImage id="spatial_storage_cell_128" scale="4" />
  </Row>

Les disques spatiaux servent à [stocker des volumes physiques d'espace](../ae2-mechanics/spatial-io.md).
Ils s'utilisent dans un <ItemLink id="spatial_io_port" />.

Contrairement aux [disques de stockage](../items-blocks-machines/storage_cells.md), les disques spatiaux ne peuvent pas être reformatés.

Encore une fois : **VOUS NE POUVEZ PAS RÉINITIALISER, REFORMATER NI REDIMENSIONNER UN DISQUE SPATIAL APRÈS SON UTILISATION.** Fabriquez un nouveau disque si vous voulez d'autres dimensions.


## Recettes

  <Row>
    <Recipe id="network/cells/spatial_storage_cell_2_cubed_storage" />

    <Recipe id="network/cells/spatial_storage_cell_16_cubed_storage" />

    <Recipe id="network/cells/spatial_storage_cell_128_cubed_storage" />
  </Row>

# Boîtiers

Les disques peuvent être fabriqués avec un composant spatial et un boîtier, ou avec la recette du boîtier autour d'un composant spatial :

<Row>
  <Recipe id="network/cells/spatial_storage_cell_2_cubed" />

  <Recipe id="network/cells/spatial_storage_cell_2_cubed_storage" />
</Row>

Les boîtiers seuls se fabriquent ainsi :

  <RecipeFor id="item_cell_housing" />

# Composants spatiaux

Les composants spatiaux sont le cœur des disques spatiaux. Chaque palier multiplie par 8 les dimensions du volume qui peut être
stocké.

  <Row>
    <RecipeFor id="spatial_cell_component_2" />

    <RecipeFor id="spatial_cell_component_16" />

    <RecipeFor id="spatial_cell_component_128" />
  </Row>