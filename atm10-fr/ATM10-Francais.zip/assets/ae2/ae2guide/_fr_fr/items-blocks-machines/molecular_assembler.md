---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Assembleur moléculaire
  icon: molecular_assembler
  position: 310
categories:
- machines
item_ids:
- ae2:molecular_assembler
---

# L'assembleur moléculaire

<BlockImage id="molecular_assembler" scale="8" />

L'assembleur moléculaire prend les objets qui lui sont fournis et exécute l'opération définie par un <ItemLink id="pattern_provider" /> adjacent,
ou par le <ItemLink id="crafting_pattern" />, le <ItemLink id="smithing_table_pattern" /> ou le <ItemLink id="stonecutting_pattern" /> inséré,
puis envoie le résultat vers les inventaires adjacents.

Cet assembleur contient un modèle de fabrication correspondant à la recette 1 bûche de chêne = 4 planches de chêne. Lorsque des bûches de chêne sont acheminées dans l'entonnoir du haut,
l'assembleur fabrique et recrache des planches de chêne dans l'entonnoir du bas.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/standalone_assembler.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## L'usage principal de l'assembleur moléculaire

Leur usage principal reste toutefois à côté d'un <ItemLink id="pattern_provider" />. Dans ce cas, les Fournisseurs de pattern ME ont un comportement particulier :
ils transmettent les informations du modèle concerné en même temps que les ingrédients aux assembleurs adjacents. Comme les assembleurs éjectent automatiquement le résultat
de leurs fabrications vers les inventaires adjacents (et donc dans les emplacements de retour du Fournisseur de pattern ME), un assembleur posé sur un Fournisseur de pattern ME
suffit à automatiser les modèles de fabrication.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Améliorations

L'assembleur moléculaire accepte les [améliorations](upgrade_cards.md) suivantes :

*   <ItemLink id="speed_card" />

## Recette

<RecipeFor id="molecular_assembler" />

## Remarque

Optifine casse la fonction d'« envoi vers les inventaires adjacents », si bien que la plupart des installations de fabrication à base d'assembleurs ne fonctionneront pas.
