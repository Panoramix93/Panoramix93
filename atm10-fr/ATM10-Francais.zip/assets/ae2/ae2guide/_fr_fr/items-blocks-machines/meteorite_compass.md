---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Boussole à météorites
  icon: meteorite_compass
  position: 410
categories:
- tools
item_ids:
- ae2:meteorite_compass
---

# La boussole à météorites

<ItemImage id="meteorite_compass" scale="4" />

La boussole à météorites pointe vers le <ItemLink id="mysterious_cube" /> le plus proche, et donc vers la
[météorite](../ae2-mechanics/meteorites.md) la plus proche. C'est l'un des premiers objets AE2 que vous devriez fabriquer.

## Recette

<RecipeFor id="meteorite_compass" />
