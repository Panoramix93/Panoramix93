---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Noyaux de formation et d'annihilation
  icon: formation_core
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:formation_core
- ae2:annihilation_core
---

# Noyaux de formation et d'annihilation

<Row>
  <ItemImage id="formation_core" scale="4" />

  <ItemImage id="annihilation_core" scale="4" />
</Row>

Ce sont les composants principaux des [dispositifs](../ae2-mechanics/devices.md) d'entrée et de sortie d'AE2. Grâce à la puissance du <ItemLink id="fluix_crystal" /> et
d'un [processeur logique](processors.md), ils permettent aux dispositifs de faire entrer et sortir des objets, des blocs, des fluides, etc. (Aucune fonction réelle, juste
un intermédiaire de fabrication)

## Recettes

<RecipeFor id="formation_core" />

<RecipeFor id="annihilation_core" />

