---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Câbles
  icon: fluix_glass_cable
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:white_glass_cable
- ae2:orange_glass_cable
- ae2:magenta_glass_cable
- ae2:light_blue_glass_cable
- ae2:yellow_glass_cable
- ae2:lime_glass_cable
- ae2:pink_glass_cable
- ae2:gray_glass_cable
- ae2:light_gray_glass_cable
- ae2:cyan_glass_cable
- ae2:purple_glass_cable
- ae2:blue_glass_cable
- ae2:brown_glass_cable
- ae2:green_glass_cable
- ae2:red_glass_cable
- ae2:black_glass_cable
- ae2:fluix_glass_cable
- ae2:white_covered_cable
- ae2:orange_covered_cable
- ae2:magenta_covered_cable
- ae2:light_blue_covered_cable
- ae2:yellow_covered_cable
- ae2:lime_covered_cable
- ae2:pink_covered_cable
- ae2:gray_covered_cable
- ae2:light_gray_covered_cable
- ae2:cyan_covered_cable
- ae2:purple_covered_cable
- ae2:blue_covered_cable
- ae2:brown_covered_cable
- ae2:green_covered_cable
- ae2:red_covered_cable
- ae2:black_covered_cable
- ae2:fluix_covered_cable
- ae2:white_covered_dense_cable
- ae2:orange_covered_dense_cable
- ae2:magenta_covered_dense_cable
- ae2:light_blue_covered_dense_cable
- ae2:yellow_covered_dense_cable
- ae2:lime_covered_dense_cable
- ae2:pink_covered_dense_cable
- ae2:gray_covered_dense_cable
- ae2:light_gray_covered_dense_cable
- ae2:cyan_covered_dense_cable
- ae2:purple_covered_dense_cable
- ae2:blue_covered_dense_cable
- ae2:brown_covered_dense_cable
- ae2:green_covered_dense_cable
- ae2:red_covered_dense_cable
- ae2:black_covered_dense_cable
- ae2:fluix_covered_dense_cable
- ae2:white_smart_cable
- ae2:orange_smart_cable
- ae2:magenta_smart_cable
- ae2:light_blue_smart_cable
- ae2:yellow_smart_cable
- ae2:lime_smart_cable
- ae2:pink_smart_cable
- ae2:gray_smart_cable
- ae2:light_gray_smart_cable
- ae2:cyan_smart_cable
- ae2:purple_smart_cable
- ae2:blue_smart_cable
- ae2:brown_smart_cable
- ae2:green_smart_cable
- ae2:red_smart_cable
- ae2:black_smart_cable
- ae2:fluix_smart_cable
- ae2:white_smart_dense_cable
- ae2:orange_smart_dense_cable
- ae2:magenta_smart_dense_cable
- ae2:light_blue_smart_dense_cable
- ae2:yellow_smart_dense_cable
- ae2:lime_smart_dense_cable
- ae2:pink_smart_dense_cable
- ae2:gray_smart_dense_cable
- ae2:light_gray_smart_dense_cable
- ae2:cyan_smart_dense_cable
- ae2:purple_smart_dense_cable
- ae2:blue_smart_dense_cable
- ae2:brown_smart_dense_cable
- ae2:green_smart_dense_cable
- ae2:red_smart_dense_cable
- ae2:black_smart_dense_cable
- ae2:fluix_smart_dense_cable
---

# Câbles

<GameScene zoom="3" background="transparent">
  <ImportStructure src="../assets/assemblies/cables.snbt" />
  <IsometricCamera yaw="180" pitch="30" />
</GameScene>

Même si les réseaux ME se créent aussi par le simple fait d'accoler des machines compatibles ME, les câbles sont le principal moyen
d'étendre un réseau ME sur de plus grandes surfaces.

Des câbles de couleurs différentes permettent de s'assurer que des câbles adjacents ne se connectent pas entre eux,
ce qui permet de répartir les [canaux](../ae2-mechanics/channels.md) plus efficacement. Ils déterminent aussi la couleur des terminaux qui y sont connectés,
vous n'êtes donc pas obligé d'avoir tous vos terminaux en violet. Les câbles Fluix se connectent à toutes les autres couleurs.

À noter, **LES CANAUX N'ONT RIEN À VOIR AVEC LA COULEUR DES CÂBLES**

## Une remarque importante

**Si vous débutez avec AE2 et que vous ne maîtrisez pas les canaux, utilisez du câble intelligent et du câble dense intelligent partout où vous pouvez.
Cela montrera comment les canaux sont acheminés dans votre réseau, ce qui rendra leur comportement plus compréhensible.**

## Une autre remarque

**Ce ne sont pas des tuyaux à objets, à fluides, à énergie ni quoi que ce soit d'autre.** Ils n'ont aucun inventaire interne, les fournisseurs de pattern et les machines ne « poussent » rien
dedans, tout ce qu'ils font, c'est relier les [appareils](../ae2-mechanics/devices.md) AE2 entre eux pour former un réseau.

## Câble de verre

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/fluix_glass_cable.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Le <ItemLink id="fluix_glass_cable" /> est le câble le plus simple à fabriquer, il transporte l'énergie
et jusqu'à 8 [canaux](../ae2-mechanics/channels.md). Il existe en 17 couleurs différentes, la couleur par défaut
étant Fluix, et peut être teint dans n'importe quelle couleur à l'aide de l'un des 16 colorants.

Pour fabriquer des câbles colorés, entourez un colorant de n'importe quel type avec 8 câbles du même
type (la couleur des câbles n'a pas d'importance, mais ils doivent être du même type :
verre, intelligent, etc.). Vous pouvez aussi peindre les câbles directement dans le monde avec n'importe quel pinceau
compatible Forge.

Vous pouvez fabriquer n'importe quel câble coloré avec un seau d'eau pour en retirer le colorant.

Vous pouvez recouvrir le câble de laine pour obtenir un <ItemLink id="fluix_covered_cable" />, et fabriquer un <ItemLink id="fluix_smart_cable" /> pour mieux comprendre ce qui se passe avec
vos [canaux](../ae2-mechanics/channels.md).

<RecipeFor id="fluix_glass_cable" />

<RecipeFor id="blue_glass_cable" />

## Câble couvert

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

La variante couverte n'offre aucun avantage de jeu par rapport à son équivalent <ItemLink id="fluix_glass_cable" />. Elle peut toutefois servir
de choix esthétique alternatif si vous préférez le look couvert.

Il peut être coloré de la même manière que le <ItemLink id="fluix_glass_cable" />. Quatre <ItemLink id="fluix_covered_cable" /> peuvent être fabriqués avec
de la redstone et de la pierre lumineuse pour obtenir un <ItemLink id="fluix_covered_dense_cable" />.

<Recipe id="network/cables/covered_fluix" />

<RecipeFor id="blue_covered_cable" />

## Câble dense

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Câble de plus grande capacité, il peut transporter 32 canaux, contrairement au câble standard qui n'en transporte que 8,
mais il ne prend pas en charge les bus : vous devez donc d'abord passer du câble dense à un
câble plus petit (comme le <ItemLink id="fluix_glass_cable" /> ou le <ItemLink id="fluix_smart_cable" />) avant d'utiliser des bus ou
des panneaux.

Les câbles denses modifient légèrement le comportement de « chemin le plus court » des canaux : les canaux empruntent le chemin le plus court jusqu'à un
câble dense, puis le chemin le plus court à travers ce câble dense jusqu'à un contrôleur.

<Recipe id="network/cables/dense_covered_fluix" />

<RecipeFor id="blue_covered_dense_cable" />

## Câble intelligent

<Row>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
</Row>

Bien qu'ils ressemblent un peu au <ItemLink id="fluix_covered_cable" /> en apparence, ils
offrent une fonction de diagnostic en affichant l'utilisation des canaux sur les câbles :
les canaux apparaissent comme des lignes colorées lumineuses qui courent le long de la bande noire
des câbles, ce qui vous permet de comprendre comment vos canaux sont utilisés sur
votre réseau. Pour les câbles intelligents ordinaires, les quatre premiers canaux apparaissent comme des lignes de la couleur du
câble, les quatre suivants comme des lignes blanches. Pour le câble dense intelligent, chaque bande représente 4 canaux.

Sur les réseaux équipés d'un <ItemLink id="controller" />, les lignes sur les câbles montrent le chemin exact emprunté par les canaux.

Sur les réseaux ad hoc, les câbles intelligents affichent à la place le nombre de canaux utilisés sur l'ensemble du réseau, et non le nombre de canaux qui passent par ce câble précis.

Ils peuvent aussi être colorés de la même manière que le <ItemLink id="fluix_glass_cable" />.

<Recipe id="network/cables/smart_fluix" />

<Recipe id="network/cables/dense_smart_fluix" />

<RecipeFor id="blue_smart_cable" />
