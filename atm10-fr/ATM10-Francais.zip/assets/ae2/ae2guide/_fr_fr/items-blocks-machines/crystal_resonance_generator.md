---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Générateur de résonance cristalline
  icon: crystal_resonance_generator
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:crystal_resonance_generator
---

# Le générateur de résonance cristalline

<BlockImage id="crystal_resonance_generator" scale="8" />

Cet appareil produit de l'énergie pour votre réseau ME sans aucun carburant. À cause des vibrations cristallines qu'il génère, un seul exemplaire peut être utilisé par réseau. Ces vibrations traversent même la <ItemLink id="quartz_fiber" />.

**Taux de production :** <ae2:ConfigValue name="crystalResonanceGeneratorRate"/> AE/t

## Recettes

<RecipeFor id="crystal_resonance_generator" />
