---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Établi de cellules
  icon: cell_workbench
  position: 310
categories:
- machines
item_ids:
- ae2:cell_workbench
---

# L'Établi de cellules

<BlockImage id="cell_workbench" scale="8" />

L'Établi de cellules vous permet de configurer les [disques de stockage](storage_cells.md) et les <ItemLink id="view_cell" />.

Vous pouvez y ajouter des [cartes d'amélioration](upgrade_cards.md) et configurer des « partitions » pour filtrer ce que le disque stockera.

Les objets et les fluides peuvent être glissés dans les emplacements depuis JEI/REI même si vous ne possédez pas réellement l'objet en question.

Faites un clic droit avec un conteneur de fluide (comme un seau ou une cuve) pour définir ce fluide comme filtre, au lieu du seau ou de la cuve elle-même.

## Réglages

L'établi de cellules dispose de quelques boutons en haut à gauche :

*   Vous pouvez partitionner un disque d'après son contenu actuel
*   Vous pouvez effacer le partitionnement du disque
*   L'établi peut être réglé pour conserver les réglages de partition lorsque le disque est retiré, ce qui permet de copier les réglages d'un disque à l'autre.

## Recette

<RecipeFor id="cell_workbench" />
