---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Chercheur en Fluix (villageois)
  icon: minecraft:emerald
  position: 310
categories:
- tools
---

# Le Chercheur en Fluix

<Row>
![Chercheur en Fluix](../assets/diagrams/ae2_villager.png)
<BlockImage id="charger" scale="8" />
</Row>

Le Chercheur en Fluix est un métier de villageois. Le poste de travail correspondant est le <ItemLink id="charger" />.

## Échanges

Les échanges suivent la structure vanilla : une sélection aléatoire de 2 échanges est débloquée par niveau (sauf si ce niveau ne compte qu'un seul échange
possible)

| Niveau     | Objet demandé                                     | Objet donné                                     |
|------------|---------------------------------------------------|-------------------------------------------------|
| Novice     | 3 <ItemLink id="minecraft:emerald" />             | 4 <ItemLink id="certus_quartz_crystal" />       |
| Novice     | 2 <ItemLink id="minecraft:emerald" />             | 1 <ItemLink id="meteorite_compass" />           |
|            |                                                   |                                                 |
| Apprenti   | 3 <ItemLink id="charged_certus_quartz_crystal" /> | 1 <ItemLink id="minecraft:emerald" />           |
| Apprenti   | 5 <ItemLink id="silicon" />                       | 1 <ItemLink id="minecraft:emerald" />           |
| Apprenti   | 5 <ItemLink id="minecraft:emerald" />             | 8 <ItemLink id="sky_stone_block" />             |
|            |                                                   |                                                 |
| Compagnon  | 2 <ItemLink id="quartz_glass" />                  | 1 <ItemLink id="minecraft:emerald" />           |
| Compagnon  | 5 <ItemLink id="minecraft:emerald" />             | 4 <ItemLink id="fluix_crystal" />               |
|            |                                                   |                                                 |
| Expert     | 5 <ItemLink id="matter_ball" />                   | 1 <ItemLink id="minecraft:emerald" />           |
| Expert     | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="silicon_press" />               |
| Expert     | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="logic_processor_press" />       |
| Expert     | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="calculation_processor_press" /> |
| Expert     | 10 <ItemLink id="minecraft:emerald" />            | 1 <ItemLink id="engineering_processor_press" /> |
|            |                                                   |                                                 |
| Maître     | 8 <ItemLink id="minecraft:emerald" />             | 5 <ItemLink id="minecraft:slime_ball" />        |
