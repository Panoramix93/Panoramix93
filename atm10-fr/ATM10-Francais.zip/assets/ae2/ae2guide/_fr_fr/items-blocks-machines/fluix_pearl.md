---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Perle de Fluix
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# Perle de Fluix

<ItemImage id="fluix_pearl" scale="4" />

Une perle de l'Ender enrobée de <ItemLink id="fluix_crystal" />, utilisée dans la production de
plusieurs composants d'AE2.

## Recette

<RecipeFor id="fluix_pearl" />
