---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cartes d'amélioration
  icon: speed_card
  position: 410
categories:
- tools
item_ids:
- ae2:basic_card
- ae2:advanced_card
- ae2:redstone_card
- ae2:capacity_card
- ae2:void_card
- ae2:fuzzy_card
- ae2:speed_card
- ae2:inverter_card
- ae2:crafting_card
- ae2:equal_distribution_card
- ae2:energy_card
---

# Cartes d'amélioration

<Row>
  <ItemImage id="redstone_card" scale="2" />

  <ItemImage id="capacity_card" scale="2" />

  <ItemImage id="void_card" scale="2" />

  <ItemImage id="fuzzy_card" scale="2" />

  <ItemImage id="speed_card" scale="2" />

  <ItemImage id="inverter_card" scale="2" />

  <ItemImage id="crafting_card" scale="2" />

  <ItemImage id="equal_distribution_card" scale="2" />

  <ItemImage id="energy_card" scale="2" />
</Row>

Les cartes d'amélioration modifient le comportement des [dispositifs](../ae2-mechanics/devices.md) et des machines d'AE2 : elles augmentent leur vitesse, améliorent leur
capacité de filtrage, activent le contrôle par redstone, etc.

## Composants des cartes

<Row>
  <ItemImage id="basic_card" scale="2" />

  <ItemImage id="advanced_card" scale="2" />
</Row>

Les cartes se fabriquent à partir d'une base de carte simple ou avancée

<Row>
  <RecipeFor id="basic_card" />

  <RecipeFor id="advanced_card" />
</Row>

## Carte de redstone

<ItemImage id="redstone_card" scale="2" />

Les cartes de redstone ajoutent le contrôle par redstone en ajoutant un bouton dans l'interface du dispositif, qui permet de basculer entre différentes conditions de redstone.

<RecipeFor id="redstone_card" />

## Carte de capacité

<ItemImage id="capacity_card" scale="2" />

Les cartes de capacité augmentent le nombre d'emplacements de filtre des bus d'importation, d'exportation et de stockage ME, ainsi que des plans de formation.

<RecipeFor id="capacity_card" />

## Carte de destruction du surplus

<ItemImage id="void_card" scale="2" />

Les cartes de destruction du surplus peuvent être appliquées aux [disques de stockage](storage_cells.md) dans un <ItemLink id="cell_workbench" />
et suppriment les objets entrants lorsque le disque est plein. (Pensez bien à [partitionner](cell_workbench.md) vos disques !) Associées à une carte de répartition équitable,
les objets sont détruits dès que la section du disque réservée à cet objet précis est pleine, même si les sections des autres objets sont vides.

<RecipeFor id="void_card" />

## Carte approximative

<ItemImage id="fuzzy_card" scale="2" />

Les cartes approximatives permettent aux dispositifs et aux outils dotés de filtres de filtrer selon le niveau d'endommagement et/ou d'ignorer les NBT des objets, ce qui vous permet d'exporter
toutes les haches en fer quel que soit leur niveau d'usure et leurs enchantements, ou de n'exporter que les épées en diamant endommagées, et pas celles entièrement réparées.

Voici un exemple du fonctionnement des modes de comparaison d'endommagement approximatif : à gauche la
configuration du bus, en haut l'objet comparé.

| 25 %                        | Pioche endommagée à 10 % | Pioche endommagée à 30 % | Pioche endommagée à 80 % | Pioche entièrement réparée |
| --------------------------- | ------------------------ | ------------------------ | ------------------------ | -------------------------- |
| Pioche presque cassée       | ✅                   | \*\*\*\*            | \*\*\*\*            | \*\*\*\*            |
| Pioche entièrement réparée  | \*\*\*\*            | ✅                   | ✅                   | ✅                   |

| 50 %                        | Pioche endommagée à 10 % | Pioche endommagée à 30 % | Pioche endommagée à 80 % | Pioche entièrement réparée |
| --------------------------- | ------------------------ | ------------------------ | ------------------------ | -------------------------- |
| Pioche presque cassée       | ✅                   | ✅                   | \*\*\*\*            | \*\*\*\*            |
| Pioche entièrement réparée  | \*\*\*\*            | \*\*\*\*            | ✅                   | ✅                   |

| 75 %                        | Pioche endommagée à 10 % | Pioche endommagée à 30 % | Pioche endommagée à 80 % | Pioche entièrement réparée |
| --------------------------- | ------------------------ | ------------------------ | ------------------------ | -------------------------- |
| Pioche presque cassée       | ✅                   | ✅                   | \*\*\*\*            | \*\*\*\*            |
| Pioche entièrement réparée  | \*\*\*\*            |                     | ✅                   | ✅                   |

| 99 %                        | Pioche endommagée à 10 % | Pioche endommagée à 30 % | Pioche endommagée à 80 % | Pioche entièrement réparée |
| --------------------------- | ------------------------ | ------------------------ | ------------------------ | -------------------------- |
| Pioche presque cassée       | ✅                   | ✅                   | ✅                   | \*\*\*\*            |
| Pioche entièrement réparée  | \*\*\*\*            | \*\*\*\*            | \*\*\*\*            | ✅                   |

| Ignorer                     | Pioche endommagée à 10 % | Pioche endommagée à 30 % | Pioche endommagée à 80 % | Pioche entièrement réparée |
| --------------------------- | ------------------------ | ------------------------ | ------------------------ | -------------------------- |
| Pioche presque cassée       | ✅                   | ✅                   | ✅                   | **✅**               |
| Pioche entièrement réparée  | **✅**               | **✅**               | **✅**               | ✅                   |

<RecipeFor id="fuzzy_card" />

## Carte d'accélération

<ItemImage id="speed_card" scale="2" />

Les cartes d'accélération rendent les choses plus rapides : les bus d'importation et d'exportation déplacent davantage d'objets par opération, et les graveurs
et les assembleurs travaillent plus vite.

<RecipeFor id="speed_card" />

## Carte d'inversion

<ItemImage id="inverter_card" scale="2" />

Les cartes d'inversion font passer les filtres des dispositifs et des outils de la liste blanche à la liste noire.

<RecipeFor id="inverter_card" />

## Carte de fabrication

<ItemImage id="crafting_card" scale="2" />

Les cartes de fabrication permettent au dispositif d'envoyer des demandes de fabrication à votre système de
[fabrication automatique](../ae2-mechanics/autocrafting.md) afin d'obtenir les objets dont il a besoin.

<RecipeFor id="crafting_card" />

## Carte de répartition équitable

<ItemImage id="equal_distribution_card" scale="2" />

Les cartes de répartition équitable peuvent être appliquées aux [disques de stockage](storage_cells.md) dans un <ItemLink id="cell_workbench" /> et
divisent le disque en sections de taille égale selon le [partitionnement](cell_workbench.md) de la carte. Cela évite qu'un seul type d'objet
remplisse entièrement le disque.

<RecipeFor id="equal_distribution_card" />

## Carte d'énergie

<ItemImage id="energy_card" scale="2" />

Les cartes d'énergie augmentent la réserve d'énergie de certains outils comme les terminaux portables et rendent les <ItemLink id="vibration_chamber" />
plus efficaces.

<RecipeFor id="energy_card" />
