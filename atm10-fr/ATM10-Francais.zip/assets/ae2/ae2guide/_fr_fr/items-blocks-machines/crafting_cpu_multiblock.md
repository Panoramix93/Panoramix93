---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Multibloc CPU de fabrication (stockage, coprocesseur, moniteur, unité)
  icon: 1k_crafting_storage
  position: 210
categories:
- devices
item_ids:
- ae2:1k_crafting_storage
- ae2:4k_crafting_storage
- ae2:16k_crafting_storage
- ae2:64k_crafting_storage
- ae2:256k_crafting_storage
- ae2:crafting_accelerator
- ae2:crafting_monitor
- ae2:crafting_unit
---

# Le CPU de fabrication

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="crafting_accelerator" scale="4" />

  <BlockImage id="crafting_monitor" scale="4" />

  <BlockImage id="crafting_unit" scale="4" />
</Row>

Les CPU de fabrication gèrent les demandes et les tâches de fabrication. Ils stockent les ingrédients intermédiaires pendant l'exécution des tâches de fabrication
comportant plusieurs étapes, et déterminent la taille maximale des tâches ainsi que, dans une certaine mesure, leur vitesse d'exécution. Voir [l'autofabrication](../ae2-mechanics/autocrafting.md)
pour plus de détails.

Chaque CPU de fabrication gère 1 demande ou tâche : si vous voulez demander en même temps un processeur de calcul et 256 pierres lisses, il vous faut 2 multiblocs CPU.

Ils peuvent être réglés pour traiter les demandes des joueurs, celles de l'automatisation (bus d'exportation et interfaces), ou les deux.

Un clic droit sur l'un d'eux ouvre une interface d'état de fabrication où vous pouvez suivre la progression de la tâche de fabrication gérée par ce CPU.

## Réglages

*   Le CPU peut être réglé pour n'accepter que les demandes des joueurs, uniquement celles de l'automatisation (comme les <ItemLink id="export_bus" /> équipés de
    <ItemLink id="crafting_card" />), ou les deux.

## Construction

Les CPU de fabrication sont des multiblocs, et doivent former des prismes rectangulaires pleins, sans trou. Ils sont composés de plusieurs éléments.

Chaque CPU doit contenir au moins 1 bloc de stockage de fabrication (et le CPU viable minimal est en fait un simple stockage de fabrication 1k).

# Unité de fabrication

<BlockImage id="crafting_unit" scale="4" />

(Optionnel) Les unités de fabrication servent simplement à combler l'espace dans un CPU afin d'en faire un prisme rectangulaire plein, si vous n'avez pas assez
des autres éléments. Elles sont aussi un ingrédient de base des autres éléments.

<RecipeFor id="crafting_unit" />

# Stockage de fabrication

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="4k_crafting_storage" scale="4" />

  <BlockImage id="16k_crafting_storage" scale="4" />

  <BlockImage id="64k_crafting_storage" scale="4" />

  <BlockImage id="256k_crafting_storage" scale="4" />
</Row>

(Requis) Les stockages de fabrication existent dans toutes les tailles de disque standard (1k, 4k, 16k, 64k, 256k). Ils stockent les ingrédients et
les ingrédients intermédiaires impliqués dans une fabrication : il faut donc des stockages plus grands ou plus nombreux pour que le CPU puisse gérer des tâches de fabrication
comportant davantage d'ingrédients.

<Column>
  <Row>
    <RecipeFor id="1k_crafting_storage" />

    <RecipeFor id="4k_crafting_storage" />

    <RecipeFor id="16k_crafting_storage" />
  </Row>

  <Row>
    <RecipeFor id="64k_crafting_storage" />

    <RecipeFor id="256k_crafting_storage" />
  </Row>
</Column>

# Unité de co-traitement de fabrication

<BlockImage id="crafting_accelerator" scale="4" />

(Optionnel) Les coprocesseurs de fabrication font en sorte que le système envoie plus souvent des lots d'ingrédients depuis les <ItemLink id="pattern_provider" />
en accélérant le tic du CPU.
Cela leur permet de suivre le rythme des machines qui traitent rapidement. Par exemple, un fournisseur de pattern entouré
d'<ItemLink id="molecular_assembler" /> peut pousser les ingrédients plus vite qu'un seul assembleur ne peut les traiter, et ainsi
répartir les lots d'ingrédients entre les assembleurs qui l'entourent.

Certaines recettes complexes comportent plusieurs étapes réalisables en parallèle, comme fabriquer des planches et des livres simultanément pour obtenir des bibliothèques.
Dans l'écran d'état de fabrication (accessible par un clic droit sur un CPU ou via l'icône de marteau dans un [terminal](terminals.md)), ces
étapes apparaissent toutes comme « planifiées ». Chaque coprocesseur supplémentaire permet de réaliser une de ces étapes de plus en parallèle (et donc de l'afficher comme « en fabrication »).
Cela reste toutefois peu pertinent, car vous aurez généralement plus de coprocesseurs pour la seule vitesse d'insertion qu'une recette n'a d'étapes réellement parallélisables.

<RecipeFor id="crafting_accelerator" />

# Moniteur de fabrication

<BlockImage id="crafting_monitor" scale="4" />

(Optionnel) Le moniteur de fabrication affiche la tâche que le CPU gère à l'instant présent.
L'écran peut être coloré avec un <ItemLink id="color_applicator" />.

<RecipeFor id="crafting_monitor" />
