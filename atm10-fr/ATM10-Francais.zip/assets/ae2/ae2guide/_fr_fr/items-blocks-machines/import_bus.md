---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bus d'importation ME
  icon: import_bus
  position: 220
categories:
- devices
item_ids:
- ae2:import_bus
---

# Le Bus d'importation

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/import_bus.snbt" />
</GameScene>

Le bus d'importation retire les objets et les fluides (et tout le reste, selon les add-ons) de l'inventaire auquel il est accolé et les pousse dans le
[stockage du réseau](../ae2-mechanics/import-export-storage.md).

Pour limiter le lag, lorsque le bus d'importation n'a rien importé depuis un moment, il passe dans une sorte de
« mode veille » où il fonctionne lentement ; il se réveille et accélère jusqu'à sa pleine vitesse (4 opérations par seconde) dès qu'il importe quelque chose avec succès.

Ce sont des [sous-éléments de câble](../ae2-mechanics/cable-subparts.md).

## Filtrage

Par défaut, le bus importe tout ce à quoi il a accès. Les objets insérés dans ses emplacements de filtre font office de liste blanche : seuls
ces objets précis peuvent alors être importés.

Les objets et les fluides peuvent être glissés dans les emplacements depuis JEI/REI, même si vous n'en possédez aucun.

Faites un clic droit avec un récipient à fluide (comme un seau ou une cuve) pour définir ce fluide comme filtre au lieu du seau ou de la cuve.

## Améliorations

Le bus d'importation accepte les [améliorations](upgrade_cards.md) suivantes :

*   <ItemLink id="capacity_card" /> augmente le nombre d'emplacements de filtre
*   <ItemLink id="speed_card" /> augmente la quantité déplacée par opération
*   <ItemLink id="fuzzy_card" /> permet au bus de filtrer selon le niveau d'usure et/ou d'ignorer les NBT des objets
*   <ItemLink id="inverter_card" /> transforme le filtre de liste blanche en liste noire
*   <ItemLink id="redstone_card" /> ajoute un contrôle par redstone, avec activation sur signal haut, signal bas, ou une fois par impulsion

## Vitesses

| Cartes d'accélération | Objets déplacés par opération |
|:----------------------|:------------------------------|
| 0                     | 1                             |
| 1                     | 8                             |
| 2                     | 32                            |
| 3                     | 64                            |
| 4                     | 96                            |

## Recette

<RecipeFor id="import_bus" />
