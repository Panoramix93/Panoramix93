---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bus à bascule
  icon: toggle_bus
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:toggle_bus
- ae2:inverted_toggle_bus
---

# Le bus à bascule

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/toggle_bus.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Un bus qui fonctionne comme le <ItemLink id="fluix_glass_cable" /> ou les autres câbles, mais dont
l'état de connexion peut être basculé par la redstone. Cela vous permet de couper
une section d'un [réseau ME](../ae2-mechanics/me-network-connections.md).

Lorsqu'un signal de redstone est fourni, l'élément active la connexion ; le <ItemLink id="inverted_toggle_bus" /> a le comportement
inverse et désactive alors la connexion.

À noter : basculer ces bus peut provoquer un redémarrage du réseau et un recalcul des appareils connectés.

Ce sont des [sous-éléments de câble](../ae2-mechanics/cable-subparts.md).

## Recettes

<RecipeFor id="toggle_bus" />

<RecipeFor id="inverted_toggle_bus" />
