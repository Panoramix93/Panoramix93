---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Applicateur de couleur
  icon: color_applicator
  position: 410
categories:
- tools
item_ids:
- ae2:color_applicator
---

# L'Applicateur de couleur

<ItemImage id="color_applicator" scale="4" />

L'applicateur de couleur sert à peindre les blocs colorables comme les [câbles](cables.md), la laine, la terre cuite, le verre et le béton. Il utilise
des [boules de peinture](paintballs.md) ou des teintures, et les boules de neige permettent de nettoyer la couleur des câbles et les taches de peinture sur les blocs.

Son énergie peut être rechargée dans un <ItemLink id="charger" />.

Les applicateurs de couleur se comportent comme des [disques de stockage](storage_cells.md), et le plus simple pour remplir leur réserve de peinture est de
placer l'applicateur dans l'emplacement à disque de stockage d'un <ItemLink id="chest" />

Faites un clic droit sur une cible pour appliquer la couleur sélectionnée. Pour changer de couleur, utilisez la molette en maintenant Maj, ou faites un clic droit sans viser de cible.

## Améliorations

Les applicateurs de couleur acceptent les [améliorations](upgrade_cards.md) suivantes, insérées via un <ItemLink id="cell_workbench" /> :

*   <ItemLink id="equal_distribution_card" /> attribue le même espace d'octets du disque à chaque type, afin qu'un seul type ne puisse pas remplir tout le disque
*   <ItemLink id="void_card" /> détruit les objets insérés lorsque le disque est plein (ou lorsque l'espace attribué à ce type précis est plein, dans le
    cas d'une carte de distribution égale). Attention à bien partitionner le disque avant de l'utiliser !
*   <ItemLink id="energy_card" /> pour augmenter la capacité de leur batterie

## Recette

<RecipeFor id="color_applicator" />
