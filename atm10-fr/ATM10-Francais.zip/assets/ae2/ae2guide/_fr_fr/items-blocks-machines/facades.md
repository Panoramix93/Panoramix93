---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Façades
  icon: facade
  icon_components:
    "ae2:facade_item": "minecraft:stone"
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:facade
---

# Façades

Les façades permettent de donner un aspect plus net à votre base. Elles peuvent recouvrir les deux tailles de câble et être fabriquées à partir de
nombreux types de blocs.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/facades_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Elles peuvent recouvrir toutes les faces d'un câble, mais laissent dépasser les [éléments](../ae2-mechanics/cable-subparts.md) et les
connexions de câble.

<GameScene zoom="6"  interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Soyez astucieux avec elles pour améliorer l'esthétique de votre base ou créer des blocs dont chaque face a une texture différente.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_3.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Masquer les façades

Les façades sont masquées lorsque vous tenez un <a href="network_tool.md">outil réseau</a> dans l'une ou l'autre main.

Vous pouvez interagir avec les blocs situés derrière des façades masquées sans avoir à retirer les façades au préalable.

## Recette

Placez le bloc dont vous voulez la texture au milieu de 4 <ItemLink id="cable_anchor" />.

![Recette de façade](../assets/diagrams/facade_recipe.png)
