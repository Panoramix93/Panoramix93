---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cristal de Fluix
  icon: fluix_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_crystal
---

# Le cristal de Fluix

<ItemImage id="fluix_crystal" scale="4" />

*« Les cristaux de Fluix possèdent la capacité unique d'absorber l'énergie et de la convertir d'une forme à une autre ; ils sont le fondement de
toute la technologie Matter Energy. »*

L'un des principaux ingrédients des blocs, [dispositifs](../ae2-mechanics/devices.md) et objets d'AE2. Il s'obtient en jetant du quartz du Nether, de la redstone et
un <ItemLink id="charged_certus_quartz_crystal" /> dans l'eau.

Le procédé peut être [automatisé](../example-setups/throw-in-water-automation.md) à l'aide d'un <ItemLink id="formation_plane" /> et d'un <ItemLink id="annihilation_plane" />.

## Recettes

<Row>
  <Recipe id="transform/fluix_crystals" />

  <Recipe id="transform/fluix_crystal" />

  <Recipe id="misc/deconstruction_fluix_block" />
</Row>
