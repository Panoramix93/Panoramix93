---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Point d'accès sans fil
  icon: wireless_access_point
  position: 210
categories:
- devices
item_ids:
- ae2:wireless_booster
- ae2:wireless_access_point
---

# Le point d'accès sans fil

<BlockImage id="wireless_access_point" p:state="has_channel" scale="8" />

Permet un accès sans fil au moyen d'un <ItemLink id="wireless_terminal" />.
La portée et la consommation d'énergie dépendent du nombre d'<ItemLink id="wireless_booster" /> installés.

Un réseau peut comporter autant de points d'accès sans fil que vous le souhaitez, avec un nombre quelconque
d'<ItemLink id="wireless_booster" /> dans chacun, ce qui vous permet d'optimiser la consommation d'énergie
et la portée en adaptant votre montage.

Nécessite un [canal](../ae2-mechanics/channels.md).

Sert aussi à lier les [terminaux sans fil](wireless_terminals.md)

# Amplificateur sans fil

<ItemImage id="wireless_booster" scale="2" />

Sert à augmenter la portée du point d'accès sans fil.

## Recettes

<RecipeFor id="wireless_access_point" />

<RecipeFor id="wireless_booster" />
