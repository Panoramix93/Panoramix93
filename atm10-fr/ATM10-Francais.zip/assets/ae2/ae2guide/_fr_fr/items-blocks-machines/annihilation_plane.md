---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Plan d'annihilation
  icon: annihilation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:annihilation_plane
---

# Le Plan d'annihilation

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/annihilation_plane.snbt" />
</GameScene>

Le Plan d'annihilation casse les blocs et ramasse les objets. Il fonctionne comme un <ItemLink id="import_bus" />, en poussant les éléments
dans le [stockage du réseau](../ae2-mechanics/import-export-storage.md). Pour que les objets soient ramassés, ils doivent entrer en contact avec la
face du plan : celui-ci ne ramasse pas dans une zone.

Les plans d'annihilation peuvent être enchantés avec n'importe quel enchantement de pioche, donc oui, vous pouvez mettre des niveaux délirants de fortune sur quelques-uns et
[automatiser le traitement du minerai](../example-setups/ore-fortuner.md) si votre modpack l'autorise. De plus, la toucher de soie fait ce à quoi
vous vous attendez, l'efficacité réduit le coût en énergie du cassage d'un bloc, et la solidité donne une chance de ne consommer aucune énergie.

Il s'agit d'[éléments de câble](../ae2-mechanics/cable-subparts.md).

**PENSEZ À AUTORISER LES FAUX JOUEURS DANS VOTRE REVENDICATION DE CHUNK**

## Filtrage

Le plan d'annihilation ne cassera un bloc ou ne ramassera un objet que s'il peut stocker les butins ou objets obtenus
dans son réseau. Autrement dit, pour en filtrer un, *vous devez restreindre ce qui peut être stocké sur son réseau*, le plus probablement en le
plaçant sur un [sous-réseau](../ae2-mechanics/subnetworks.md). Un <ItemLink id="storage_bus" /> ou un [disque](../items-blocks-machines/storage_cells.md)
peut être [partitionné](cell_workbench.md) pour y parvenir.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/annihilation_filtering.snbt" />

  <DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        Filtré sur ce que fait tomber l'élément que vous voulez casser.
  </DiamondAnnotation>

  <DiamondAnnotation pos=".5 0.5 2.5" color="#00ff00">
        Partitionné sur ce que fait tomber l'élément que vous voulez casser.
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Encore une fois, il filtre *selon les objets obtenus*, donc si vous voulez par exemple filtrer le cassage des <ItemLink id="minecraft:amethyst_cluster" />,
il vous faut un plan enchanté avec la toucher de soie, sinon chaque stade de croissance antérieur ne fait rien tomber et le plan les cassera donc quoi
qu'il arrive, puisque le réseau peut toujours stocker « rien ».

## Recette

<RecipeFor id="annihilation_plane" />
