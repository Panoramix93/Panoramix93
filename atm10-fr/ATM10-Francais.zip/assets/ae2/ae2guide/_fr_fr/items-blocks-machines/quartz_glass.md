---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Verre de quartz
  icon: quartz_glass
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_glass
- ae2:quartz_vibrant_glass
---

# Verre de quartz

<BlockImage id="quartz_glass" scale="8" />

Un verre presque transparent fabriqué avec de la <ItemLink id="certus_quartz_dust" />.
Il sert à fabriquer de nombreuses machines et objets d'AE2.

Il en existe une variante, le verre de quartz vibrant, qui émet de la lumière.

## Recettes

<RecipeFor id="quartz_glass" />

<RecipeFor id="quartz_vibrant_glass" />
