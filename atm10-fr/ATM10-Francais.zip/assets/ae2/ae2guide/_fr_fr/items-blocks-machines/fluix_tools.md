---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Outils en fluix
  icon: fluix_pickaxe
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_axe
- ae2:fluix_hoe
- ae2:fluix_shovel
- ae2:fluix_pickaxe
- ae2:fluix_sword
---

# Outils en fluix

<Row>
  <ItemImage id="fluix_axe" scale="4" />

  <ItemImage id="fluix_hoe" scale="4" />

  <ItemImage id="fluix_shovel" scale="4" />

  <ItemImage id="fluix_pickaxe" scale="4" />

  <ItemImage id="fluix_sword" scale="4" />
</Row>

Les outils en [fluix](fluix_crystal.md) sont comparables aux outils en fer, avec 3 fois plus de durabilité et des dégâts d'attaque et une vitesse de minage légèrement supérieurs.

Tous les outils en fluix se comportent comme s'ils avaient au moins Fortune/Butin 1, ce qui est utile avant d'avoir accès à une table d'enchantement.

Vous devrez fabriquer un <ItemLink id="fluix_upgrade_smithing_template" />

## Recettes

<Column>
  <Row>
    <RecipeFor id="fluix_axe" />

    <RecipeFor id="fluix_hoe" />

    <RecipeFor id="fluix_shovel" />
  </Row>

  <Row>
    <RecipeFor id="fluix_pickaxe" />

    <RecipeFor id="fluix_sword" />
  </Row>
</Column>
