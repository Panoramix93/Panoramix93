---
navigation:
  title: Objets, blocs et machines
  position: 50
---

# Objets, blocs et machines

Une liste des éléments du mod, vers lesquels les autres pages peuvent faire des liens, avec une description de leur fonction.

## Ingrédients et blocs divers

<CategoryIndex category="misc ingredients blocks" />

## Infrastructure réseau

<CategoryIndex category="network infrastructure" />

## Appareils

<CategoryIndex category="devices" />

## Machines

<CategoryIndex category="machines" />

## Outils

<CategoryIndex category="tools" />
