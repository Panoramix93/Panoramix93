---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Appliques en quartz
  icon: quartz_fixture
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_fixture
- ae2:light_detector
---

# Appliques en quartz

<Row>
<BlockImage id="quartz_fixture" scale="8" />

<BlockImage id="light_detector" scale="8" />
</Row>

L'applique en quartz chargé est un petit élément décoratif qui émet de la lumière.

L'applique détectrice de lumière émet quant à elle un signal de redstone en fonction du niveau de lumière de son bloc.

## Recettes

<RecipeFor id="quartz_fixture" />

<RecipeFor id="light_detector" />
