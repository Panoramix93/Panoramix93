---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cuve en pierre du ciel
  icon: sky_stone_tank
  position: 310
categories:
- machines
item_ids:
- ae2:sky_stone_tank
---

# La cuve en pierre du ciel

<BlockImage id="sky_stone_tank" scale="8" />

C'est une cuve à fluide qui stocke 16 seaux de fluide. Elle ne conserve pas son contenu lorsqu'on la ramasse. Il n'y a pas grand-chose de plus à en dire.

## Recette

<RecipeFor id="sky_stone_tank" />
