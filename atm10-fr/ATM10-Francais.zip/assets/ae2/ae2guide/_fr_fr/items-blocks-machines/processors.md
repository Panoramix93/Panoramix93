---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Processeurs
  icon: logic_processor
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:logic_processor
- ae2:calculation_processor
- ae2:engineering_processor
- ae2:printed_silicon
- ae2:printed_logic_processor
- ae2:printed_calculation_processor
- ae2:printed_engineering_processor
- ae2:silicon
---

# Processeurs

<Row>
  <ItemImage id="logic_processor" scale="4" />

  <ItemImage id="calculation_processor" scale="4" />

  <ItemImage id="engineering_processor" scale="4" />
</Row>

Les processeurs sont l'un des principaux ingrédients des [appareils](../ae2-mechanics/devices.md) et machines d'AE2. Ils
constituent aussi l'un de vos premiers gros défis d'automatisation. Il existe trois types de processeurs, fabriqués
respectivement avec de l'or, du <ItemLink id="certus_quartz_crystal" /> et du diamant. Ils se fabriquent à l'aide de
[matrices](presses.md) dans un <ItemLink id="inscriber" />, selon un procédé en plusieurs étapes (généralement réalisé
grâce à une série de graveurs et de tuyauterie filtrée).

## Étapes de production

<Column gap="5">
  1.  Rassemblez ou fabriquez les ingrédients nécessaires : silicium, redstone, or, <ItemLink id="certus_quartz_crystal" />, diamant.

  <RecipeFor id="silicon" />

  <br />

  2.  Gravez les composants de circuits imprimés requis

  <Row>
    <RecipeFor id="printed_silicon" />

    <RecipeFor id="printed_logic_processor" />
  </Row>

  <Row>
    <RecipeFor id="printed_calculation_processor" />

    <RecipeFor id="printed_engineering_processor" />
  </Row>

  <br />

  3.  Assemblage final

  <Row>
    <RecipeFor id="logic_processor" />

    <RecipeFor id="calculation_processor" />
  </Row>

  <RecipeFor id="engineering_processor" />
</Column>
