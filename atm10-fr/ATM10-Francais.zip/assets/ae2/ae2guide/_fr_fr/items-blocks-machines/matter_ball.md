---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Boule de matière
  icon: matter_ball
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:matter_ball
---

# Boules de matière

<ItemImage id="matter_ball" scale="4" />

Une boule de matière générique, utile comme munition pour un <ItemLink id="matter_cannon" /> ou pour produire des [billes de peinture](paintballs.md).

Fabriquée avec 256 objets ou seaux dans un <ItemLink id="condenser" /> réglé en mode boule de matière.
