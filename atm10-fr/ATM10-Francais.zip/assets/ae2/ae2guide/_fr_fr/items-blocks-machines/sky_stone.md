---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pierre de ciel
  icon: sky_stone_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_stone_block
- ae2:smooth_sky_stone_block
---

# Pierre de ciel

<BlockImage id="sky_stone_block" scale="8" />

Le matériau dont sont faites les [météorites](../ae2-mechanics/meteorites.md), utilisé dans les recettes de la <ItemLink id="sky_stone_tank" />, du <ItemLink id="not_so_mysterious_cube" />,
du <ItemLink id="cell_component_256k" /> et, surtout, du <ItemLink id="controller" />.

## Recettes

placez un plan d'annihilation orienté vers le haut à la hauteur maximale du monde pour obtenir de la poussière de pierre de ciel

<RecipeFor id="sky_stone_block" />

<RecipeFor id="smooth_sky_stone_block" />
