---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Port d'E/S spatiale
  icon: spatial_io_port
  position: 210
categories:
- devices 
item_ids:
- ae2:spatial_io_port
---

# Le port d'E/S spatiale

<BlockImage id="spatial_io_port" p:powered="true" scale="8" />

Le port d'E/S spatiale est utilisé dans l'[E/S spatiale](../ae2-mechanics/spatial-io.md) pour accueillir le [disque spatial](spatial_cells.md)
et piloter l'opération d'E/S spatiale.

Le disque peut être inséré et extrait par n'importe quel système de logistique d'objets, comme des entonnoirs ou des bus AE2, si vous souhaitez l'automatiser.

## Recette

<RecipeFor id="spatial_io_port" />
