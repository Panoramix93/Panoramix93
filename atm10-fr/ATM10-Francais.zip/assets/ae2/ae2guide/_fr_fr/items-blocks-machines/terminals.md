---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Terminaux
  icon: crafting_terminal
  position: 210
categories:
- devices
item_ids:
- ae2:terminal
- ae2:crafting_terminal
- ae2:pattern_encoding_terminal
- ae2:pattern_access_terminal
---

# Terminaux

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminals.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Si les <ItemLink id="pattern_provider" />s, les <ItemLink id="import_bus" />s, les <ItemLink id="storage_bus" />s et compagnie
sont le principal moyen par lequel un réseau AE2 interagit avec le monde, les terminaux sont le principal moyen par lequel un réseau
AE2 interagit avec *vous*. Il en existe plusieurs variantes, aux fonctions différentes.

Les terminaux prennent la couleur du [câble](cables.md) sur lequel ils sont posés.

Ce sont des [sous-éléments de câble](../ae2-mechanics/cable-subparts.md).

## Placement d'un terminal

Comme un terminal est souvent le premier [sous-élément](../ae2-mechanics/cable-subparts.md) que l'on pose,
il est fréquent de se tromper et de le placer à l'envers. Voici un exemple de ce qu'il faut faire et de ce qu'il ne faut pas faire :

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminal_placement.snbt" />
  <IsometricCamera yaw="195" pitch="30" />

  <LineAnnotation color="#ff3333" from="2.5 .5 .5" to="4.5 2.5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="2.5 2.5 .5" to="4.5 .5 .5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="-.5 2.5 .5" to="1 .5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1 .5 .5" to="1.5 1 .5" alwaysOnTop={true} thickness="0.05"/>
</GameScene>

Vous avez toujours un terminal et un accepteur d'énergie, sauf que cette fois le terminal est dans le bon sens et réellement
connecté au réseau, et en plus tout cela tient dans moins de place.

<a name="terminal-ui"></a>

# Recherche dans un terminal

La barre de recherche accepte les expressions régulières (Regex) : vous pouvez par exemple écrire « gtceu:.*ore » pour obtenir tous les
minerais de Gregtech. L'apprentissage des Regex est laissé en exercice au lecteur.

# Terminal

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Le terminal de base, qui vous permet de consulter et d'utiliser le contenu du [stockage de votre réseau](../ae2-mechanics/import-export-storage.md)
et de demander des objets à votre installation de [fabrication automatique](../ae2-mechanics/autocrafting.md).

## L'interface

L'interface d'un terminal de base comporte plusieurs sections.

La section centrale donne accès au stockage de votre réseau. Vous pouvez y déposer et y prendre des objets. Plusieurs
raccourcis souris/clavier sont disponibles :

*   Le clic gauche prend une pile, le clic droit une demi-pile.
*   Si un objet, un fluide, etc. peut être [fabriqué automatiquement](../ae2-mechanics/autocrafting.md),
    la touche associée à « sélectionner le bloc » (en général le clic du milieu) ouvre une interface pour préciser la quantité à fabriquer. Vous pouvez aussi saisir des formules comme `3*64/2`,
    ou taper `=32` pour ne fabriquer que le nombre d'objets nécessaire pour atteindre 32 dans votre stockage.
*   Maintenir la touche Maj fige l'affichage des objets, ce qui les empêche de se réorganiser quand les quantités changent ou que de nouveaux objets entrent dans le système.
*   Un clic droit avec un seau ou un autre récipient à fluide y dépose le fluide ; un clic gauche sur un fluide du terminal avec
    un récipient à fluide vide en retire le fluide.

La section de gauche contient des boutons de réglage permettant de :

*   Trier selon différents critères comme le nom, le mod et la quantité
*   Afficher les objets stockés, les objets fabricables, ou les deux
*   Afficher les objets, les fluides, ou les deux
*   Changer l'ordre de tri
*   Ouvrir la fenêtre de réglages détaillés du terminal
*   Changer la hauteur de l'interface du terminal

À droite se trouvent des emplacements pour les <ItemLink id="view_cell" />s

En haut à droite de la section centrale, le bouton en forme de marteau ouvre l'interface d'état de la
[fabrication automatique](../ae2-mechanics/autocrafting.md), qui vous permet de suivre l'avancement de vos fabrications et de voir ce que fait chaque
[CPU de fabrication](crafting_cpu_multiblock.md).

## Recette

<RecipeFor id="terminal" />

<a name="crafting-terminal-ui"></a>

# Terminal de fabrication

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/crafting_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Le Terminal de fabrication ressemble à un terminal classique, avec les mêmes réglages et les mêmes sections, mais il dispose en plus d'une grille de fabrication qui est automatiquement
réapprovisionnée depuis le [stockage du réseau](../ae2-mechanics/import-export-storage.md). Attention lorsque vous faites Maj + clic sur le résultat !

Vous devriez remplacer votre terminal par un terminal de fabrication dès que possible.

## L'interface

Le terminal de fabrication a la même interface que le terminal classique, avec une grille de fabrication ajoutée au centre.

Il comporte 2 boutons supplémentaires, pour vider la grille de fabrication vers le stockage du réseau ou vers votre inventaire.

## Recette

<RecipeFor id="crafting_terminal" />

<a name="pattern-encoding-terminal-ui"></a>

# Terminal d'encodage de pattern

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_encoding_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Le Terminal d'encodage de pattern ressemble à un terminal classique, avec les mêmes réglages et les mêmes sections, mais il dispose en plus d'une
interface d'encodage de [patterns](patterns.md). Elle ressemble à l'interface d'un terminal de fabrication, mais cette grille de fabrication ne
réalise pas réellement de fabrication.

Vous devriez en avoir un en plus d'un terminal de fabrication.

## L'interface

Le terminal de fabrication a la même interface que le terminal classique, avec l'interface d'encodage de [patterns](patterns.md) en plus.

L'interface d'encodage de pattern comporte plusieurs sections :

Un emplacement pour insérer des <ItemLink id="blank_pattern" />s.

Une grande flèche pour encoder le pattern.

Un emplacement pour les patterns encodés. Placez dans cet emplacement un pattern déjà encodé pour le modifier, puis cliquez sur la flèche « encoder ».

4 onglets sur la droite pour changer le type de pattern à encoder parmi

*   Fabrication
*   Traitement
*   Forge
*   Taille de la pierre

L'interface centrale change selon le type de pattern à encoder :

*   En mode fabrication :
    *   Faites un clic gauche ou glissez les ingrédients depuis JEI/REI pour composer la recette. Le clic droit retire l'ingrédient.
    *   Activer les substitutions permet par exemple de fabriquer des bâtons à partir de n'importe quel type de planche. À n'utiliser
        qu'en cas de nécessité absolue.
    *   Les substitutions de fluides permettent d'utiliser les fluides stockés à la place des seaux de fluides.
    *   Vous pouvez aussi encoder un pattern directement depuis l'écran de recette de JEI/REI.

*   En mode traitement :
    * Faites un clic gauche ou droit, ou glissez les ingrédients depuis JEI/REI, pour définir les entrées et les sorties de la recette.
    * Faites un clic droit avec un récipient à fluide (comme un seau ou une cuve) pour définir ce fluide comme ingrédient au lieu du seau ou de la cuve.
    * Lorsque vous tenez une pile, le clic gauche place la pile entière et le clic droit un seul objet. Le clic gauche sur une pile d'ingrédients existante
        la retire entièrement, et le clic droit la réduit de 1. La touche associée à « sélectionner le bloc » (en général le clic du milieu)
        vous permet d'indiquer une quantité précise de l'objet ou du fluide.
    * Les emplacements de sortie comportent une sortie principale et de la place pour les éventuelles sorties secondaires que vous voulez faire connaître à l'algorithme de fabrication automatique.
    * Les emplacements d'entrée comme de sortie défilent, vous pouvez donc avoir 81 ingrédients différents et 26 sorties secondaires
    * Vous pouvez aussi encoder un pattern directement depuis l'écran de recette de JEI/REI.

*   Les interfaces des modes forge et taille de la pierre fonctionnent comme une table de forge et un tailleur de pierre respectivement.

## Recette

<RecipeFor id="pattern_encoding_terminal" />

<a name="pattern-access-terminal-ui"></a>

# Terminal d'accès aux patterns

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_access_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Le Terminal d'accès aux patterns répond à un problème précis : dans une tour dense de <ItemLink id="pattern_provider" />s
et d'<ItemLink id="molecular_assembler" />s, vous ne pouvez pas accéder physiquement aux fournisseurs pour y insérer de nouveaux patterns. Et puis,
peut-être que vous êtes paresseux et que vous ne voulez pas traverser toute votre base pour insérer un [pattern](patterns.md). Le terminal d'accès aux patterns
donne accès à tous les fournisseurs de pattern du réseau.

## L'interface

Ce terminal a une interface différente de celle de tous les autres terminaux.

Il propose des réglages pour la hauteur du terminal et pour les fournisseurs de pattern à afficher.

Chaque ligne du terminal correspond à un fournisseur de pattern précis.

Les fournisseurs de pattern y sont triés selon les blocs auxquels ils sont connectés, ou selon le nom que vous leur avez donné (avec une enclume ou
avec une <ItemLink id="name_press" />).

## Recette

<RecipeFor id="pattern_access_terminal" />
