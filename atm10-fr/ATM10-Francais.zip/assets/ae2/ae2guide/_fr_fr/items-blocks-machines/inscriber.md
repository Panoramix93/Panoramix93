---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Presse
  icon: inscriber
  position: 310
categories:
- machines
item_ids:
- ae2:inscriber
---

# La Presse

<BlockImage id="inscriber" scale="8" />

La presse sert à graver des circuits et des [processeurs](processors.md) à l'aide de [matrices](presses.md), ainsi qu'à broyer divers objets en poudre.
Elle accepte aussi bien l'énergie d'AE2 (AE) que la Fabric/Forge Energy (E/FE). Elle peut fonctionner par faces, de sorte qu'insérer des objets par des faces différentes
les envoie dans des emplacements différents de son inventaire. Pour faciliter cela, elle peut être tournée avec une <ItemLink id="certus_quartz_wrench" />.
Elle peut aussi être réglée pour pousser les résultats des fabrications vers les inventaires adjacents.

La taille du tampon d'entrée est réglable. Par exemple, si vous voulez alimenter un grand ensemble de presses depuis un seul inventaire,
mieux vaut un petit tampon afin que les matériaux soient répartis de façon plus optimale entre les presses (au lieu que la première
presse se remplisse jusqu'à 64 et que les autres restent vides).

Les 4 matrices de circuits servent à fabriquer les [processeurs](processors.md)

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

La matrice de nom, elle, permet de nommer des blocs comme le ferait une enclume, ce qui est pratique pour étiqueter les choses dans un <ItemLink id="pattern_access_terminal" />.

<ItemImage id="name_press" scale="4" />

## Réglages

* La presse peut être réglée pour fonctionner par faces (comme expliqué ci-dessous) ou pour accepter les entrées dans n'importe quel emplacement depuis n'importe quelle face, un filtre interne décidant
    de ce qui va où. En mode sans distinction de face, les objets ne peuvent pas être extraits des emplacements du haut et du bas.
* La presse peut être réglée pour pousser les objets dans les inventaires adjacents.
* La taille du tampon d'entrée est réglable : l'option « grand » convient à une presse isolée que vous alimentez à la main, l'option
« petit » rend les grosses installations parallélisées plus viables.

## L'interface et les faces

En mode par faces, la presse détermine ce qui va où selon la face par laquelle vous insérez ou extrayez.

![Inscriber GUI](../assets/diagrams/inscriber_gui.png) ![Inscriber Sides](../assets/diagrams/inscriber_sides.png)

A. **Entrée du haut**, accessible par la face supérieure de la presse (les objets peuvent être poussés dans cet emplacement comme en être retirés)

B. **Entrée centrale**, alimentée par les faces gauche, droite, avant et arrière de la presse (les objets peuvent seulement être poussés dans cet emplacement, pas en être retirés)

C. **Entrée du bas**, accessible par la face inférieure de la presse (les objets peuvent être poussés dans cet emplacement comme en être retirés)

D. **Sortie**, dont on retire les objets par les faces gauche, droite, avant et arrière de la presse (les objets peuvent seulement être retirés de cet emplacement, pas y être poussés)

## Automatisation simple

Par exemple, la gestion des faces et la possibilité de rotation permettent de semi-automatiser les presses de la façon suivante :

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/inscriber_hopper_automation.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Ou bien, en mode sans distinction de face, il suffit de brancher des tuyaux en entrée et en sortie de la presse.

## Améliorations

La presse accepte les [améliorations](upgrade_cards.md) suivantes :

*   <ItemLink id="speed_card" />

## Recette

<RecipeFor id="inscriber" />
