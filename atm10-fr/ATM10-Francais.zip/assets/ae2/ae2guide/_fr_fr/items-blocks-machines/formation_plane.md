---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Plan de formation
  icon: formation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:formation_plane
---

# Le Plan de formation

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/formation_plane.snbt" />
</GameScene>

Le Plan de formation place des blocs et fait tomber des objets. Il fonctionne comme un <ItemLink id="storage_bus" /> en insertion seule :
il place ou fait tomber les éléments lorsqu'ils y sont « stockés » par des [appareils](../ae2-mechanics/devices.md) qui insèrent dans le [stockage du réseau](../ae2-mechanics/import-export-storage.md),
comme les <ItemLink id="import_bus" /> et les <ItemLink id="interface" />.

<GameScene zoom="8" interactive={true}>
  <ImportStructure src="../assets/assemblies/formation_plane_demonstration.snbt" />
  <IsometricCamera yaw="255" pitch="30" />
</GameScene>

Remarquez que cela ressemble aux tuyaux bus d'importation -> bus de stockage ME et interface -> bus de stockage ME des [sous-réseaux en tuyau](../example-setups/pipe-subnet.md).

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage_pipe.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Cet [appareil](../ae2-mechanics/devices.md) exploite les mécanismes utilisés par les bus de stockage ME dans des montages comme les [sous-réseaux en tuyau](../example-setups/pipe-subnet.md),
et peut remplacer les bus de stockage ME dans ces installations si vous voulez faire tomber des objets ou placer des blocs plutôt que transporter des objets.

Il s'agit d'[éléments de câble](../ae2-mechanics/cable-subparts.md).

**PENSEZ À AUTORISER LES FAUX JOUEURS DANS VOTRE REVENDICATION DE CHUNK**

## Filtrage

Par défaut, le plan place ou fait tomber n'importe quoi. Les objets insérés dans ses emplacements de filtre font office de liste blanche et
n'autorisent que ces objets précis à être placés.

Les objets et les fluides peuvent être glissés dans les emplacements depuis JEI/REI même si vous ne possédez pas réellement l'objet en question.

Faites un clic droit avec un conteneur de fluide (comme un seau ou une cuve) pour définir ce fluide comme filtre, au lieu du seau ou de la cuve elle-même.

## Priorité

Les priorités se règlent en cliquant sur la clé en haut à droite de l'interface.
Les objets qui entrent dans le réseau commencent par le stockage de priorité la plus élevée.

## Réglages

*   Le plan peut être réglé pour placer des blocs dans le monde ou faire tomber des objets

## Améliorations

Le plan de formation prend en charge les [améliorations](upgrade_cards.md) suivantes :

*   <ItemLink id="capacity_card" /> augmente le nombre d'emplacements de filtre
*   <ItemLink id="fuzzy_card" /> permet au plan de filtrer selon le niveau de dégâts et/ou d'ignorer les NBT de l'objet
*   <ItemLink id="inverter_card" /> fait passer le filtre d'une liste blanche à une liste noire

## Recette

<RecipeFor id="formation_plane" />
