---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Modèle de forge Fluix
  icon: fluix_upgrade_smithing_template
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_upgrade_smithing_template
---

<ItemImage id="fluix_upgrade_smithing_template" scale="8" />

# Modèle de forge Fluix

Contrairement au modèle de forge vanilla, celui-ci peut être fabriqué de zéro.

Nécessaire pour les [outils en Fluix](fluix_tools.md)

## Recette

<RecipeFor id="fluix_upgrade_smithing_template" />
