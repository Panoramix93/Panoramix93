---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Moniteurs
  icon: storage_monitor
  position: 210
categories:
- devices
item_ids:
- ae2:storage_monitor
- ae2:conversion_monitor
---

# Les moniteurs

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/monitors.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Les moniteurs permettent de visualiser un seul type d'objet ou de fluide et d'interagir avec lui, sans ouvrir d'interface.

Les moniteurs adoptent la couleur du [câble](cables.md) sur lequel ils sont montés.

Si le moniteur est au sol ou au plafond, vous pouvez le tourner avec une <ItemLink id="certus_quartz_wrench" />.

Ce sont des [sous-éléments de câble](../ae2-mechanics/cable-subparts.md).

# Le moniteur de stockage

Il affiche un objet ou un fluide ainsi que sa quantité. Posez-en à côté de vos fermes, par exemple...

Il n'a *pas* besoin de [canal](../ae2-mechanics/channels.md).

Commandes :

*   Clic droit avec un objet, ou double clic droit avec un conteneur de fluide, pour régler le moniteur sur cet objet ou ce fluide.
*   Clic droit à main vide pour réinitialiser le moniteur.
*   Shift + clic droit à main vide pour verrouiller le moniteur.

## Recette

<RecipeFor id="storage_monitor" />

# Le moniteur de conversion

Le moniteur de conversion ressemble au moniteur de stockage, mais il vous permet d'insérer ou d'extraire l'objet qu'il affiche.

Si l'objet configuré est [fabricable automatiquement](../ae2-mechanics/autocrafting.md) et qu'il n'y en a aucun en stock, tenter d'en prendre un
ouvre à la place une interface permettant d'indiquer la quantité à fabriquer.

Il a *bien* besoin d'un [canal](../ae2-mechanics/channels.md).

Commandes supplémentaires :

*   Clic gauche pour extraire une pile de l'objet configuré, ou pour en demander la fabrication s'il n'y en a aucun en stock.
*   Clic droit avec n'importe quel objet pour insérer cet objet.
*   Clic droit à main vide pour insérer tous les exemplaires de l'objet configuré présents dans votre inventaire.

## Recette

<RecipeFor id="conversion_monitor" />
