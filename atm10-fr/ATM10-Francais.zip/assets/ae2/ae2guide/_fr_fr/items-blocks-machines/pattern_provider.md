---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fournisseur de pattern ME
  icon: pattern_provider
  position: 210
categories:
- devices
item_ids:
- ae2:pattern_provider
- ae2:cable_pattern_provider
---

# Le fournisseur de pattern ME

<Row gap="20">
<BlockImage id="pattern_provider" scale="8" />
<BlockImage id="pattern_provider" p:push_direction="up" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

Les fournisseurs de pattern sont le principal moyen par lequel votre système de [fabrication automatique](../ae2-mechanics/autocrafting.md) interagit avec le monde. Ils poussent les ingrédients de
leurs [patterns](patterns.md) vers les inventaires adjacents, et vous pouvez y insérer des objets pour les faire entrer dans le réseau. Vous pouvez souvent
économiser un canal en renvoyant la sortie d'une machine par tuyau vers un fournisseur de pattern voisin (souvent celui qui a poussé les ingrédients)
au lieu d'utiliser un <ItemLink id="import_bus" /> pour tirer la sortie de la machine dans le réseau.

À noter : comme ils poussent les ingrédients directement depuis le [stockage de fabrication](crafting_cpu_multiblock.md#crafting-storage) d'un CPU de fabrication, ils
ne contiennent jamais réellement les ingrédients dans leur inventaire, vous ne pouvez donc pas en extraire par tuyau. Vous devez faire pousser le fournisseur
vers un autre inventaire (un tonneau par exemple), puis tirer depuis celui-ci.

À noter également : le fournisseur doit pousser TOUS les ingrédients d'un coup, il ne peut pas pousser des lots partiels. C'est utile
à exploiter.

Les fournisseurs de pattern ont une interaction particulière avec les interfaces placées sur des [sous-réseaux](../ae2-mechanics/subnetworks.md) : si l'interface n'est pas modifiée (rien dans les emplacements de requête),
le fournisseur ignore complètement l'interface et pousse directement vers le [stockage](../ae2-mechanics/import-export-storage.md) de ce sous-réseau,
sans passer par l'interface, donc sans la remplir de lots de recette et, surtout, sans insérer le lot suivant avant qu'il y ait de la place dans la machine.
Cela fonctionne correctement avec le mode blocage : le fournisseur surveille les emplacements de la machine à la recherche d'ingrédients, au lieu de ceux de l'interface.

Par exemple, cette installation pousse à la fois l'objet à fondre et le combustible directement dans les emplacements correspondants du four.
Vous pouvez utiliser cette astuce pour fournir des patterns sur plusieurs faces d'une machine, ou sur plusieurs machines.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Fournisseur de pattern : la variante directionnelle, obtenue avec une clé en quartz Certus, avec les patterns de traitement correspondants.

        ![Pattern de fer](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (2) Interface : dans sa configuration par défaut.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        (3) Bus de stockage ME n° 1 : filtré sur le charbon.
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        (4) Bus de stockage ME n° 2 : filtré pour exclure le charbon, à l'aide d'une carte d'inversion.
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        Vers le réseau principal
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Voici une illustration générale de la fourniture vers plusieurs machines

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Interface (doit être en version plate, pas en bloc plein)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Bus de stockage ME
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        Les endroits où vous voulez fournir vos patterns
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

Plusieurs fournisseurs de pattern contenant des patterns identiques sont pris en charge et fonctionnent en parallèle.

Les fournisseurs de pattern essaient de répartir leurs lots à tour de rôle sur toutes leurs faces, utilisant ainsi en parallèle toutes les machines attachées.

## Variantes

Les fournisseurs de pattern existent en 3 variantes : normale, directionnelle et plate/[sous-élément](../ae2-mechanics/cable-subparts.md). Cela détermine les faces précises vers lesquelles ils poussent
les ingrédients, celles depuis lesquelles ils reçoivent des objets et celles auxquelles ils fournissent une connexion réseau.

* Les fournisseurs de pattern normaux poussent les ingrédients sur toutes les faces, reçoivent des entrées sur toutes les faces et, comme la plupart des machines d'AE2, se comportent
    comme un câble en fournissant des [connexions réseau](../ae2-mechanics/me-network-connections.md) sur toutes les faces.

* Les fournisseurs de pattern directionnels s'obtiennent en utilisant une <ItemLink id="certus_quartz_wrench" /> sur un fournisseur de pattern normal pour changer sa
    direction. Ils ne poussent les ingrédients que vers la face sélectionnée, reçoivent des entrées sur toutes les faces et, spécifiquement, ne fournissent pas de
  [connexion réseau](../ae2-mechanics/me-network-connections.md) sur la face sélectionnée. Cela leur permet de pousser vers des machines AE2 sans relier les réseaux, si vous voulez créer un sous-réseau.

* Les fournisseurs de pattern plats sont des [sous-éléments de câble](../ae2-mechanics/cable-subparts.md), on peut donc en placer plusieurs sur le même câble, ce qui permet des installations compactes.
    Ils se comportent comme la face sélectionnée d'un fournisseur de pattern directionnel : ils fournissent les patterns, reçoivent les entrées et ne fournissent **pas**
    de [connexion réseau](../ae2-mechanics/me-network-connections.md) sur leur face.

Les fournisseurs de pattern peuvent être convertis de la version normale à la version plate (et inversement) dans une grille de fabrication.

## Réglages

Les fournisseurs de pattern disposent de plusieurs modes :

*   Le **mode blocage** empêche le fournisseur de pousser un nouveau lot d'ingrédients s'il y a déjà
    des ingrédients dans la machine.
*   Le **verrouillage de fabrication** peut bloquer le fournisseur selon diverses conditions de redstone, ou jusqu'à ce que le résultat de la
    fabrication précédente soit inséré dans ce fournisseur de pattern précis.
*   Le fournisseur peut être affiché ou masqué sur les <ItemLink id="pattern_access_terminal" />.

## Priorité

Les priorités se règlent en cliquant sur la clé en haut à droite de l'interface. Lorsque plusieurs [patterns](patterns.md)
existent pour le même objet, les patterns des fournisseurs de priorité plus élevée seront utilisés avant ceux des fournisseurs de priorité plus faible,
sauf si le réseau ne possède pas les ingrédients du pattern le plus prioritaire.

## Une erreur fréquente

Pour une raison qui m'échappe, les gens continuent de faire ça, alors je le mets ici en espérant que ça aide. (Peut-être que
certains se trompent en pensant qu'un <ItemLink id="export_bus" /> est le seul moyen de faire sortir des choses du réseau, sans savoir
que les fournisseurs de pattern exportent aussi des objets.)

Ceci ne fera pas ce que vous attendez. Comme indiqué dans [câbles](cables.md), les câbles ne sont pas des tuyaux à objets, ils n'ont aucun inventaire
interne, les fournisseurs ne pousseront rien dedans.

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_1.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        Ceci n'est pas un haut fourneau
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

Comme le fournisseur n'a rien vers quoi pousser, il ne
pourra pas fonctionner. Tout ce qu'il fait ici, c'est se comporter comme un câble, en reliant le <ItemLink id="export_bus" /> au
réseau.

Le fournisseur ne dira pas non plus au <ItemLink id="export_bus" /> quoi exporter : le bus d'exportation exportera simplement
tout ce que vous mettez dans son filtre.

Ce que nous avons fait ici revient en réalité à ceci :

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_2.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        Ceci n'est pas un haut fourneau
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

Ce que vous voulez probablement construire, c'est plutôt ceci, où le fournisseur de pattern peut exporter le contenu de ses patterns vers
la machine adjacente :

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_3.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        Ceci n'est pas un haut fourneau
  </BoxAnnotation>

  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

## Utilisation avec les assembleurs moléculaires

Les <ItemLink id="molecular_assembler" /> se comportent en gros comme n'importe quelle autre machine. Ils ont un inventaire dans lequel on peut insérer
des objets, ils effectuent ensuite une action sur le contenu de cet inventaire puis, comme beaucoup de machines, ils poussent le résultat vers un
inventaire adjacent. Ils doivent donc être utilisés avec des fournisseurs comme n'importe quelle autre machine, avec un ajout :

Les assembleurs peuvent prendre le pattern souhaité dans un <ItemLink id="crafting_pattern" />, un <ItemLink id="smithing_table_pattern" /> ou un <ItemLink id="stonecutting_pattern" />
inséré directement dans l'assembleur.
C'est pratique dans une chaîne d'assemblage, mais devoir consacrer un assembleur à chaque recette de fabrication serait pénible.

C'est pourquoi les fournisseurs de pattern ont une fonctionnalité spéciale avec les assembleurs : ils peuvent envoyer les données du pattern en même temps que les ingrédients.
Ainsi, il vous suffit de placer un assembleur à côté d'un fournisseur de pattern, et le fournisseur peut alors utiliser cet assembleur pour tous ses
patterns de fabrication, de forge et de taille de pierre.

C'est aussi simple que ça, il suffit de mettre les patterns dans les fournisseurs :

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

*Notez que cette installation comporte exactement 8 fournisseurs, soit le nombre maximum de canaux pouvant être acheminés par un seul assembleur, fournisseur ou
câble non dense.*

## Recettes

<RecipeFor id="pattern_provider" />

<RecipeFor id="cable_pattern_provider" />
