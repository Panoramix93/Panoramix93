---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cube mystérieux
  icon: mysterious_cube
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:mysterious_cube
- ae2:not_so_mysterious_cube
---

# Le cube mystérieux

<BlockImage id="mysterious_cube" scale="8" />

Vous vous souvenez de l'époque où il fallait trouver une quantité de météores pour récupérer toutes les presses ? C'est fini ! Les météorites contiennent désormais un cube mystérieux.

Je me demande ce qui se passe quand on le casse (sans toucher de soie)...

Vous pouvez aussi en fabriquer une réplique, le cube pas si mystérieux

## Recette

<RecipeFor id="not_so_mysterious_cube" />
