---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Panneaux lumineux
  icon: semi_dark_monitor
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:monitor
- ae2:semi_dark_monitor
- ae2:dark_monitor
---

# Panneaux lumineux

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/illuminated_panels.snbt" />
  <IsometricCamera yaw="-75" pitch="30" />
</GameScene>

Les panneaux lumineux sont une source de lumière décorative, également utilisée dans la fabrication des [terminaux](terminals.md).

Ce sont des [sous-parties de câble](../ae2-mechanics/cable-subparts.md).

## Recettes

<Row>
  <RecipeFor id="monitor" />

  <RecipeFor id="semi_dark_monitor" />

  <RecipeFor id="dark_monitor" />
</Row>
