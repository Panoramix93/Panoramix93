---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Clés
  icon: certus_quartz_wrench
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_wrench
- ae2:nether_quartz_wrench
---

# Les clés

<Row>
  <ItemImage id="certus_quartz_wrench" scale="4" />

  <ItemImage id="nether_quartz_wrench" scale="4" />
</Row>

Les clés servent à faire tourner les appareils AE2 (clic droit) et à démonter les blocs AE2 (maj + clic droit).
Les [sous-éléments](../ae2-mechanics/cable-subparts.md) peuvent être retirés d'un câble sans casser tout ce qui se trouve sur ce câble
(ou le câble peut être retiré sans casser les sous-éléments).

Beaucoup de blocs AE2 peuvent être tournés : ce n'est pas parce que ce guide ne dit pas qu'un élément peut être tourné que ce n'est pas possible.

## Recettes

<Row>
  <RecipeFor id="certus_quartz_wrench" />

  <RecipeFor id="nether_quartz_wrench" />
</Row>
