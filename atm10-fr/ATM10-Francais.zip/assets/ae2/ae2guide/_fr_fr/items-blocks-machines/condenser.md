---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Matter Condenser
  icon: condenser
  position: 310
categories:
- machines
item_ids:
- ae2:condenser
---

# Le Matter Condenser

<BlockImage id="condenser" scale="8" />

Le Matter Condenser peut servir de poubelle ou bien à créer des <ItemLink id="matter_ball" /> et des
[singularités](singularities.md). Il accepte tout objet, fluide, etc. qu'un disque de stockage peut stocker.

## Réglages et recettes

*   En mode poubelle, le Matter Condenser détruit simplement tout ce qui entre dedans
*   En mode boule de matière, le condenseur fabrique des <ItemLink id="matter_ball" /> à partir de tout ce que vous y mettez.
    Ce mode exige que vous placiez un composant de stockage dans l'emplacement supérieur du condenseur. Chaque boule de matière demande 256 objets ou seaux,
    un <ItemLink id="cell_component_1k" /> (qui offre 8192 bits de capacité) est donc largement suffisant.
*   En mode singularité de matière, le condenseur fabrique des [singularités](singularities.md) à partir de tout ce que vous y mettez.
    Ce mode exige que vous placiez un composant de stockage dans l'emplacement supérieur du condenseur. Chaque singularité demande 256 000 objets ou seaux,
    un <ItemLink id="cell_component_64k" /> (qui offre 524 288 bits de capacité) est donc largement suffisant.

Notez que dans les deux derniers modes, où une ressource est produite, le Matter Condenser *peut* se bloquer et
n'accepte alors plus aucune entrée si les tampons d'énergie et d'objets en sortie sont tous les deux complètement pleins.

## Recette

<RecipeFor id="condenser" />
