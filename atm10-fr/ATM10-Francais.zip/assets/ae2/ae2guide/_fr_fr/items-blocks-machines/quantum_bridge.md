---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pont quantique
  icon: quantum_ring
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quantum_link
- ae2:quantum_ring
---

# Le pont de réseau quantique

![Un pont de réseau quantique formé](../assets/diagrams/quantum_bridge_demonstration.png)

Les ponts de réseau quantique peuvent prolonger un [réseau](../ae2-mechanics/me-network-connections.md) sur des distances infinies, et même entre dimensions.
Ils peuvent transporter 32 canaux au total (quelle que soit la façon dont les câbles sont raccordés à chaque face), se comportant
pour l'essentiel comme un [câble dense](cables.md#dense-cable) sans fil.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_2.snbt" />

  <BoxAnnotation color="#33dd33" min="1 1 1" max="6 2 3">
        Un câble imaginaire entre les deux extrémités
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

À noter : **les deux côtés doivent être chargés en permanence**, il faut donc utiliser un <ItemLink id="spatial_anchor" /> ou un autre chargeur de chunks
si les 2 côtés sont éloignés.

# Anneau quantique

<BlockImage id="quantum_ring" scale="8" />

Huit de ces blocs placés autour d'une <ItemLink id="quantum_link" /> créent un
pont de réseau quantique. Seuls les 4 blocs <ItemLink id="quantum_ring" /> adjacents à la
<ItemLink id="quantum_link" /> acceptent les connexions réseau ;
les 4 blocs d'angle ne peuvent pas être reliés aux câbles.

## Recette

<RecipeFor id="quantum_ring" />

# Chambre de liaison quantique

<BlockImage id="quantum_link" scale="8" />

Un de ces blocs entouré d'un <ItemLink id="quantum_ring" />
crée un pont de réseau quantique. Ce bloc ne se relie à aucun câble et n'est reconnu
comme faisant partie du réseau que lorsque le pont complet est formé.

L'inventaire de ce bloc ne peut contenir qu'une seule <ItemLink id="quantum_entangled_singularity" /> et il est
accessible à l'automatisation.

## Recette

<RecipeFor id="quantum_link" />
