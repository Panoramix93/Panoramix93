---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bâton chargé
  icon: charged_staff
  position: 410
categories:
- tools
item_ids:
- ae2:charged_staff
---

# Le Bâton chargé

<ItemImage id="charged_staff" scale="4" />

Le Bâton chargé est un bâton surmonté d'un <ItemLink id="charged_certus_quartz_crystal" />. Il inflige 6 dégâts et consomme 300 AE
par attaque.

Son énergie peut être rechargée dans un <ItemLink id="charger" />.

## Recette

<RecipeFor id="charged_staff" />
