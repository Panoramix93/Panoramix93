---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bus d'exportation ME
  icon: export_bus
  position: 220
categories:
- devices
item_ids:
- ae2:export_bus
---

# Le bus d'exportation

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/export_bus.snbt" />
</GameScene>

Le bus d'exportation retire des objets et des fluides (et tout le reste, selon les add-ons) du [stockage du réseau](../ae2-mechanics/import-export-storage.md)
et les pousse dans l'inventaire qu'il touche.

Pour réduire le lag, si le bus d'exportation n'a rien exporté récemment, il passe dans une sorte de
« mode veille » où il fonctionne lentement, puis se réveille et accélère à pleine vitesse (4 opérations par seconde) dès qu'il réussit à exporter quelque chose.

Ce sont des [sous-éléments de câble](../ae2-mechanics/cable-subparts.md).

## Filtrage

Par défaut, le bus n'exporte rien. Les objets placés dans ses emplacements de filtre agissent comme une liste blanche
et autorisent l'exportation de ces objets précis.

Les objets et les fluides peuvent être glissés dans les emplacements depuis JEI/REI, même si vous ne possédez en réalité aucun exemplaire de l'objet.

Faites un clic droit avec un conteneur de fluide (comme un seau ou une cuve) pour définir ce fluide comme filtre, au lieu de l'objet seau ou cuve.

## Améliorations

Le bus d'importation prend en charge les [améliorations](upgrade_cards.md) suivantes :

*   <ItemLink id="capacity_card" /> augmente le nombre d'emplacements de filtre et fait apparaître un réglage sur l'ordre d'exportation de ce qui est filtré.
*   <ItemLink id="speed_card" /> augmente la quantité de matière déplacée par opération
*   <ItemLink id="fuzzy_card" /> permet au bus de filtrer selon le niveau d'usure et/ou d'ignorer le NBT des objets
*   <ItemLink id="crafting_card" /> permet au bus d'envoyer des demandes de fabrication à votre système de [fabrication automatique](../ae2-mechanics/autocrafting.md)
    pour obtenir les objets qu'il souhaite. On peut le régler pour qu'il prenne les objets dans le stockage si possible, ou pour qu'il demande toujours
    la fabrication d'un nouvel objet.
*   <ItemLink id="redstone_card" /> ajoute un contrôle par redstone, avec activation sur signal haut, sur signal bas ou une fois par impulsion

## Vitesses

| Cartes d'accélération | Objets déplacés par opération |
|:-------------------|:--------------------------|
| 0                  | 1                         |
| 1                  | 8                         |
| 2                  | 32                        |
| 3                  | 64                        |
| 4                  | 96                        |

## Recette

<RecipeFor id="import_bus" />
