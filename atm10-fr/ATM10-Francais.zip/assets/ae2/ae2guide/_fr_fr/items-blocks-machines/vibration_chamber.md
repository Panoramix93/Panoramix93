---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Chambre à vibration
  icon: vibration_chamber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:vibration_chamber
---

# La chambre à vibration

<BlockImage id="vibration_chamber" p:active="true" scale="8" />

Même si la méthode principale prévue pour fournir de l'[énergie](../ae2-mechanics/energy.md) à votre réseau est l'
<ItemLink id="energy_acceptor" />, la chambre à vibration peut générer directement des quantités faibles à moyennes d'AE.

Par défaut (sans [amélioration](upgrade_cards.md) et avec la configuration d'origine), elle produit 40 AE/t.

Lorsque le stockage d'[énergie](../ae2-mechanics/energy.md) du réseau est plein, la chambre à vibration ralentit pour économiser
du carburant, mais elle ne peut pas s'arrêter complètement.

## Réglages

*   La chambre à vibration donne accès au réglage global d'affichage de l'énergie en AE ou en E/FE.

## Améliorations

La chambre à vibration accepte les [améliorations](upgrade_cards.md) suivantes :

*   <ItemLink id="energy_card" /> augmente le rendement de la chambre de +50 %, jusqu'à un maximum de +150 %, soit 250 % du rendement de base.
*   <ItemLink id="speed_card" /> augmente la vitesse de combustion de la chambre de +50 %, jusqu'à un maximum de +150 %, soit 250 % de la puissance de base.

## Configuration

Les propriétés de la chambre à vibration peuvent être modifiées dans common.json, dans le dossier ae2 du dossier config de votre\
répertoire .minecraft.

*   baseEnergyPerFuelTick définit le rendement de base, sans amélioration, de la chambre à vibration.
*   minEnergyPerGameTick définit la production d'énergie minimale possible (la chambre consommera toujours lentement un peu de carburant, même si le réseau
    n'a besoin d'aucune énergie).
*   maxEnergyPerGameTick définit la production maximale (et la vitesse) sans amélioration de la chambre à vibration.

## Recette

<RecipeFor id="vibration_chamber" />
