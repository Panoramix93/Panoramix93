---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Disques de stockage
  icon: item_storage_cell_1k
  position: 410
categories:
- tools
item_ids:
- ae2:item_cell_housing
- ae2:fluid_cell_housing
- ae2:cell_component_1k
- ae2:cell_component_4k
- ae2:cell_component_16k
- ae2:cell_component_64k
- ae2:cell_component_256k
- ae2:item_storage_cell_1k
- ae2:item_storage_cell_4k
- ae2:item_storage_cell_16k
- ae2:item_storage_cell_64k
- ae2:item_storage_cell_256k
- ae2:fluid_storage_cell_1k
- ae2:fluid_storage_cell_4k
- ae2:fluid_storage_cell_16k
- ae2:fluid_storage_cell_64k
- ae2:fluid_storage_cell_256k
---

# Disques de stockage

<Column>
  <Row>
    <ItemImage id="item_storage_cell_1k" scale="4" />

    <ItemImage id="item_storage_cell_4k" scale="4" />

    <ItemImage id="item_storage_cell_16k" scale="4" />

    <ItemImage id="item_storage_cell_64k" scale="4" />

    <ItemImage id="item_storage_cell_256k" scale="4" />
  </Row>

  <Row>
    <ItemImage id="fluid_storage_cell_1k" scale="4" />

    <ItemImage id="fluid_storage_cell_4k" scale="4" />

    <ItemImage id="fluid_storage_cell_16k" scale="4" />

    <ItemImage id="fluid_storage_cell_64k" scale="4" />

    <ItemImage id="fluid_storage_cell_256k" scale="4" />
  </Row>
</Column>

Les disques de stockage sont l'un des principaux moyens de stockage d'Applied Energistics. Ils se placent dans les <ItemLink id="drive" />
ou les <ItemLink id="chest" />.

Voir [Octets et types](../ae2-mechanics/bytes-and-types.md) pour une explication de leurs capacités en octets et en types.

Les composants de stockage peuvent être retirés du boîtier lorsque le disque est vide, par un maj + clic droit avec le disque en main.

<Row>
    <Recipe id="upgrade/item_storage_cell_1k_to_4k" />

    Vous pouvez améliorer les disques de stockage vers des paliers supérieurs en les combinant avec des composants de stockage de palier supérieur dans une grille de fabrication. Leur contenu est conservé et le composant de palier inférieur vous est rendu.
</Row>

## Capacité de stockage selon le nombre de types

Le [coût fixe des types](../ae2-mechanics/bytes-and-types.md) est tel qu'un disque ne contenant qu'un seul type peut stocker 2 fois plus qu'un disque dont les 63 types sont utilisés.

| Disque                                   | Capacité totale du disque avec 1 type utilisé | Capacité totale du disque avec 63 types utilisés |
| ---------------------------------------- | ----------------------------------------: | ------------------------------------------: |
| <ItemLink id="item_storage_cell_1k" />   |                                     8 128 |                                       4 160 |
| <ItemLink id="item_storage_cell_4k" />   |                                    32 512 |                                      16 640 |
| <ItemLink id="item_storage_cell_16k" />  |                                   130 048 |                                      66 560 |
| <ItemLink id="item_storage_cell_64k" />  |                                   520 192 |                                     266 240 |
| <ItemLink id="item_storage_cell_256k" /> |                                 2 080 768 |                                   1 064 960 |


## Partitionnement

Les disques peuvent être filtrés pour n'accepter que certains objets, de la même façon que les <ItemLink id="storage_bus" /> peuvent être filtrés. Cela se
fait dans un <ItemLink id="cell_workbench" />.

Les objets peuvent être glissés dans les emplacements depuis JEI/REI, même si vous ne possédez aucun exemplaire de l'objet en question.

## Améliorations

Les disques de stockage acceptent les [améliorations](upgrade_cards.md) suivantes, insérées via un <ItemLink id="cell_workbench" /> :

*   <ItemLink id="fuzzy_card" /> (non disponible sur les disques de fluide) permet de partitionner le disque par niveau de dégât et/ou d'ignorer les NBT des objets
*   <ItemLink id="inverter_card" /> transforme le filtre d'une liste blanche en liste noire
*   <ItemLink id="equal_distribution_card" /> attribue la même quantité d'octets du disque à chaque type, de sorte qu'un seul type ne puisse pas remplir tout le disque
*   <ItemLink id="void_card" /> détruit les objets insérés lorsque le disque est plein (ou lorsque l'espace alloué à ce type précis est plein dans le
    cas d'une carte de distribution égale) : utile pour éviter que des fermes ne se bloquent. Pensez bien à partitionner le disque !
*   Les disques portables acceptent une <ItemLink id="energy_card" /> afin d'augmenter la capacité de leur batterie

## Coloration

Les disques portables d'objets et de fluides peuvent être colorés comme une armure de cuir, en les fabriquant avec des teintures.

# Boîtiers

Les disques peuvent être fabriqués avec un composant de stockage et un boîtier, ou avec la recette du boîtier autour d'un composant de stockage :

<Row>
  <Recipe id="network/cells/item_storage_cell_1k" />

  <Recipe id="network/cells/item_storage_cell_1k_storage" />
</Row>

Les boîtiers seuls se fabriquent ainsi :

<Row>
  <RecipeFor id="item_cell_housing" />

  <RecipeFor id="fluid_cell_housing" />
</Row>

# Composants de stockage

Les composants de stockage sont le cœur de tous les disques d'AE2 : ils déterminent la capacité des disques. Chaque palier multiplie la capacité
par 4 et coûte 3 composants du palier précédent.

<Column>
  <Row>
    <RecipeFor id="cell_component_1k" />

    <RecipeFor id="cell_component_4k" />

    <RecipeFor id="cell_component_16k" />
  </Row>

  <Row>
    <RecipeFor id="cell_component_64k" />

    <RecipeFor id="cell_component_256k" />
  </Row>
</Column>

# Disques de stockage d'objets

Les disques de stockage d'objets peuvent contenir jusqu'à 63 types d'objets distincts et existent dans toutes les capacités standard.

<Column>
  <Row>
    <Recipe id="network/cells/item_storage_cell_1k_storage" />

    <Recipe id="network/cells/item_storage_cell_4k_storage" />

    <Recipe id="network/cells/item_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/item_storage_cell_64k_storage" />

    <Recipe id="network/cells/item_storage_cell_256k_storage" />
  </Row>
</Column>

## Stockage d'objets portable

Ils font office de minuscule <ItemLink id="chest" /> de poche, ou d'une sorte de sac à dos. Ils peuvent être rechargés dans un <ItemLink id="charger" />

Contrairement aux disques de stockage classiques, leur capacité en types *diminue* à mesure que leur capacité en octets augmente, et ils n'ont que la moitié
de la capacité totale en octets.

En plus des cartes d'amélioration acceptées par tous les disques, ils acceptent aussi des <ItemLink id="energy_card" /> pour améliorer leur batterie interne.

<Column>
  <Row>
    <RecipeFor id="portable_item_cell_1k" />

    <RecipeFor id="portable_item_cell_4k" />

    <RecipeFor id="portable_item_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_item_cell_64k" />

    <RecipeFor id="portable_item_cell_256k" />
  </Row>
</Column>

# Disques de stockage de fluide

Les disques de stockage de fluide peuvent contenir jusqu'à 5 types de fluides distincts et existent dans toutes les capacités standard.

<Column>
  <Row>
    <Recipe id="network/cells/fluid_storage_cell_1k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_4k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/fluid_storage_cell_64k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_256k_storage" />
  </Row>
</Column>

## Stockage de fluide portable

Ils font office de minuscule <ItemLink id="chest" /> de poche, ou d'une sorte de sac à dos. Ils peuvent être rechargés dans un <ItemLink id="charger" />

Contrairement aux disques de stockage classiques, leur capacité en types *diminue* à mesure que leur capacité en octets augmente, et ils n'ont que la moitié
de la capacité totale en octets.

En plus des cartes d'amélioration acceptées par tous les disques, ils acceptent aussi des <ItemLink id="energy_card" /> pour améliorer leur batterie interne.

<Column>
  <Row>
    <RecipeFor id="portable_fluid_cell_1k" />

    <RecipeFor id="portable_fluid_cell_4k" />

    <RecipeFor id="portable_fluid_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_fluid_cell_64k" />

    <RecipeFor id="portable_fluid_cell_256k" />
  </Row>
</Column>

# Disque de stockage créatif

<Row>
  <ItemImage id="creative_storage_cell" scale="2" />
</Row>

Les disques créatifs **ne fournissent pas un stockage infini**. Ils agissent plutôt comme une source et un puits infinis de l'objet
ou du fluide auquel vous les [partitionnez](cell_workbench.md).
