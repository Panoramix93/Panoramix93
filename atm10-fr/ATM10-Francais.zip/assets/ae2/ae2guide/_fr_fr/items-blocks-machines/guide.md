---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Guide
  icon: guide
categories:
- tools
item_ids:
- ae2:guide
---

# Le Guide

<ItemImage id="guide" scale="8" />

### Le guide que vous êtes en train de lire, pour tous vos besoins d'accompagnement sur AE2.

* Utilisez la barre latérale de gauche pour accéder à la table des matières
* De nombreuses pages contiennent des scènes interactives. Si une scène comporte des boutons ![Plus](../assets/diagrams/plus.png)
  et ![Minus](../assets/diagrams/minus.png) (zoom) à côté d'elle, vous pouvez faire pivoter et déplacer la caméra.
  Clic gauche maintenu pour faire pivoter, clic droit maintenu pour déplacer.

## Recette

<RecipeFor id="guide" />
