---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Émetteur de niveau
  icon: level_emitter
  position: 220
categories:
- devices
item_ids:
- ae2:level_emitter
- ae2:energy_level_emitter
---

# L'Émetteur de niveau

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/level_emitter.snbt" />
</GameScene>

L'Émetteur de niveau émet un signal de redstone en fonction de la quantité d'un objet présent dans le
[stockage du réseau](../ae2-mechanics/import-export-storage.md).

Il existe également une version qui émet un signal de redstone en fonction de l'[énergie](../ae2-mechanics/energy.md) stockée
dans votre réseau.

Les objets et les fluides peuvent être glissés dans l'emplacement depuis JEI/REI même si vous ne possédez pas réellement l'objet en question.

Faites un clic droit avec un conteneur de fluide (comme un seau ou une cuve) pour définir ce fluide comme filtre, au lieu du seau ou de la cuve elle-même.

Il s'agit d'[éléments de câble](../ae2-mechanics/cable-subparts.md).

Contrairement aux autres [appareils](../ae2-mechanics/devices.md), les émetteurs de niveau *ne nécessitent pas* de [canal](../ae2-mechanics/channels.md).

## Réglages

*   L'Émetteur de niveau peut être réglé en mode « supérieur ou égal à » ou « inférieur à »
*   Lorsqu'une <ItemLink id="crafting_card" /> est insérée, il peut être réglé sur « émettre un signal de redstone pendant la fabrication de l'objet » ou
    « émettre un signal de redstone pour fabriquer l'objet »

## Améliorations

L'émetteur de niveau prend en charge les [améliorations](upgrade_cards.md) suivantes :

*   <ItemLink id="fuzzy_card" /> permet à l'émetteur de filtrer selon le niveau de dégâts et/ou d'ignorer les NBT de l'objet
*   <ItemLink id="crafting_card" /> active la fonction de fabrication

## Fonction de fabrication

Si une <ItemLink id="crafting_card" /> est insérée, l'émetteur passe en mode fabrication.

Cela active deux options :

La première option, « émettre un signal de redstone pendant la fabrication de l'objet », fait émettre à l'émetteur un signal de redstone pendant que votre [fabrication automatique](../ae2-mechanics/autocrafting.md)
fabrique un objet précis via des <ItemLink id="pattern_provider" />. C'est utile pour n'allumer certaines installations
d'automatisation très gourmandes en énergie que lorsqu'elles servent réellement.

La seconde option, « émettre un signal de redstone pour fabriquer l'objet », est extrêmement utile dans des cas précis comme les fermes infinies et les
installations d'automatisation qui n'ont qu'une chance de produire un résultat, au lieu d'un résultat garanti.
Ce réglage crée un [modèle](patterns.md) virtuel utilisable par la [fabrication automatique](../ae2-mechanics/autocrafting.md), pour l'objet
placé dans l'emplacement de filtre de l'émetteur.
(Pour un fonctionnement correct, un véritable modèle pour le même objet **ne doit pas exister** dans vos <ItemLink id="pattern_provider" />)

Ce « modèle » ne définit pas les ingrédients et ne s'en soucie même pas.
Il dit simplement « si vous émettez un signal de redstone depuis cet émetteur de niveau, le système ME recevra cet objet à un moment donné dans un
avenir proche ou lointain ». On s'en sert généralement pour activer et désactiver des fermes infinies qui ne nécessitent aucun ingrédient d'entrée,
ou pour activer [un système qui gère les recettes récursives](../example-setups/recursive-crafting-setup.md) (que la fabrication automatique standard ne sait pas interpréter)
comme, par exemple, « 1 pierre = 2 pierres » si vous disposez d'une machine qui duplique la pierre.

## Recette

<RecipeFor id="level_emitter" />

<RecipeFor id="energy_level_emitter" />
