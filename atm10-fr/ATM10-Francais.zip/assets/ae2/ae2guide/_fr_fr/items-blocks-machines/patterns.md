---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Modèles
  icon: crafting_pattern
  position: 410
categories:
- tools
item_ids:
- ae2:blank_pattern
- ae2:crafting_pattern
- ae2:processing_pattern
- ae2:smithing_table_pattern
- ae2:stonecutting_pattern
---

# Modèles

<ItemImage id="crafting_pattern" scale="4" />

Les modèles se fabriquent dans un <ItemLink id="pattern_encoding_terminal" /> à partir de modèles vierges, puis s'insèrent dans des <ItemLink id="pattern_provider" />
ou des <ItemLink id="molecular_assembler" />.

Il existe plusieurs types de modèles pour différents usages :

*   Les <ItemLink id="crafting_pattern" /> encodent des recettes réalisées dans une table de craft. Ils peuvent être placés directement dans un <ItemLink id="molecular_assembler" /> pour qu'il
    fabrique le résultat dès qu'il reçoit les ingrédients, mais leur usage principal se trouve dans un <ItemLink id="pattern_provider" /> adjacent à un assembleur moléculaire.
    Dans ce cas, les fournisseurs de modèles ont un comportement particulier : ils envoient le modèle concerné en même temps que les ingrédients aux assembleurs adjacents.
    Comme les assembleurs éjectent automatiquement les résultats des fabrications dans les inventaires adjacents, un assembleur posé sur un fournisseur de modèles suffit à automatiser les modèles de fabrication.

***

*   Les <ItemLink id="smithing_table_pattern" /> ressemblent beaucoup aux modèles de fabrication, mais ils encodent des recettes de table de forge. Ils sont également automatisés par un fournisseur
    de modèles et un assembleur moléculaire, et fonctionnent exactement de la même manière. De fait, les modèles de fabrication, de forge et de taille de pierre peuvent
    être utilisés dans la même installation.

***

*   Les <ItemLink id="stonecutting_pattern" /> ressemblent beaucoup aux modèles de fabrication, mais ils encodent des recettes de tailleur de pierre. Ils sont également automatisés par un fournisseur
    de modèles et un assembleur moléculaire, et fonctionnent exactement de la même manière. De fait, les modèles de fabrication, de forge et de taille de pierre peuvent
    être utilisés dans la même installation.

***

*   Les <ItemLink id="processing_pattern" /> sont à l'origine d'une grande partie de la souplesse de la fabrication automatique. C'est le type le plus général : ils disent simplement
    « si un fournisseur de modèles pousse ces ingrédients dans les inventaires adjacents, le système ME recevra ces objets à un moment ou un autre, dans un futur
    proche ou lointain ». C'est ainsi que vous automatiserez la fabrication avec presque n'importe quelle machine moddée, ou avec des fours et autres. Comme ils sont
    très généraux et qu'ils ne se soucient pas de ce qui se passe entre la poussée des ingrédients et la réception du résultat, vous pouvez faire des choses vraiment farfelues, comme injecter
    les ingrédients dans toute une chaîne de production complexe qui va trier des éléments, prendre d'autres ingrédients dans des fermes
    à production infinie et imprimer l'intégralité du script du film Bee Movie : le système ME s'en moque, du moment qu'il obtient le résultat indiqué par le modèle. En fait,
    il ne se soucie même pas de savoir si les ingrédients ont un lien quelconque avec le résultat. Vous pourriez lui dire « 1 planche de cerisier = 1 étoile du Nether », faire tuer
    un Wither par votre ferme à Withers dès la réception d'une planche de cerisier, et cela fonctionnerait.

Plusieurs <ItemLink id="pattern_provider" /> contenant des modèles identiques sont pris en charge et fonctionnent en parallèle. De plus, un modèle peut indiquer,
par exemple, 8 cobblestones = 8 pierres au lieu de 1 cobblestone = 1 pierre, et le fournisseur de modèles insérera alors 8 cobblestones dans
votre installation de fusion à chaque opération au lieu d'une seule à la fois.

## Recette

<RecipeFor id="blank_pattern" />
