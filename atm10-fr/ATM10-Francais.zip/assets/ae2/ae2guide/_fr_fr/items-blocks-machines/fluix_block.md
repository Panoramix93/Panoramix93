---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bloc de Fluix
  icon: fluix_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_block
---

# Le Bloc de Fluix

<BlockImage id="fluix_block" scale="8" />

Le bloc de stockage pour le <ItemLink id="fluix_crystal" />. Il sert également dans les recettes de quelques machines.

## Recette

<RecipeFor id="fluix_block" />
