---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Certus Quartz bourgeonnant
  icon: flawless_budding_quartz
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:flawless_budding_quartz
- ae2:flawed_budding_quartz
- ae2:chipped_budding_quartz
- ae2:damaged_budding_quartz
- ae2:small_quartz_bud
- ae2:medium_quartz_bud
- ae2:large_quartz_bud
- ae2:quartz_cluster
---

# Certus Quartz bourgeonnant

(voir aussi [Croissance du Certus](../ae2-mechanics/certus-growth.md))

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Des bourgeons de Certus Quartz poussent sur les blocs de Certus bourgeonnant, comme pour l'améthyste. On les trouve dans les [météorites](../ae2-mechanics/meteorites.md).
Il existe 4 niveaux de blocs de Certus bourgeonnant : parfait, imparfait, ébréché et abîmé. Le plus simple pour les identifier
est d'utiliser un mod comme HWYLA, Jade, The One Probe, etc. (ou l'écran F3)

Avec le Certus bourgeonnant imparfait, ébréché et abîmé, chaque fois qu'un bourgeon passe à un stade supérieur, le bloc bourgeonnant a une chance
de se dégrader d'un niveau, jusqu'à devenir un simple <ItemLink id="quartz_block" />.

Le Certus bourgeonnant parfait ne se dégrade pas en faisant pousser des bourgeons et constitue donc une source infinie.

S'ils sont cassés avec une pioche normale, les blocs de Certus bourgeonnant se dégradent d'1 niveau. S'ils sont cassés avec une pioche
enchantée avec Toucher de soie, ils ne se dégradent pas, sauf s'ils étaient parfaits. **Cela signifie que les blocs de Certus bourgeonnant parfait ne peuvent pas
être ramassés et déplacés à la pioche**. À la place, le [stockage spatial](../ae2-mechanics/spatial-io.md) permet de
couper-coller les blocs bourgeonnants parfaits d'un endroit à un autre.

## Recettes

Le Certus bourgeonnant imparfait, ébréché et abîmé se fabrique en jetant le niveau précédent de bloc bourgeonnant (ou un <ItemLink id="quartz_block" />)
dans l'eau avec un ou plusieurs <ItemLink id="charged_certus_quartz_crystal" />.

Le Certus bourgeonnant parfait ne peut pas être fabriqué, il se trouve uniquement dans le monde.

<Row>
  <RecipeFor id="damaged_budding_quartz" />

  <RecipeFor id="chipped_budding_quartz" />

  <RecipeFor id="flawed_budding_quartz" />
</Row>
