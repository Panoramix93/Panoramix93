---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Contrôleur
  icon: controller
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:controller
---

# Le contrôleur

<BlockImage id="controller" p:state="online" scale="8" />

Le contrôleur est le cœur de routage d'un [réseau ME](../ae2-mechanics/me-network-connections.md).
Sans lui, un réseau est « ad hoc » et ne peut compter que 8 [appareils](../ae2-mechanics/devices.md) consommant un canal au total.

Il est impossible d'avoir 2 contrôleurs dans un même [réseau ME](../ae2-mechanics/me-network-connections.md).

Le contrôleur fournit 32 [canaux](../ae2-mechanics/channels.md) par face.

Le contrôleur a besoin de 6 AE/t par bloc de contrôleur pour
fonctionner. Chaque bloc de contrôleur peut stocker 8000 AE, les réseaux plus importants peuvent donc nécessiter un
stockage d'énergie supplémentaire. Voir [énergie](../ae2-mechanics/energy.md) pour les détails.

Les contrôleurs multiblocs peuvent être construits de façon assez libre.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controllers.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Quelques règles doivent toutefois être respectées :

1.  Tous les blocs de contrôleur d'un [réseau ME](../ae2-mechanics/me-network-connections.md) doivent être connectés, sinon les blocs deviennent rouges.
2.  La taille du contrôleur doit tenir dans 7x7x7, sinon il devient rouge.
3.  Un contrôleur ne peut avoir 2 blocs adjacents que sur 1 axe au maximum ; si un bloc enfreint cette règle, il se désactive et devient rouge.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controller_rules.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Tant que toutes les règles sont respectées et qu'il est alimenté, le contrôleur doit briller et
changer de couleur en boucle.

Vous pouvez faire un clic droit sur un contrôleur pour obtenir la même interface qu'avec un <ItemLink id="network_tool" />

## Recette

<RecipeFor id="controller" />
