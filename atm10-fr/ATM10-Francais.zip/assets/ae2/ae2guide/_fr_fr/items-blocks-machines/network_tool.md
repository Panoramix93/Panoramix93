---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Outil réseau
  icon: network_tool
  position: 410
categories:
- tools
item_ids:
- ae2:network_tool
---

# Outil réseau

<ItemImage id="network_tool" scale="4" />

L'outil réseau est une [clé](wrench.md) modifiée qui affiche en plus des informations de diagnostic sur le réseau et qui peut stocker des [cartes d'amélioration](upgrade_cards.md).
S'il conserve la capacité de la clé à démonter rapidement les choses et à retirer les [sous-parties](../ae2-mechanics/cable-subparts.md)
d'un câble, il ne peut pas faire tourner les blocs.

Il dispose de 9 cases pour stocker des [cartes d'amélioration](upgrade_cards.md), et celles-ci seront disponibles dans l'interface de n'importe quel appareil AE2 si l'outil
se trouve quelque part dans votre inventaire.

Un clic droit sur n'importe quelle partie d'un réseau affiche une fenêtre d'informations de diagnostic, similaire à celle obtenue par un clic droit sur un <ItemLink id="controller" />.
Cette fenêtre indique

*   le nombre de canaux utilisés sur le réseau
*   un interrupteur pour le réglage global d'affichage de l'énergie en AE ou en E/FE
*   la quantité d'[énergie](../ae2-mechanics/energy.md) stockée dans le réseau, et la capacité énergétique maximale du réseau
*   la quantité d'énergie qui entre dans le réseau et celle qu'il consomme
*   la liste de tous les [appareils](../ae2-mechanics/devices.md) et composants du réseau

Cette fenêtre est également pratique pour déterminer si deux câbles ou appareils différents font partie du même réseau lorsque vous bricolez avec les
[sous-réseaux](../ae2-mechanics/subnetworks.md).

## Masquer les façades

<a href="facades.md">Les façades</a> sont masquées tant que vous tenez un outil réseau dans l'une ou l'autre main.

Vous pouvez interagir avec les blocs situés derrière les façades masquées sans avoir à retirer ces dernières au préalable.

## Recette

<RecipeFor id="network_tool" />
