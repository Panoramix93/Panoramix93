---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Outils en quartz
  icon: certus_quartz_pickaxe
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_axe
- ae2:certus_quartz_hoe
- ae2:certus_quartz_shovel
- ae2:certus_quartz_pickaxe
- ae2:certus_quartz_sword
- ae2:nether_quartz_axe
- ae2:nether_quartz_hoe
- ae2:nether_quartz_shovel
- ae2:nether_quartz_pickaxe
- ae2:nether_quartz_sword
---

# Outils en quartz

<Row>
  <ItemImage id="certus_quartz_axe" scale="4" />

  <ItemImage id="certus_quartz_hoe" scale="4" />

  <ItemImage id="certus_quartz_shovel" scale="4" />

  <ItemImage id="certus_quartz_pickaxe" scale="4" />

  <ItemImage id="certus_quartz_sword" scale="4" />
</Row>

<Row>
  <ItemImage id="nether_quartz_axe" scale="4" />

  <ItemImage id="nether_quartz_hoe" scale="4" />

  <ItemImage id="nether_quartz_shovel" scale="4" />

  <ItemImage id="nether_quartz_pickaxe" scale="4" />

  <ItemImage id="nether_quartz_sword" scale="4" />
</Row>

Les outils en quartz sont fonctionnellement identiques aux outils en fer : mêmes dégâts, même durabilité, même vitesse de minage, etc.
Il existe des variantes en quartz du Nether et en [quartz certus](fluix_crystal.md).

## Recettes

<Column>
  <Row>
    <RecipeFor id="certus_quartz_axe" />

    <RecipeFor id="certus_quartz_hoe" />

    <RecipeFor id="certus_quartz_shovel" />
  </Row>

  <Row>
    <RecipeFor id="certus_quartz_pickaxe" />

    <RecipeFor id="certus_quartz_sword" />
  </Row>

  <Row>
    <RecipeFor id="nether_quartz_axe" />

    <RecipeFor id="nether_quartz_hoe" />

    <RecipeFor id="nether_quartz_shovel" />
  </Row>

  <Row>
    <RecipeFor id="nether_quartz_pickaxe" />

    <RecipeFor id="nether_quartz_sword" />
  </Row>
</Column>
