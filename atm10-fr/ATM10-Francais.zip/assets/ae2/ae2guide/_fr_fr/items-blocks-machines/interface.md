---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Interface
  icon: interface
  position: 210
categories:
- devices
item_ids:
- ae2:interface
- ae2:cable_interface
---

# L'Interface

<Row gap="20">
<BlockImage id="interface" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_interface.snbt" />
</GameScene>
</Row>

Les interfaces se comportent comme un petit coffre et une petite cuve à fluides qui se remplissent depuis le [stockage du réseau](../ae2-mechanics/import-export-storage.md) et s'y vident,
selon ce que vous leur demandez de garder en stock dans leurs emplacements. Elles essaient de le faire en un seul tick de jeu, et peuvent donc se remplir
ou se vider de 9 piles par tick, ce qui en fait une méthode d'importation ou d'exportation rapide si vous avez des tuyaux à objets rapides.

Autre atout : alors que la plupart des cuves ne peuvent stocker qu'un seul type de fluide, les interfaces peuvent en stocker jusqu'à 9, en plus des objets.
Ce sont au fond de simples coffres / cuves multifluides dotés de fonctionnalités supplémentaires, et vous pouvez désactiver ces fonctionnalités en les
laissant déconnectées de tout réseau.
Elles sont donc utiles dans certains cas de niche où vous voulez stocker une petite quantité de plein de choses différentes.

## Fonctionnement interne d'une interface

Comme indiqué plus haut, une interface est essentiellement un coffre / une cuve auquel sont attachés des <ItemLink id="import_bus" /> et des
<ItemLink id="export_bus" /> surpuissants, avec tout un tas d'<ItemLink id="level_emitter" />.

<GameScene zoom="3" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_internals.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 0.3 1.3" max="9.7 1 1.7">
        Tout un tas d'émetteurs de niveau pour contrôler la quantité à maintenir en stock
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 4 1.3" max="9.7 4.7 1.7">
        Tout un tas d'émetteurs de niveau pour contrôler la quantité à maintenir en stock
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 1.3 1.3" max="9.7 2 1.7">
        Tout un tas de bus d'importation surpuissants capables de transférer 1 pile par tick de jeu
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/import_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 3 1.3" max="9.7 3.7 1.7">
        Tout un tas de bus d'exportation surpuissants capables de transférer 1 pile par tick de jeu
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/export_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="10 3 2">
        9 emplacements internes distincts
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="15" />
</GameScene>

## Interactions particulières

Les interfaces ont aussi quelques fonctionnalités particulières avec d'autres [appareils](../ae2-mechanics/devices.md) d'AE2 :

Un <ItemLink id="storage_bus" /> posé sur une interface non configurée présente l'intégralité du [stockage du réseau](../ae2-mechanics/import-export-storage.md)
de son réseau au réseau du bus de stockage, comme si le réseau de l'interface était un unique grand coffre sur lequel le bus de stockage était posé.
Définir un objet à maintenir en stock dans les emplacements de filtre de l'interface désactive ce comportement.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Les fournisseurs de pattern ont une interaction particulière avec les interfaces sur un [sous-réseau](../ae2-mechanics/subnetworks.md) : si l'interface n'est pas configurée,
le fournisseur l'ignore complètement et pousse directement vers le [stockage](../ae2-mechanics/import-export-storage.md) de ce sous-réseau,
sans passer par l'interface ni la remplir de lots de recette, et surtout sans insérer le lot suivant tant qu'il n'y a pas de place dans le stockage.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Interface (doit être plate, pas en bloc plein)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Bus de stockage ME
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        Les endroits où vous voulez fournir des patterns (plusieurs machines, ou plusieurs faces d'une même machine)
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## Variantes

Les interfaces existent en 2 variantes : normale et plate / [sous-élément](../ae2-mechanics/cable-subparts.md). Cela détermine depuis quelles faces précises leurs inventaires sont accessibles
et à quelles faces elles fournissent une connexion réseau.

*   Les interfaces normales permettent de pousser vers leur inventaire, d'en extraire et d'y accéder depuis toutes les faces et, comme la plupart des machines AE2, se comportent
    comme un câble fournissant une connexion réseau sur toutes les faces.

*   Les interfaces plates sont des [sous-éléments de câble](../ae2-mechanics/cable-subparts.md), ce qui permet d'en placer plusieurs sur le même câble et d'obtenir des montages compacts.
    Elles permettent de pousser vers leur inventaire, d'en extraire et d'y accéder depuis leur face, mais ne fournissent pas de connexion réseau sur leur face.

On peut passer d'une interface normale à une interface plate dans une grille de fabrication.

## Réglages

Les emplacements supérieurs de l'interface déterminent ce que l'interface doit garder en stock. Lorsque vous y placez quelque chose
ou que vous le glissez depuis JEI/REI, une clé apparaît et vous permet de régler la quantité.

Faites un clic droit avec un conteneur de fluide (un seau ou une cuve, par exemple) pour définir ce fluide comme filtre au lieu de l'objet seau ou cuve.

Lorsque vous mettez un emplacement en mode stockage, cela empêche aussi les machines externes d'y insérer autre chose.

## Améliorations

L'interface accepte les [améliorations](upgrade_cards.md) suivantes :

*   <ItemLink id="fuzzy_card" /> permet au bus de filtrer selon le niveau de dégâts et/ou d'ignorer les NBT de l'objet
*   <ItemLink id="crafting_card" /> permet à l'interface d'envoyer des demandes de fabrication à votre système d'[autofabrication](../ae2-mechanics/autocrafting.md)
    pour obtenir les objets qu'elle souhaite. Elle extraira les objets du stockage si possible avant de demander
    la fabrication d'un nouvel objet.

## Priorité

Les priorités se règlent en cliquant sur la clé en haut à droite de l'interface graphique. Les interfaces ayant une priorité plus élevée reçoivent leurs objets
avant celles de priorité plus faible,

## Recettes

<Recipe id="network/blocks/interfaces_interface" />

<RecipeFor id="cable_interface" />
