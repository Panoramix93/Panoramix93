---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ancrage de câble
  icon: cable_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:cable_anchor
---

# L'ancrage de câble

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/cable_anchor.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

De petites pointes décoratives fixées sur les câbles, qui servent à empêcher les câbles de se connecter, à créer des échelles avec des câbles, ou à donner l'impression que le câble
est relié aux murs qui l'entourent. Elles servent aussi à fabriquer des <ItemLink id="facade" />.

Les ancrages de câble empêchent toute connexion de se former sur le côté où ils sont fixés.

Vous pouvez les escalader comme une échelle.

## Recette

<RecipeFor id="cable_anchor" />
