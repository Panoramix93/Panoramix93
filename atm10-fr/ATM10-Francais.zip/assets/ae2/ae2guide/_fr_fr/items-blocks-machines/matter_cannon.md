---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Canon à matière
  icon: matter_cannon
  position: 410
categories:
- tools
item_ids:
- ae2:matter_cannon
---

# Le canon à matière

<ItemImage id="matter_cannon" scale="4" />

Le canon à matière est un canon électromagnétique portatif capable de tirer de petits objets en guise de projectiles, comme les <ItemLink id="matter_ball" /> et les pépites de métal. Les dégâts
dépendent de l'objet tiré : les objets « lourds » comme les pépites d'or (10 points de dégâts) font plus mal que les objets légers comme les boules de matière (2 points de dégâts).
Il consomme une énergie de base de 1600 AE par tir.

Lorsque l'option de configuration « matterCannonBlockDamage » est activée, le canon casse les blocs en fonction de leur dureté et
des dégâts de la munition.

Son énergie peut être rechargée dans un <ItemLink id="charger" />.

Les canons à matière se comportent comme des [disques de stockage](storage_cells.md), et le plus simple pour remplir leur chargeur est de placer
le canon dans l'emplacement à disque de stockage d'un <ItemLink id="chest" />

## Améliorations

Les canons à matière prennent en charge les [améliorations](upgrade_cards.md) suivantes, insérées via un <ItemLink id="cell_workbench" /> :

*   <ItemLink id="fuzzy_card" /> permet de partitionner le disque selon le niveau d'usure et/ou d'ignorer le NBT des objets
*   <ItemLink id="inverter_card" /> transforme le filtre de liste blanche en liste noire
*   <ItemLink id="speed_card" /> augmente l'énergie consommée à chaque tir, ce qui donne des tirs plus puissants.
*   <ItemLink id="void_card" /> détruit les objets insérés si le disque est plein. Pensez bien à la partitionner !
*   <ItemLink id="energy_card" /> pour augmenter la capacité de la batterie

## Recette

<RecipeFor id="matter_cannon" />
