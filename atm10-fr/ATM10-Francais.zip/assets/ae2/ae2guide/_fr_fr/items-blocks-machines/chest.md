---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Coffre ME
  icon: chest
  position: 210
categories:
- devices
item_ids:
- ae2:chest
---

# Le Coffre ME

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/chest.snbt" />
</GameScene>

Le Coffre ME se comporte comme un réseau miniature doté d'un <ItemLink id="terminal" />, d'un <ItemLink id="drive" /> et d'un <ItemLink id="energy_acceptor" />.
S'il peut servir de petit réseau de stockage, sa capacité limitée à un seul [disque de stockage](../items-blocks-machines/storage_cells.md)
en fait un usage peu pratique.

Il est en revanche utile pour interagir spécifiquement avec le disque de stockage qui y est monté. Son terminal intégré ne peut voir et atteindre
que les objets du disque monté, tandis que les [dispositifs](../ae2-mechanics/devices.md) du réseau général peuvent accéder aux objets de n'importe quel [stockage réseau](../ae2-mechanics/import-export-storage.md),
y compris les coffres ME.

Il possède 2 interfaces différentes et est orienté pour le transport d'objets. Interagir avec le terminal du dessus ouvre le terminal intégré. Des objets peuvent être insérés dans
le disque de stockage monté par cette face, mais pas extraits. Interagir avec n'importe quelle autre face ouvre l'interface comportant l'emplacement du disque de stockage
et les réglages de priorité. Le disque ne peut être inséré et retiré par la logistique d'objets que par la face comportant l'emplacement du disque.

Il peut être tourné avec une <ItemLink id="certus_quartz_wrench" />.

Il possède une petite réserve d'énergie AE : s'il n'est pas sur un réseau équipé d'une [cellule d'énergie](../items-blocks-machines/energy_cells.md),
insérer ou extraire trop d'objets d'un coup peut provoquer une chute de tension.

Le terminal peut être coloré avec un <ItemLink id="color_applicator" />.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/chest_color.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Réglages

Le Coffre ME dispose exactement des mêmes réglages qu'un <ItemLink id="terminal" /> ou un <ItemLink id="crafting_terminal" />.
Il ne prend toutefois pas en charge les <ItemLink id="view_cell" />.

## LED d'état des disques

Les disques placés dans le coffre portent une LED qui indique leur état :

| Couleur | État                                                                                    |
| :------ | :-------------------------------------------------------------------------------------- |
| Vert    | Vide                                                                                    |
| Bleu    | Contient quelques objets                                                                |
| Orange  | [Types](../ae2-mechanics/bytes-and-types.md) saturés, aucun nouveau type possible       |
| Rouge   | [Octets](../ae2-mechanics/bytes-and-types.md) saturés, plus aucun objet ne peut entrer  |
| Noir    | Pas d'énergie ou range-disque sans [canal](../ae2-mechanics/channels.md)                |

## Priorité

Les priorités se règlent en cliquant sur la clé en haut à droite de l'interface de l'emplacement du disque.
Les objets qui entrent dans le réseau se dirigent d'abord vers le stockage de priorité la plus élevée.
Si deux stockages ou disques ont la même priorité et que l'un contient déjà l'objet, ce stockage sera préféré à tout
autre. Tout disque [partitionné](cell_workbench.md) sera considéré comme contenant déjà l'objet
lorsqu'il se trouve dans le même groupe de priorité que d'autres stockages. Les objets retirés du stockage sont
prélevés sur le stockage de priorité la plus faible. Ce système de priorité fait qu'au fil des insertions et des retraits
dans le stockage réseau, les stockages de priorité élevée se remplissent et ceux de priorité faible se vident.

## Recette

<RecipeFor id="chest" />
