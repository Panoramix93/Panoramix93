---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Poussière de Certus Quartz
  icon: certus_quartz_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_dust
---

# Poussière de Certus Quartz

<ItemImage id="certus_quartz_dust" scale="4" />

Un <ItemLink id="certus_quartz_crystal" /> qui a été broyé par un <ItemLink id="inscriber" />. Utilisé dans la production de
plusieurs matériaux et composants d'AE2.

## Recette

<RecipeFor id="certus_quartz_dust" />

