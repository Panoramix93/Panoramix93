---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Récepteur sans fil
  icon: wireless_receiver
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:wireless_receiver
---

# Récepteur sans fil

<ItemImage id="wireless_receiver" scale="4" />

Une <ItemLink id="fluix_pearl" /> dans une parabole réflectrice : un composant de la technologie ME sans fil à courte portée.

## Recette

<RecipeFor id="wireless_receiver" />
