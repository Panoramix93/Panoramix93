---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Manipulateur d'entropie
  icon: entropy_manipulator
  position: 410
categories:
- tools
item_ids:
- ae2:entropy_manipulator
---

# Le manipulateur d'entropie

<ItemImage id="entropy_manipulator" scale="4" />

Le manipulateur d'entropie vous permet de chauffer et de refroidir des choses, respectivement par un clic droit et un Shift + clic droit. Il ne fait pas grand-chose,
juste des opérations comme évaporer ou geler l'eau, solidifier la lave en obsidienne, transformer des bûches en charbon de bois et cuire de la pierre brute en pierre, directement dans le monde.

S'il n'a rien de particulier à faire sur un bloc, il se comporte comme un briquet.

Son énergie peut être rechargée dans un <ItemLink id="charger" />.

## Recette

<RecipeFor id="entropy_manipulator" />
