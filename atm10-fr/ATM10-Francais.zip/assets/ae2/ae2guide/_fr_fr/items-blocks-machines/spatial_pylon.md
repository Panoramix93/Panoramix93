---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Pylône spatial
  icon: spatial_pylon
  position: 210
categories:
- devices
item_ids:
- ae2:spatial_pylon
---

# Le pylône spatial

<BlockImage id="spatial_pylon" p:powered_on="true" scale="8" />

Le pylône spatial est utilisé par les [E/S spatiales](../ae2-mechanics/spatial-io.md) pour générer le champ spatial et définir le volume
à traiter.

Chaque ligne continue de pylônes utilise 1 [canal](../ae2-mechanics/channels.md)

Les lignes de pylônes doivent mesurer au moins 2 blocs de long pour fonctionner.

## Recette

<RecipeFor id="spatial_pylon" />
