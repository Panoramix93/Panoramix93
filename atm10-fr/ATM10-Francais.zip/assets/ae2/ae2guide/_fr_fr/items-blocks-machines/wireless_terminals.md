---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Terminaux sans fil
  icon: wireless_crafting_terminal
  position: 410
categories:
- tools
item_ids:
- ae2:wireless_terminal
- ae2:wireless_crafting_terminal
---

# Terminaux sans fil

<Row>
  <ItemImage id="wireless_terminal" scale="4" />

  <ItemImage id="wireless_crafting_terminal" scale="4" />
</Row>

Les terminaux sans fil sont les versions portables des [terminaux](terminals.md) filaires classiques. Ils ont exactement
les mêmes interfaces que leurs équivalents filaires, à ceci près qu'au lieu d'emplacements pour les
<ItemLink id="view_cell" />, ils disposent d'emplacements pour les [cartes d'amélioration](upgrade_cards.md)

Pour les associer à un réseau, insérez le terminal dans l'emplacement en haut à droite d'un
<ItemLink id="wireless_access_point" /> connecté à ce réseau. (L'emplacement sur lequel figure l'image d'un terminal
sans fil avec une flèche en dessous)

Ils doivent se trouver à portée d'un <ItemLink id="wireless_access_point" /> pour fonctionner.

Leur énergie peut être rechargée dans un <ItemLink id="charger" />.

# Terminal sans fil

<ItemImage id="wireless_terminal" scale="4" />

Votre terminal de base, désormais portable ! Consultez et manipulez le contenu du
[stockage de votre réseau](../ae2-mechanics/import-export-storage.md) et lancez des demandes à votre installation de
[fabrication automatique](../ae2-mechanics/autocrafting.md) depuis n'importe où, à portée d'un
<ItemLink id="wireless_access_point" />.

## L'interface

Voir les [terminaux](terminals.md)

## Améliorations

Le terminal sans fil accepte les [améliorations](upgrade_cards.md) suivantes :

*   <ItemLink id="energy_card" /> pour augmenter la capacité de la batterie

## Recette

<RecipeFor id="wireless_terminal" />

# Terminal de fabrication sans fil

<ItemImage id="wireless_crafting_terminal" scale="4" />

Le terminal de fabrication sans fil ressemble à un terminal sans fil classique, avec les mêmes réglages et les mêmes sections, mais il ajoute une grille de fabrication qui se réapprovisionne automatiquement
depuis le [stockage du réseau](../ae2-mechanics/import-export-storage.md). Attention lorsque vous faites Maj + clic sur le résultat !

## L'interface

Voir les [terminaux](terminals.md)

## Améliorations

Le terminal de fabrication sans fil accepte les [améliorations](upgrade_cards.md) suivantes :

*   <ItemLink id="energy_card" /> pour augmenter la capacité de la batterie

## Recette

<RecipeFor id="wireless_crafting_terminal" />
