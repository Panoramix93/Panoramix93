---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Accélérateur de croissance
  icon: growth_accelerator
  position: 310
categories:
- machines
item_ids:
- ae2:growth_accelerator
---

# L'accélérateur de croissance

<BlockImage id="growth_accelerator" p:powered="true" scale="8"/>

L'accélérateur de croissance accélère massivement [la croissance](../ae2-mechanics/certus-growth.md) du quartz certus ou de l'améthyste lorsqu'il est placé à côté du bloc bourgeonnant.

Curieusement, il peut *aussi* accélérer la croissance de diverses plantes.

Pour cela, il applique des « ticks aléatoires » aux blocs adjacents, en plus des ticks aléatoires qui se produisent naturellement.
En théorie, cela signifie qu'1 accélérateur fait pousser les choses environ 90 fois plus vite que la normale, et l'effet se cumule de façon additive.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/growth_accelerator.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

L'énergie peut être fournie par le dessus ou par le dessous, via les [câbles](cables.md) d'AE2 ou via les câbles d'alimentation d'autres mods. Il accepte
aussi bien l'énergie d'AE2 (AE) que la Forge Energy (FE).

Pour l'alimenter manuellement, placez une <ItemLink id="crank" /> sur le dessus ou le dessous et faites un clic droit dessus.

Le dessus et le dessous se repèrent grâce aux petits détails de flux roses qui s'y trouvent.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/accelerator_connections.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Recette

<RecipeFor id="growth_accelerator" />
