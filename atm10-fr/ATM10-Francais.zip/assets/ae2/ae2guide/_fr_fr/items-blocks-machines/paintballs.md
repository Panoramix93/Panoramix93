---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Billes de peinture
  icon: green_lumen_paint_ball
  position: 410
categories:
- tools
item_ids:
- ae2:white_paint_ball
- ae2:orange_paint_ball
- ae2:magenta_paint_ball
- ae2:light_blue_paint_ball
- ae2:yellow_paint_ball
- ae2:lime_paint_ball
- ae2:pink_paint_ball
- ae2:gray_paint_ball
- ae2:light_gray_paint_ball
- ae2:cyan_paint_ball
- ae2:purple_paint_ball
- ae2:blue_paint_ball
- ae2:brown_paint_ball
- ae2:green_paint_ball
- ae2:red_paint_ball
- ae2:black_paint_ball
- ae2:white_lumen_paint_ball
- ae2:orange_lumen_paint_ball
- ae2:magenta_lumen_paint_ball
- ae2:light_blue_lumen_paint_ball
- ae2:yellow_lumen_paint_ball
- ae2:lime_lumen_paint_ball
- ae2:pink_lumen_paint_ball
- ae2:gray_lumen_paint_ball
- ae2:light_gray_lumen_paint_ball
- ae2:cyan_lumen_paint_ball
- ae2:purple_lumen_paint_ball
- ae2:blue_lumen_paint_ball
- ae2:brown_lumen_paint_ball
- ae2:green_lumen_paint_ball
- ae2:red_lumen_paint_ball
- ae2:black_lumen_paint_ball
---

# Billes de peinture

<Row gap="-8">
  <ItemImage id="white_paint_ball" scale="4" />

  <ItemImage id="orange_paint_ball" scale="4" />

  <ItemImage id="green_paint_ball" scale="4" />

  <ItemImage id="blue_paint_ball" scale="4" />

  <ItemImage id="red_paint_ball" scale="4" />
</Row>

Les billes de peinture s'utilisent dans un <ItemLink id="color_applicator" /> afin de peindre les blocs colorables comme les [câbles](cables.md),
la laine, la terre cuite, le verre et le béton. Elles peuvent aussi servir dans un <ItemLink id="matter_cannon" /> pour tirer de petites taches de peinture.

## Recettes

8 boules de matière autour d'une teinture

<Column>
  <Row>
    <RecipeFor id="white_paint_ball" />

    <RecipeFor id="orange_paint_ball" />

    <RecipeFor id="green_paint_ball" />
  </Row>

  <Row>
    <RecipeFor id="blue_paint_ball" />

    <RecipeFor id="red_paint_ball" />

    <RecipeFor id="black_paint_ball" />
  </Row>

  <br />
</Column>

# Billes de peinture lumineuses

<Row gap="-8">
  <ItemImage id="white_lumen_paint_ball" scale="4" />

  <ItemImage id="orange_lumen_paint_ball" scale="4" />

  <ItemImage id="green_lumen_paint_ball" scale="4" />

  <ItemImage id="blue_lumen_paint_ball" scale="4" />

  <ItemImage id="red_lumen_paint_ball" scale="4" />
</Row>

Elles se comportent exactement comme les billes de peinture classiques, mais les taches émettent de la lumière lorsqu'elles sont tirées d'un <ItemLink id="matter_cannon" />.
Pratique comme pistolet de détresse, je suppose.

## Recettes

8 billes de peinture autour d'une poudre de pierre lumineuse

<Column>
  <Row>
    <RecipeFor id="white_lumen_paint_ball" />

    <RecipeFor id="orange_lumen_paint_ball" />

    <RecipeFor id="green_lumen_paint_ball" />
  </Row>

  <Row>
    <RecipeFor id="blue_lumen_paint_ball" />

    <RecipeFor id="red_lumen_paint_ball" />

    <RecipeFor id="black_lumen_paint_ball" />
  </Row>
</Column>
