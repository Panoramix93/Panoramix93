---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Poussière d'Ender
  icon: ender_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:ender_dust
---

# La poussière d'Ender

<ItemImage id="ender_dust" scale="4" />

Une perle de l'Ender qui a été broyée par une <ItemLink id="inscriber" />. Utilisée dans la production d'<ItemLink id="wireless_booster" />
et de paires de <ItemLink id="quantum_entangled_singularity" />.

## Recette

<RecipeFor id="ender_dust" />
