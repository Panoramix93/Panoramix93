---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ancre spatiale
  icon: spatial_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:spatial_anchor
---

# L'ancre spatiale

<BlockImage id="spatial_anchor" p:powered="true" scale="8"/>

Un réseau AE2 doit être maintenu chargé (chunkloaded) pour que ses [appareils](../ae2-mechanics/devices.md) puissent fonctionner, et s'il n'en est chargé qu'une partie,
il risque de ne pas fonctionner correctement. L'ancre spatiale résout ce problème. Elle force le chargement des chunks occupés par son réseau.
Un simple câble qui franchit une limite de chunk suffit à faire charger ce nouveau chunk.

Elle propage son « chargement » à travers les [ponts quantiques](quantum_bridge.md), mais pas entre dimensions : si vous
avez un pont quantique vers le Nether, il vous faut une ancre spatiale sur le réseau de votre base et une autre sur le réseau situé dans le Nether.

Par défaut, elle active aussi les tics aléatoires dans les chunks qu'elle charge ; cela peut être désactivé dans la configuration d'AE2.

Elle peut être tournée avec une <ItemLink id="certus_quartz_wrench" /> si pour une raison quelconque vous souhaitez le faire.

## Réglages

*   L'ancre spatiale donne accès au réglage global d'affichage de l'énergie en AE ou en E/FE.
*   Un hologramme peut être affiché dans le monde pour montrer les chunks chargés.

## Énergie

L'ancre spatiale consomme de l'[énergie](../ae2-mechanics/energy.md) selon cette équation :

e = 80 + (x\*(x+1))/2

où x est le nombre de chunks chargés

## Recette

<RecipeFor id="spatial_anchor" />
