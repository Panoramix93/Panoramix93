---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Carte mémoire
  icon: memory_card
  position: 410
categories:
- tools
item_ids:
- ae2:memory_card
---

# La carte mémoire

<ItemImage id="memory_card" scale="4" />

La carte mémoire sert à copier-coller des réglages entre les [appareils](../ae2-mechanics/devices.md) AE2 et à relier
les [tunnels P2P](p2p_tunnels.md). Elle peut aussi coller des [cartes d'amélioration](upgrade_cards.md) dans les appareils.

- Maj + clic droit pour copier les réglages ou générer une nouvelle fréquence de liaison P2P.
- Clic droit pour coller les réglages, les cartes d'amélioration ou la fréquence de liaison.

## Recette

<RecipeFor id="memory_card" />
