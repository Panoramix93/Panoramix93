---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cellules d'énergie
  icon: energy_cell
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_cell
- ae2:dense_energy_cell
- ae2:creative_energy_cell
---

# Cellules d'énergie

<Row gap="20">
  <BlockImage id="energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="8" />
</Row>

Les cellules d'énergie offrent à un réseau davantage de stockage d'[énergie](../ae2-mechanics/energy.md). Un certain tampon d'énergie aide à lisser
les pics de consommation lorsque de grandes quantités d'objets sont insérées ou extraites, et des capacités de stockage plus importantes
permettent au réseau de fonctionner quand l'énergie n'est pas produite (comme la nuit avec des panneaux solaires) ou d'absorber l'énorme appel
d'énergie instantané du [stockage spatial](../ae2-mechanics/spatial-io.md).

## Barres de remplissage

<Row>
<BlockImage id="energy_cell" scale="4" p:fullness="0" />
<BlockImage id="energy_cell" scale="4" p:fullness="1" />
<BlockImage id="energy_cell" scale="4" p:fullness="2" />
<BlockImage id="energy_cell" scale="4" p:fullness="3" />
<BlockImage id="energy_cell" scale="4" p:fullness="4" />
</Row>

Les barres sur le côté d'une cellule correspondent à la quantité d'énergie qu'elle contient.

*   0 en dessous de 25 % de charge
*   1 entre 25 % et 50 % de charge
*   2 entre 50 % et 75 % de charge
*   3 entre 75 % et 99 % de charge
*   4 au-dessus de 99 % de charge

## Types de cellules

*   La <ItemLink id="energy_cell" /> peut stocker 200k AE, et une seule devrait suffire dans la plupart des cas, absorbant sans peine les pics de consommation
    d'une utilisation normale du réseau.
*   La <ItemLink id="dense_energy_cell" /> peut stocker 1.6M AE et sert lorsque vous voulez faire fonctionner un réseau sur de l'énergie stockée, ou
    absorber l'énorme appel d'énergie instantané des grandes installations de [stockage spatial](../ae2-mechanics/spatial-io.md).
*   La <ItemLink id="creative_energy_cell" /> est un objet créatif destiné aux tests, qui fournit une PUISSANCE ILLIMITÉEEE ou quelque chose comme ça.

## Recettes

<Row>
  <RecipeFor id="energy_cell" />

  <RecipeFor id="dense_energy_cell" />
</Row>

