---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Matrices
  icon: silicon_press
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:silicon_press
- ae2:logic_processor_press
- ae2:calculation_processor_press
- ae2:engineering_processor_press
- ae2:name_press
---

# Matrices

Il existe 5 matrices différentes utilisables dans la <ItemLink id="inscriber" />.

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

<ItemImage id="name_press" scale="4" />

## Matrices de processeurs

Les matrices de silicium, de logique, de calcul et d'ingénierie servent à produire les [processeurs](processors.md).
Ces 4 matrices s'obtiennent en cassant un <ItemLink id="mysterious_cube" /> dans une [météorite](../ae2-mechanics/meteorites.md).
Elles peuvent aussi être dupliquées dans une <ItemLink id="inscriber" />.

<Column>
  <Row>
    <RecipeFor id="silicon_press" />

    <RecipeFor id="logic_processor_press" />
  </Row>

  <Row>
    <RecipeFor id="calculation_processor_press" />

    <RecipeFor id="engineering_processor_press" />
  </Row>
</Column>

## Matrice de nom

La matrice de nom peut être utilisée dans une presse pour nommer des objets, comme le ferait une enclume.

Pour la fabriquer, faites un clic droit avec le <ItemLink id="certus_quartz_cutting_knife" /> ou le <ItemLink id="nether_quartz_cutting_knife" />
et insérez un lingot de métal ; vous devrez alors taper le nom que vous
souhaitez inscrire sur la plaque, puis il ne vous restera qu'à extraire la plaque terminée. Vous pouvez utiliser une ou deux plaques à la fois dans la presse :
si vous en utilisez deux, le nom imprimé sera la combinaison des deux noms, d'abord l'emplacement du haut, puis celui du bas.
