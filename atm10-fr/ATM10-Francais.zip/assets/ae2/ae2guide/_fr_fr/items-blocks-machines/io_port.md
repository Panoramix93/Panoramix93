---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Port d'E/S ME
  icon: io_port
  position: 210
categories:
- devices
item_ids:
- ae2:io_port
---

# Le port d'E/S ME

<BlockImage id="io_port" p:powered="true" scale="8" />

Le port d'E/S vous permet de remplir ou de vider rapidement des [disques de stockage](../items-blocks-machines/storage_cells.md) depuis ou vers le
[stockage du réseau](../ae2-mechanics/import-export-storage.md).

Il peut être tourné avec une <ItemLink id="certus_quartz_wrench" />.

## Réglages

*   Le port d'E/S peut être réglé pour déplacer le disque vers les emplacements de sortie quand le disque est vide, plein, ou quand le travail est terminé.
*   Si une <ItemLink id="redstone_card" /> est insérée, des options apparaissent pour diverses conditions de redstone.
*   Au centre de l'interface, une flèche permet de choisir le sens du transfert : du disque vers le [stockage du réseau](../ae2-mechanics/import-export-storage.md),
    ou du stockage vers le disque.

## Améliorations

Le port d'E/S prend en charge les [améliorations](upgrade_cards.md) suivantes :

*   La <ItemLink id="speed_card" /> augmente la quantité de choses déplacées par opération.
*   La <ItemLink id="redstone_card" /> ajoute un contrôle par redstone, permettant une activation sur signal fort, sur signal faible ou une fois par impulsion.

## Recette

<RecipeFor id="io_port" />
