---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Accepteur d'énergie
  icon: energy_acceptor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_acceptor
---

# L'Accepteur d'énergie

<Row gap="20">
<BlockImage id="energy_acceptor" scale="8" /> 

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
</GameScene>
</Row>

L'accepteur d'énergie convertit les formes d'énergie courantes des autres mods techniques en la forme interne d'[énergie](../ae2-mechanics/energy.md) d'AE2,
l'AE. Le <ItemLink id="controller" /> sait aussi le faire, mais les faces du contrôleur sont précieuses, il est donc souvent préférable d'utiliser un accepteur
d'énergie à la place.

Les taux de conversion de la Forge Energy et de la Techreborn Energy sont les suivants

*   2 FE = 1 AE (Forge)
*   1 E  = 2 AE (Fabric)

La vitesse de conversion dépend entièrement de la quantité d'AE que votre réseau peut stocker, pour des raisons expliquées sur
[cette page](../ae2-mechanics/energy.md).

## Variantes

Les accepteurs d'énergie existent en 2 variantes : normale et plate/[élément de câble](../ae2-mechanics/cable-subparts.md). Cela vous permet de rendre certaines installations plus compactes.

Les accepteurs d'énergie peuvent être convertis de la version normale à la version plate dans une grille de fabrication.

## Recette

<RecipeFor id="energy_acceptor" />

<RecipeFor id="cable_energy_acceptor" />