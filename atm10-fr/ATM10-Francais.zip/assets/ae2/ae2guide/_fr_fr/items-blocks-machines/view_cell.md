---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Cellule de visualisation
  icon: view_cell
  position: 410
categories:
- tools
item_ids:
- ae2:view_cell
---

# Cellule de visualisation

<ItemImage id="view_cell" scale="2" />

Les cellules de visualisation servent à filtrer l'affichage des [terminaux](terminals.md). Vous les partitionnez dans un <ItemLink id="cell_workbench" />.

Par exemple, imaginons que vous vouliez qu'un terminal n'affiche qu'une sélection de matériaux de construction en pierre. Partitionnez la cellule de visualisation sur ces
matériaux et placez-la dans un terminal : seuls ces objets seront affichés.

Les cellules de visualisation sont additives : si vous avez une cellule de visualisation pour les planches de chêne et une autre pour la pierre, mettre les deux affichera
à la fois les planches et la pierre.

## Recette

<Recipe id="network/cells/view_cell_storage" />

<Recipe id="network/cells/view_cell" />
