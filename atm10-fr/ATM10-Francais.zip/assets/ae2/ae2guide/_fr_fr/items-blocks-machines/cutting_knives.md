---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Couteaux de découpe
  icon: certus_quartz_cutting_knife
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_cutting_knife
- ae2:nether_quartz_cutting_knife
---

# Outils en quartz

<Row>
  <ItemImage id="certus_quartz_cutting_knife" scale="4" />

  <ItemImage id="nether_quartz_cutting_knife" scale="4" />
</Row>

Les couteaux de découpe servent à fabriquer des <ItemLink id="name_press" /> et des <ItemLink id="cable_anchor" />.

Pour fabriquer une presse à nom, faites un clic droit avec le couteau de découpe et insérez un lingot de métal, puis saisissez le nom que vous
souhaitez inscrire sur la plaque et récupérez simplement la plaque terminée.

## Recettes

<Row>
  <RecipeFor id="certus_quartz_cutting_knife" />

  <RecipeFor id="nether_quartz_cutting_knife" />
</Row>
