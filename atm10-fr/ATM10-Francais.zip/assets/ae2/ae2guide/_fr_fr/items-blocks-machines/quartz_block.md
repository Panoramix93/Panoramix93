---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Bloc de quartz de certus
  icon: quartz_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_block
---

# Le bloc de quartz de certus

<BlockImage id="quartz_block" scale="8" />

Le bloc de stockage du <ItemLink id="certus_quartz_crystal" />. Il permet de fabriquer des [blocs de certus bourgeonnants](budding_certus.md)
ou des [blocs de certus décoratifs](decorative_certus.md).

## Recette

<RecipeFor id="quartz_block" />
