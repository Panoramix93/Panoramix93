---
navigation:
  title: Trucs et astuces
  position: 20
---

# Trucs et astuces

Tout un lot de petites recommandations en vrac

* Désinstallez Optifine
* Vous pouvez faire tourner et zoomer les scènes du guide qui comportent les boutons de zoom et d'affichage/masquage des annotations
* Gardez votre réseau en forme d'arbre et évitez les boucles
* Regroupez les [dispositifs](ae2-mechanics/devices.md) en bloc plein par groupes de 8 au maximum, à moins de bien comprendre comment les [canaux](ae2-mechanics/channels.md)
  circulent dans un réseau
* Choisissez un bois et conservez-le pour tous vos [modèles](items-blocks-machines/patterns.md). Oui, activer les substitutions
  dans les modèles fonctionne parfois, mais utiliser partout le même type de bois réduit grandement les tracas.
* Disposez vos [modèles](items-blocks-machines/patterns.md) verticalement dans le <ItemLink id="pattern_access_terminal" /> /
  répartissez vos modèles entre vos [fournisseurs](items-blocks-machines/pattern_provider.md) afin que les recettes puissent être exécutées en parallèle.
* Ajoutez une [cellule d'énergie](items-blocks-machines/energy_cells.md) pour que votre réseau puisse absorber les pointes de consommation.
* Vous pouvez utiliser de l'eau dans le <ItemLink id="condenser" />
* La meilleure façon de garder votre réseau propre est de ne pas y envoyer le butin de monstres au hasard, comme les épées et les armures. Chaque combinaison unique
  d'enchantement et de durabilité constitue un [type](ae2-mechanics/bytes-and-types.md) supplémentaire.
* Un événement « objet entrant dans le système » doit se produire lors du retour du résultat d'un [modèle de traitement](items-blocks-machines/patterns.md),
  par exemple via un <ItemLink id="import_bus" />, une <ItemLink id="interface" /> ou l'emplacement de retour d'un <ItemLink id="pattern_provider" /> :
  vous ne pouvez pas simplement envoyer le résultat par tuyau dans un coffre équipé d'un <ItemLink id="storage_bus" />.
* N'oubliez pas que vous pouvez faire tourner et zoomer les scènes du guide qui comportent les boutons de zoom et d'affichage/masquage des annotations
* Le <ItemLink id="pattern_provider" /> ne pousse que des lots de recette complets, et uniquement par une seule face. C'est utile
  pour s'assurer que les machines ne reçoivent pas de lots partiels, mais il arrive que vous souhaitiez envoyer les ingrédients à plusieurs endroits.
  Vous pouvez y parvenir avec une <ItemLink id="interface" />, soit en [sous-réseau « tuyau »](example-setups/pipe-subnet.md), soit en exploitant
  sa capacité à contenir simultanément plusieurs piles d'objets, fluides, produits chimiques, etc., pour l'utiliser comme une sorte de coffre/réservoir intermédiaire.
* Vous pouvez zoomer et faire tourner les scènes du guide qui comportent les boutons de zoom et d'affichage/masquage des annotations
