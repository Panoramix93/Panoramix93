---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Canaux
  icon: controller
---

# Canaux

Les [réseaux ME](me-network-connections.md) d'Applied Energistics 2 ont besoin de canaux
pour alimenter les [appareils](../ae2-mechanics/devices.md) qui utilisent le stockage en réseau ou d'autres services
du réseau. Voyez les canaux comme des câbles USB reliant tous vos appareils. Un ordinateur n'a qu'un nombre limité de
ports USB et ne peut donc gérer qu'un nombre limité d'appareils. La plupart des machines, des appareils en bloc plein
et des câbles standard ne transportent que 8 canaux au maximum. Vous pouvez voir les appareils en bloc plein et les câbles standard comme un faisceau de 8 « fils de canal ». En revanche, les [câbles denses](../items-blocks-machines/cables.md#dense-cable) peuvent en transporter
jusqu'à 32. Les seuls autres appareils capables d'en transmettre 32 sont le <ItemLink id="me_p2p_tunnel" />
et le [pont de réseau quantique](../items-blocks-machines/quantum_bridge.md). Chaque fois qu'un appareil consomme un canal, imaginez que vous retirez un « fil » USB
du faisceau : ce « fil » n'est évidemment plus disponible plus loin sur la ligne.

<GameScene zoom="7" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_demonstration_1.snbt" />

  <LineAnnotation color="#33ff33" from="1 .4 .7" to="2.4 .4 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .7" to="2.4 .6 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .6" to="2.6 .4 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.4 .6 .7" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .4 .7" to="2.4 .4 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .6 .6" to="2.6 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 .6" to="2.6 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.1 .6 1.5" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 1.5" to="2.9 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.6 .6 1.5" to="2.6 .9 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .1 1.5" to="2.4 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .4" to="3.5 .6 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="3.5 .6 .4" to="3.5 .9 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="3.5 .1 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .3" to="1.5 .6 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1.5 .6 .3" to="1.5 .9 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1.5 .1 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#ff3333" from="3.5 .5 .5" to="5.5 .5 .5" alwaysOnTop={true}>
  Les 8 canaux du câble sont déjà tous utilisés, le range-disque n'en obtient donc aucun.  
  </LineAnnotation>

  <LineAnnotation color="#993333" from="1 .5 .5" to="1.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="1.5 .5 .5" to="1.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2 .5 .5" to="2.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2.5 .5 .5" to="2.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="3 .5 .5" to="3.25 .5 .5" alwaysOnTop={true}/>

  <DiamondAnnotation pos="3.6 0.5 0.5" color="#ff0000">
        Les 8 canaux du câble sont déjà tous utilisés, le range-disque n'en obtient donc aucun.
    </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

Un moyen simple de voir comment les canaux sont utilisés et routés dans votre réseau est d'utiliser des [câbles intelligents](../items-blocks-machines/cables.md), qui affichent sur eux-mêmes les chemins et l'utilisation des canaux.

Les canaux consomment 1⁄128 ae/t par nœud traversé ; autrement dit, ajouter un
<ItemLink id="controller" /> à un réseau
comptant 8 appareils et plus de 96 nœuds peut en réalité faire baisser votre
consommation d'énergie, car cela change la manière dont les canaux sont attribués.

À noter : **LES CANAUX N'ONT RIEN À VOIR AVEC LA COULEUR DES CÂBLES**, la couleur des câbles sert uniquement à empêcher les câbles de se connecter.

## Routage des canaux

Lorsque vous utilisez un <ItemLink id="controller" />,
les canaux sont routés en 3 étapes. Ils empruntent d'abord le chemin le plus court à travers les machines adjacentes jusqu'au [câble normal](../items-blocks-machines/cables.md) le plus proche
(en verre, gainé ou intelligent). Ils empruntent ensuite le chemin le plus court dans ce câble normal jusqu'au [câble dense](../items-blocks-machines/cables.md) le plus proche
(dense ou dense intelligent). Puis ils empruntent le chemin le plus court dans ce câble dense jusqu'au <ItemLink id="controller" />.
Si le chemin le plus court est déjà saturé, certains [appareils](devices.md) risquent de ne pas obtenir les canaux dont ils ont besoin :
servez-vous des câbles colorés, des ancrages de câble et des tunnels pour que vos canaux suivent le chemin souhaité.

Par exemple, dans ce cas, certains range-disques n'obtiennent pas de canaux : même si les câbles ont une capacité suffisante,
les canaux essaient d'emprunter le chemin le plus court, ce qui sature certains câbles et en laisse d'autres vides.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 3.6" to="1.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.4 0.5 3.6" to="1.4 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 1.6" to="0.6 .5 1.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 1.6" to="0.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 3.4" to="1.4 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 3.4" to="1.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <BoxAnnotation color="#dddddd" min="1.2 0.2 3.2" max="1.8 0.8 3.8" alwaysOnTop={true} thickness="0.05">
        Plus de 8 canaux tentent de passer par ici, certains sont donc coupés.
  </BoxAnnotation>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

On peut corriger cela en contraignant plus soigneusement les chemins que les canaux peuvent emprunter. Les réseaux doivent avoir une structure en arbre (ou en buisson).
Les boucles et les chemins de canaux ambigus doivent être réduits au minimum.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue_fix.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 5.6" to="1 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

## Réseaux ad hoc

Un réseau dépourvu de <ItemLink id="controller" />
est considéré comme ad hoc et peut alimenter jusqu'à 8 appareils consommant des canaux.
Dès que vous dépassez 8 appareils, les appareils du réseau qui utilisent des canaux s'éteignent ;
vous pouvez soit retirer des appareils, soit ajouter un <ItemLink id="controller" />.

Contrairement aux réseaux dotés d'un contrôleur, les [câbles intelligents](../items-blocks-machines/cables.md) sur un réseau ad hoc affichent le nombre
de canaux utilisés dans tout le réseau, et non le nombre de canaux qui circulent dans ce câble précis.

Sur un réseau ad hoc, chaque appareil utilise
1 canal à l'échelle du réseau entier, ce qui est très différent de la façon dont un <ItemLink id="controller" /> attribue les canaux
selon le chemin le plus court.

## Conception

Comme indiqué plus haut dans [routage des canaux](channels.md#channel-routing), il est préférable de concevoir votre réseau en arbre : des câbles denses qui partent du contrôleur, des câbles normaux
qui partent des câbles denses, et des [appareils](../ae2-mechanics/devices.md) regroupés par 8 au maximum sur les câbles normaux.

Voici un exemple de ce qu'il ne faut pas faire :

En suivant les chemins des canaux :

1. Juste à la sortie du contrôleur, vers la droite, nous sommes limités à 8 canaux car le range-disque se comporte comme un câble normal.
Mais comme nous n'utilisons pas de câble intelligent ici, nous ne pouvons pas voir combien de canaux sont utilisés. Il reste 8 canaux.
2. Le range-disque prend un canal.
Il reste 7 canaux.
3. 2 canaux montent vers les terminaux.
Il reste 5 canaux.
4. En continuant vers la droite, l'interface prend un autre canal.
Il reste 4 canaux.
5. 1 canal monte vers le fournisseur de modèles.
Il reste 3 canaux.
6. En continuant vers la droite, 1 canal monte vers le bus d'importation.
Il reste 2 canaux.
7. Le groupe de fournisseurs de modèles qui alimentent les assembleurs n'obtient que 2 canaux : 2 des fournisseurs n'ont donc aucun canal.

Au final, l'erreur est de créer un goulot d'étranglement sur les canaux sans réfléchir à la manière dont ils vont être répartis.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/bad_network_structure.snbt" />

<LineAnnotation color="#33ff33" from="6.5 .5 1.5" to="6 .5 1.5" alwaysOnTop={true} thickness="0.4">
  32 canaux
</LineAnnotation>

<LineAnnotation color="#33ff33" from="6 .5 1.5" to="5.5 .5 1.5" alwaysOnTop={true} thickness="0.2">
  8 canaux
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 1.5 1.5" alwaysOnTop={true} thickness="0.1">
  2 canaux
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 1.5 1.5" to="5.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 2.5 1.5" to="5.5 2.5 1.1" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="4.5 .5 1.5" alwaysOnTop={true} thickness="0.158">
  5 canaux
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 1.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="3.5 .5 1.5" alwaysOnTop={true} thickness="0.122">
  3 canaux
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="3.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 2.5 1.5" to="3.7 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="1.5 .5 1.5" alwaysOnTop={true} thickness="0.1">
  2 canaux
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="1.5 0.3 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="0.5 0.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#33ff33" from="0.5 0.5 1.5" to="0.5 0.5 0.5" alwaysOnTop={true} thickness="0.071">
  1 canal
</LineAnnotation>

<LineAnnotation color="#ff3333" from="0.5 1.5 1.5" to="0.5 1.3 1.5" alwaysOnTop={true} thickness="0.071">
  aucun canal
</LineAnnotation>

<LineAnnotation color="#ff3333" from="1.5 1.5 0.5" to="1.5 1.3 0.5" alwaysOnTop={true} thickness="0.071">
  aucun canal
</LineAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

---

Voici un exemple de bonne structure :

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/treelike_network_structure.snbt" />

    <BoxAnnotation color="#dddddd" min="6.9 0 4.9" max="9.1 4 7.1" thickness="0.05">
        Remarquez que les fournisseurs de modèles sont répartis en groupes distincts de 8.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 4 4" max="8 5 5" thickness="0.05">
        Deux câbles normaux remplis de canaux qui se rejoignent impliquent d'utiliser un câble dense.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 0 13" max="8 1 14" thickness="0.05">
        Des couleurs de câble différentes sont utilisées pour empêcher les câbles adjacents de se connecter.
    </BoxAnnotation>


  <IsometricCamera yaw="315" pitch="30" />
</GameScene>

## Modes de canaux

AE2 10.0.0 pour Minecraft 1.18 introduit de nouvelles options pour changer le comportement des canaux d'AE2 dans votre monde.
Une nouvelle option de configuration dans la section générale (`channels`) contrôle ce comportement, et une nouvelle commande
en jeu permet aux opérateurs de changer le mode et la configuration depuis la partie. La commande est `/ae2 channelmode <mode>`
pour le modifier et `/ae2 channelmode` pour afficher le mode actuel. Lorsque le mode est changé en jeu, toutes les grilles
existantes redémarrent et utilisent immédiatement le nouveau mode.

Cela ressuscite et améliore l'option qui existait dans Minecraft 1.12, et offre de meilleures possibilités aux joueurs
qui veulent simplement un jeu un peu plus détendu sans pour autant supprimer complètement cette mécanique.

Le tableau suivant liste les modes disponibles, dans le fichier de configuration comme dans la commande.

| Réglage    | Description                                                                                                                                                                                                                               |
| ---------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `default`  | Le mode standard, avec les capacités de canaux des câbles et des réseaux ad hoc telles qu'elles sont décrites dans tout ce site                                                                                                           |
| `x2`       | Toutes les capacités de canaux sont doublées (16 sur câble normal, 64 sur câble dense, les réseaux ad hoc gèrent 16 canaux)                                                                                                               |
| `x3`       | Toutes les capacités de canaux sont triplées (24 sur câble normal, 92 sur câble dense, les réseaux ad hoc gèrent 24 canaux)                                                                                                               |
| `x4`       | Toutes les capacités de canaux sont quadruplées (32 sur câble normal, 128 sur câble dense, les réseaux ad hoc gèrent 32 canaux)                                                                                                           |
| `infinite` | Toutes les restrictions de canaux sont supprimées. Les contrôleurs réduisent toujours *significativement* la consommation d'énergie des grilles. Les câbles intelligents basculent uniquement entre complètement éteint (aucun canal transporté) et complètement allumé (1 canal ou plus transporté). |