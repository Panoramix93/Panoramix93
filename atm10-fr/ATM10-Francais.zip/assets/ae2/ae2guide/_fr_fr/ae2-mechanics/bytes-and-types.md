---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Octets et types
  icon: creative_storage_cell
---

# Octets et types

<Row>
    <ItemImage id="item_storage_cell_1k" scale="4" />

    <ItemImage id="item_storage_cell_4k" scale="4" />

    <ItemImage id="item_storage_cell_16k" scale="4" />

    <ItemImage id="item_storage_cell_64k" scale="4" />

    <ItemImage id="item_storage_cell_256k" scale="4" />
  </Row>

Les [disques de stockage](../items-blocks-machines/storage_cells.md) sont définis à la fois par des *octets* et par des *types*. Les octets, comme dans
votre véritable ordinateur, mesurent la quantité totale de « choses » contenues dans un disque de stockage. Les types mesurent le nombre de « choses »
différentes, eh bien, de *types* différents, stockées dans un disque. Chaque type représente un objet unique : 4 096 blocs de pierre font donc 1 type, mais 16 épées
différentes avec des enchantements différents font 16 types.

Chaque disque de stockage peut contenir une quantité fixe
de données. Chaque type consomme d'emblée un certain nombre d'octets (qui varie selon la taille
du disque), et chaque objet consomme un bit de stockage : huit objets consomment donc un
octet, et une pile complète de 64 en consomme 8, quelle que soit la façon dont l'objet
s'empilerait en dehors d'un réseau ME. Par exemple, 64 selles identiques ne prennent
pas plus de place que 64 blocs de pierre.

Encore une fois, chaque objet vaut 1 bit, donc 8 objets font 1 octet. Pour les disques de fluide, cela correspond à 8 seaux par octet.

Beaucoup de gens se plaignent du nombre limité de types qu'un disque peut contenir, mais il s'agit d'une ***limitation nécessaire***.
Les disques stockent leurs données dans une balise NBT portée par l'objet lui-même, ce qui les rend plutôt stables. En revanche, cela signifie que mettre trop de
données sur un disque peut provoquer l'envoi d'une quantité excessive de données à un joueur, avec un effet proche du « Book Banning » de Minecraft vanilla.
De plus, avoir trop de types différents dans votre système alourdit le tri et la manipulation des objets. Cette limitation
ne s'avère toutefois pas très contraignante. Une baie de <ItemLink id="drive" /> remplie de disques représente 630 types, ce qui est en réalité
déjà beaucoup, du moment que vous ne stockez pas des masses d'objets uniques non empilables.

C'est pour cette raison que les types existent : pour vous « décourager fermement » de déverser directement dans votre système ME les centaines d'armures et d'outils
aux dégâts aléatoires issus d'une ferme à monstres. Chaque pièce d'armure avec des dégâts et des enchantements uniques doit être stockée comme une entrée distincte,
ce qui fait gonfler le tout. Il est recommandé de les filtrer hors du flux d'objets avant qu'ils n'atteignent votre système.

Viser directement les disques de stockage du plus haut niveau n'est généralement pas la meilleure idée,
car vous dépensez plus de ressources sans gagner de capacité de types supplémentaire. Cela veut dire que toutes les tailles de disque restent utiles, même
en fin de partie, puisqu'elles ont chacune leurs compromis.

Voici un tableau comparant les différents niveaux de disques de stockage, leur capacité et
une estimation approximative de leur coût.

## Contenu des disques de stockage et coût

| Disque                                   |  Octets | Types | Octets par type | Certus | Redstone | Or | Pierre lumineuse |
| ---------------------------------------- | ------: | ----: | -------------: | -----: | -------: | ---: | --------: |
| <ItemLink id="item_storage_cell_1k" />   |   1 024 |    63 |              8 |      4 |        5 |    1 |         0 |
| <ItemLink id="item_storage_cell_4k" />   |   4 096 |    63 |             32 |  14,25 |       20 |    3 |         0 |
| <ItemLink id="item_storage_cell_16k" />  |  16 384 |    63 |            128 |     45 |       61 |    9 |         4 |
| <ItemLink id="item_storage_cell_64k" />  |  65 536 |    63 |            512 | 137,25 |      184 |   27 |        16 |
| <ItemLink id="item_storage_cell_256k" /> | 262 144 |    63 |           2048 |    414 |      553 |   81 |        48 |

## Capacité de stockage selon le nombre de types

Le coût initial des types est tel qu'un disque ne contenant qu'1 type peut contenir 2 fois plus qu'un disque dont les 63 types sont utilisés.

| Disque                                   | Capacité totale du disque avec 1 type utilisé | Capacité totale du disque avec 63 types utilisés |
| ---------------------------------------- | ----------------------------------------: | ------------------------------------------: |
| <ItemLink id="item_storage_cell_1k" />   |                                     8 128 |                                       4 160 |
| <ItemLink id="item_storage_cell_4k" />   |                                    32 512 |                                      16 640 |
| <ItemLink id="item_storage_cell_16k" />  |                                   130 048 |                                      66 560 |
| <ItemLink id="item_storage_cell_64k" />  |                                   520 192 |                                     266 240 |
| <ItemLink id="item_storage_cell_256k" /> |                                 2 080 768 |                                   1 064 960 |

![Un disque avec 1 type](../assets/diagrams/1_type_cell.png)

![Un disque avec 63 types](../assets/diagrams/63_type_cell.png)
