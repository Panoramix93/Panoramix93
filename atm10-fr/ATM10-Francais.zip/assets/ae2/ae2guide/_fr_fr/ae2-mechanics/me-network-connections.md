---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Connexions réseau
  icon: fluix_glass_cable
---

# Connexions réseau

## Que signifie « réseau » ?

Un « réseau » est un ensemble d'[appareils](../ae2-mechanics/devices.md) reliés par des blocs capables de transmettre des [canaux](../ae2-mechanics/channels.md),
comme les [câbles](../items-blocks-machines/cables.md) ou les machines et [appareils](../ae2-mechanics/devices.md) à bloc plein.
(<ItemLink id="charger" />, <ItemLink id="interface" />, <ItemLink id="drive" />, etc.)
Techniquement, un simple câble constitue déjà un réseau.

## Une remarque sur le positionnement des appareils

Pour les [appareils](../ae2-mechanics/devices.md) qui remplissent une fonction réseau particulière (comme une <ItemLink id="interface" />
qui insère et retire des objets du [stockage réseau](../ae2-mechanics/import-export-storage.md), un <ItemLink id="level_emitter" />
qui lit le contenu du stockage réseau, un <ItemLink id="drive" /> qui sert de stockage réseau, etc.),
la position physique de l'appareil n'a aucune importance.

Répétons-le : **la position physique de l'appareil n'a aucune importance**. Tout ce qui compte, c'est que l'appareil soit connecté au réseau
(et, bien entendu, à quel réseau il est connecté).

## Connexions réseau

Un moyen simple de déterminer ce qui est connecté à un réseau consiste à utiliser un <ItemLink id="network_tool" />. Il affiche tous les
composants du réseau : si vous y voyez des éléments qui ne devraient pas s'y trouver, ou si des éléments attendus sont absents, vous avez un problème.

Par exemple, voici 2 réseaux distincts.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        Réseau 1
  </BoxAnnotation>

<BoxAnnotation color="#5CA7CD" min="2 0 0" max="3 2 2">
        Réseau 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Voici également 2 réseaux distincts, car la <ItemLink id="quartz_fiber" /> partage l'[énergie](../ae2-mechanics/energy.md)
sans établir de connexion réseau.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        Réseau 1
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="1.3 0 0" max="3 2 2">
        Réseau 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

En revanche, ceci ne forme qu'un seul réseau, et non 2 réseaux distincts. Le [pont quantique](../items-blocks-machines/quantum_bridge.md) se comporte
comme un [câble dense](../items-blocks-machines/cables.md#dense-cable) sans fil : les deux extrémités appartiennent donc au même réseau.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="7 3 3">
        Un seul réseau
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Ceci ne forme également qu'un seul réseau, car la couleur des [câbles](../items-blocks-machines/cables.md) n'a rien à voir avec les connexions réseau, hormis le fait que
des câbles de couleurs différentes ne se connectent pas entre eux. Toutes les couleurs se connectent aux câbles fluix (ou « sans couleur »).

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        Un seul réseau
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Les connexions dans le contexte des sous-réseaux

Les [sous-réseaux](../ae2-mechanics/subnetworks.md) tirent parti des connexions réseau (et surtout de l'**ABSENCE** de connexion)
pour restreindre les appareils auxquels tel ou tel [appareil](../ae2-mechanics/devices.md) a accès.

Au fond, un sous-réseau n'est rien d'autre qu'un réseau séparé.

Prenons par exemple le [raffineur automatique de minerais](../example-setups/ore-fortuner.md). Il y a ici 3 réseaux distincts,
chacun remplissant un rôle précis dans l'installation.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 2" max="3 1 3">
        Réseau 1 : il fait office de sous-réseau « tuyau » et restreint ce à quoi le bus d'importation a accès, de sorte qu'il « stocke » les blocs de
        minerai à travers les plans de formation.
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="0 0 0" max="3 1 1">
        Réseau 2 : il fait office d'un autre sous-réseau « tuyau » et restreint ce à quoi les plans d'annihilation ont accès, afin qu'ils stockent
        les fragments de minerai raffinés dans le tonneau et non dans votre réseau principal. Cela signifie aussi qu'ils ne consomment aucun canal sur le
        réseau principal.
  </BoxAnnotation>

  <BoxAnnotation color="#82CD5C" min="2 0 1" max="4 1 2">
        Réseau 3 : le réseau principal, avec tout votre stockage et votre fabrication. En réalité, il n'est là que pour fournir l'énergie, et il n'est
        justement *pas* connecté aux 2 sous-réseaux.
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Les connexions dans le contexte du P2P

Une variante de [tunnel P2P](../items-blocks-machines/p2p_tunnels.md) transporte des [canaux](channels.md) au lieu d'objets, de fluides
ou de signaux de redstone, et cela déroute beaucoup de monde. Le réseau sur lequel le tunnel est monté n'a rien à voir avec le
réseau que le tunnel transporte. Il *peut* s'agir du même réseau, mais ce n'est pas obligatoire, et ce n'est généralement pas le cas.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_channels_network_connection.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1.98 2 1">
        Réseau 1, le réseau transporté (généralement votre réseau principal)
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="2.02 0 0" max="3.98 1 1">
        Réseau 2, le réseau qui fait tourner les tunnels P2P ME (généralement *pas* votre réseau principal)
  </BoxAnnotation>

  <BoxAnnotation color="#915dcd" min="4.02 0 0" max="6 1 1">
        Réseau 1, le réseau transporté (généralement votre réseau principal)
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Des connexions moins intuitives

Dans ce cas, il n'y a qu'un seul réseau, car le <ItemLink id="pattern_provider" />, étant un appareil à bloc plein, se comporte
comme un câble, et la <ItemLink id="inscriber" /> fait de même. La connexion réseau traverse donc
le fournisseur et la presse.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        Un seul réseau
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Pour éviter cela (utile pour de nombreuses installations de fabrication automatique faisant appel à des [sous-réseaux](../ae2-mechanics/subnetworks.md)),
vous pouvez faire un clic droit sur le fournisseur avec une <ItemLink id="certus_quartz_wrench" /> afin de le rendre directionnel : il ne
transmettra alors plus les canaux sur l'une de ses faces.

<Row gap="40">
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1.98 2 2">
        Réseau 1
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="2.02 0 0" max="4 2 2">
        Réseau 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_directional_connection.snbt" />

  <BoxAnnotation color="#ee3333" min="1 .3 .3" max="1.3 .7 .7">
        Observez que le câble ne se connecte pas
  </BoxAnnotation>

  <IsometricCamera yaw="255" pitch="30" />
</GameScene>
</Row>

Les autres éléments qui n'établissent pas de connexion réseau directionnelle sont la plupart des [appareils](../ae2-mechanics/devices.md)
[en sous-partie](../ae2-mechanics/cable-subparts.md), comme les <ItemLink id="import_bus" />, les <ItemLink id="storage_bus" /> et les
<ItemLink id="cable_interface" />.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/subpart_no_connection.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
