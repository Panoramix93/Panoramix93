---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Spatial IO
  icon: spatial_storage_cell_2
---

# Spatial IO

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/spatial_storage_1x1x1.snbt" />

  <BoxAnnotation color="#33dd33" min="1 1 1" max="2 2 2">
        Le volume à déplacer
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />

</GameScene>

Le Spatial IO est un moyen de couper-coller des volumes physiques d'espace dans votre monde. Il peut servir à déplacer du <ItemLink id="flawless_budding_quartz" />,
à aménager dans votre base une pièce dont vous pouvez échanger les différents intérieurs pour l'utiliser à des fins variées, ou même à déplacer
le portail de l'End !

Son fonctionnement consiste à *échanger* le volume défini avec un volume de taille identique situé dans la dimension de stockage spatial : ce qui se trouve
dans le réseau de pylônes est envoyé vers la dimension de stockage spatial, et ce qui se trouve dans la dimension est envoyé vers le réseau de pylônes.

Cela signifie que si vous avez un moyen de voyager entre les dimensions (le Spatial IO *peut* servir à fabriquer un téléporteur,
mais le faire est très complexe, un peu bancal, et dépasse le cadre de ce guide), vous pouvez les utiliser comme des machines compactes de taille personnalisée ou des
dimensions de poche.

# L'assemblage multibloc

Le Spatial IO nécessite une disposition précise de ses composants pour fonctionner et pour définir le volume à couper-coller.

Tous les composants doivent se trouver sur le même [réseau](me-network-connections.md) pour fonctionner, et vous ne pouvez avoir qu'un seul
assemblage Spatial IO par réseau. Un [sous-réseau](subnetworks.md) est donc recommandé.

## Le port Spatial IO

<BlockImage id="spatial_io_port" p:powered="true" scale="4" />

Le <ItemLink id="spatial_io_port" /> contrôle l'opération de Spatial IO. Il affiche les statistiques de l'assemblage multibloc et contient
les [disques spatiaux](../items-blocks-machines/spatial_cells.md)

Il affiche
- L'[énergie](energy.md) stockée et maximale du réseau
- L'énergie requise pour effectuer l'opération. Elle peut être assez importante et est consommée instantanément, assurez-vous donc d'avoir assez de
  [cellules d'énergie](../items-blocks-machines/energy_cells.md) pour la stocker entièrement.
- L'efficacité du réseau de pylônes
- La taille du volume défini

Pour effectuer une opération de Spatial IO, placez un disque de stockage spatial dans l'emplacement d'entrée et envoyez une impulsion de redstone au port Spatial IO.
Il *échangera* alors le volume délimité par les pylônes avec le volume situé dans la dimension de stockage spatial. Cela signifie que si vous envoyez un
ensemble de blocs vers la dimension de stockage spatial, *puis que vous placez un autre ensemble de blocs dans les pylônes*, que vous remettez le disque dans l'emplacement d'entrée
et que vous déclenchez de nouveau le port IO, le 2e ensemble de blocs disparaîtra et le 1er ensemble de blocs réapparaîtra.

**ATTENTION : toute entité présente dans le volume défini, vous y compris, sera emportée, et si vous n'avez aucun moyen d'en sortir, vous serez piégé
dans la dimension de stockage spatial, dans une boîte sombre et vide.** Servez-vous-en pour faire des blagues à vos amis !

## Les pylônes

<BlockImage id="spatial_pylon" p:powered_on="true" scale="4" />

Les <ItemLink id="spatial_pylon" /> sont la partie principale d'un assemblage Spatial IO et définissent le volume à affecter.

Le volume est défini par la boîte englobante de l'extérieur des pylônes, réduite de 1 bloc dans toutes les directions.

Les règles sont les suivantes :
- Taille minimale de 3x3x3 (ce qui définit un volume de 1x1x1)
- Tous les pylônes spatiaux doivent se trouver dans la boîte englobante extérieure
- Tous les pylônes spatiaux doivent être sur le même réseau
- Tous les pylônes doivent mesurer au moins 2 blocs de long

Par exemple, supposons que vous voulez définir un volume de 3x3x3. D'après la règle 2, tous les pylônes doivent se trouver dans une coque de 5x5x5 autour
du volume que vous voulez définir. Ils peuvent être disposés de presque n'importe quelle manière, du moment qu'ils restent contenus dans cette coque
de 5x5x5 d'une épaisseur de 1 bloc.

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/spatial_storage_3x3x3_pylon_demonstration.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
        Le volume à déplacer
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Un assemblage plus raisonnable est celui-ci :

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/better_spatial_storage_3x3x3.snbt" />

<BoxAnnotation color="#33dd33" min="1 1 1" max="4 4 4">
        Le volume à déplacer
  </BoxAnnotation>

<BoxAnnotation color="#3333ff" min="5 5 0" max="0 0 5">
  </BoxAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Efficacité

L'efficacité du réseau de pylônes dépend de la proportion de la coque que vous remplissez. Des assemblages minimalistes autour de grands volumes
seront très inefficaces et nécessiteront peut-être des *milliards* d'AE.

## Dimensions des disques

Une fois qu'un [disque spatial](../items-blocks-machines/spatial_cells.md) a été utilisé, il acquiert définitivement un jeu de dimensions XYZ (par exemple 3x4x2)
et se trouve lié à un volume d'espace dans la dimension de stockage spatial. **VOUS NE POUVEZ PAS RÉINITIALISER, REFORMATER NI REDIMENSIONNER UN DISQUE SPATIAL APRÈS
SA PREMIÈRE UTILISATION.** Fabriquez un nouveau disque si vous voulez utiliser d'autres dimensions. 

Il ne s'agit pas des mêmes dimensions que celles du nom d'un disque : un disque 16^3 peut avoir n'importe quelles dimensions *jusqu'à* 16x16x16

Notez que ce volume est orienté et ne peut pas être pivoté. Un volume de 2x2x3 n'est pas identique à un volume de 3x2x2, même s'ils ont la
même taille.

si les dimensions XYZ d'un disque ne correspondent pas au volume défini (visible dans le port IO), le port IO ne fonctionnera pas.
