---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Météorites
  icon: sky_stone_block
---

# Météorites

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/meteor_interior.snbt" />
</GameScene>

Les météorites sont le point de départ de l'utilisation d'AE2. Elles fournissent des matériaux essentiels : des
[blocs de certus bourgeonnant](../items-blocks-machines/budding_certus.md) de différents types et un
<ItemLink id="mysterious_cube" /> en leur centre.

La page [Premiers pas](../getting-started.md) vous indiquera quoi faire une fois que vous en aurez trouvé une.

## Trouver des météorites

Les météorites sont assez courantes et laissent d'énormes cratères dans le sol : vous en avez donc peut-être déjà
croisé quelques-unes. Sinon, une <ItemLink id="meteorite_compass" /> pointe vers le cube mystérieux le plus proche.

![Meteorite Crater](../assets/assemblies/meteorite-crater.png)
