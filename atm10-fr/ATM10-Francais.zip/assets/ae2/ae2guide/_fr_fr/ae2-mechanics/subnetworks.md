---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Sous-réseaux
---

# Sous-réseaux

<GameScene zoom="4" interactive={true}>
<ImportStructure src="../assets/assemblies/subnet_demonstration.snbt" />

<DiamondAnnotation pos="6.5 2.5 0.5" color="#00ff00">
        Sous-réseau « tuyau à objets »
    </DiamondAnnotation>

<DiamondAnnotation pos="5.5 2.5 0.5" color="#00ff00">
        Sous-réseau « tuyau à fluides »
    </DiamondAnnotation>

<DiamondAnnotation pos="4.5 2.5 0.5" color="#00ff00">
        Plan d'annihilation filtré
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 2.5 0.5" color="#00ff00">
        Sous-réseau à plan de formation
    </DiamondAnnotation>

<DiamondAnnotation pos="2.5 2.5 0.5" color="#00ff00">
        Sous-réseau exploitant l'interaction interface / bus de stockage ME pour servir de stockage secondaire local auquel le réseau
principal peut accéder
    </DiamondAnnotation>

<DiamondAnnotation pos="1.5 1.5 0.5" color="#00ff00">
        Un autre sous-réseau « tuyau à objets », pour renvoyer les objets chargés vers le Fournisseur de pattern ME
    </DiamondAnnotation>

<IsometricCamera yaw="195" pitch="30" />
</GameScene>

« Sous-réseau » est un terme assez vaguement défini, mais on peut dire qu'un sous-réseau est tout [réseau](../ae2-mechanics/me-network-connections.md) qui assiste votre
réseau principal ou accomplit une petite tâche. Ils sont généralement assez petits pour ne pas nécessiter de contrôleur. Leurs 2 usages principaux sont :

* Restreindre le stockage auquel certains [appareils](../ae2-mechanics/devices.md) ont accès (vous ne voulez pas que le bus d'importation d'un sous-réseau « tuyau » ait accès au stockage
    de votre réseau principal, sinon il déposera les objets dans vos disques de stockage au lieu de l'inventaire de destination).
* Économiser des canaux sur votre réseau principal : par exemple, faire qu'un Fournisseur de pattern ME alimente une interface reliée à plusieurs bus
    de stockage ME sur plusieurs machines, en n'utilisant qu'1 canal, au lieu de placer un Fournisseur de pattern ME sur chaque machine, ce qui consommerait plusieurs canaux.

Lorsqu'on monte un sous-réseau, il est très important de garder à l'œil les [connexions réseau](../ae2-mechanics/me-network-connections.md).
Souvent, on assemble un amas d'interfaces, de bus et d'autres composants en s'attendant à obtenir un sous-réseau, alors que
tous les appareils restent connectés au réseau principal à travers divers appareils à bloc plein.

Les câbles de couleurs différentes n'ont rien à voir avec la création d'un sous-réseau, hormis le fait qu'ils ne se connectent pas entre eux.

Quelques exemples :

* Une installation qui remplace votre poubelle / amélioration de destruction par tout un réseau AE2 qui décide de la meilleure façon d'exploiter vos déchets. Acheminer intelligemment
  les objets vers un ensemble de composteurs ou vers un recycleur moddé selon la disponibilité et la demande.
* Créer des abstractions. Gérer tous les détails d'une opération de fabrication complexe depuis votre sous-réseau, de sorte que, du point de vue
  de votre réseau principal, toute l'usine « ressemble » à une seule machine.
* Le parallélisme. Remplacer une machine lente par 10 copies de cette machine lente. Du point de vue de votre réseau principal,
  rien n'a changé, et vous n'utilisez même pas plus de canaux.
* Un bus d'importation et un bus de stockage ME configurés pour transférer des objets ou des fluides d'un conteneur à un autre, comme un tuyau à objets ou à fluides.
* Un plan d'annihilation et un bus de stockage ME, pour que le seul endroit où le plan d'annihilation puisse déposer ce qu'il casse soit le bus de stockage ME, ce qui vous permet de filtrer le plan.
* Une interface et un plan de formation, pour que tout ce qui est inséré dans l'interface soit envoyé au plan de formation puis placé ou lâché dans le monde.
* Une installation qui produit automatiquement du quartz certus, régulée et contrôlée par un <ItemLink id="level_emitter" /> sur le réseau principal.
* Un système de stockage spécialisé, accessible depuis le réseau principal via l'interaction particulière entre bus de stockage ME et interface, afin de stocker la production d'une ferme sans faire déborder sans fin votre stockage principal.
* Et ainsi de suite

La <ItemLink id="quartz_fiber" /> est très utile pour créer des sous-réseaux. Elle transfère l'énergie entre réseaux sans
les connecter, ce qui vous permet d'alimenter vos sous-réseaux sans avoir à placer des accepteurs d'énergie et des câbles d'alimentation partout.
