---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Appareils
  icon: interface
---

# Appareils

Un « appareil » désigne un composant de réseau AE2 qui remplit une fonction liée au réseau lui-même. Ils nécessitent presque toujours
un canal, à la notable exception des [émetteurs de niveau](../items-blocks-machines/level_emitter.md).

Quelques exemples :

*   <ItemLink id="interface" />
*   <ItemLink id="import_bus" />
*   <ItemLink id="storage_bus" />
*   <ItemLink id="pattern_provider" />
*   <ItemLink id="drive" />
