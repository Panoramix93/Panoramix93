---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Énergie
  icon: energy_cell
---

# L'énergie

Votre réseau a besoin d'énergie pour fonctionner. Les réseaux disposent d'une réserve d'énergie dans laquelle les [appareils](../ae2-mechanics/devices.md) puisent directement, et que
les <ItemLink id="vibration_chamber" />, les <ItemLink id="energy_acceptor" /> (et les <ItemLink id="controller" />) alimentent. Vous pouvez
consulter les statistiques énergétiques d'un réseau en cliquant droit n'importe où dessus avec un <ItemLink id="network_tool" />, ou en
cliquant droit sur le contrôleur du réseau, s'il en possède un. Comme le stockage et la distribution se font à l'échelle du réseau entier,
il n'existe aucune limite de débit de transfert d'énergie : les appareils peuvent donc puiser des quantités d'énergie arbitrairement élevées et les
accepteurs d'énergie peuvent en absorber à une vitesse pratiquement illimitée, dans la seule limite de votre stockage d'énergie.

## Acceptation de l'énergie

<Row>
  <BlockImage id="energy_acceptor" scale="4" />

  <GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
  </GameScene>

  <BlockImage id="controller" p:state="online" scale="4" />

  <BlockImage id="vibration_chamber" p:active="true" scale="4" />
  
  <BlockImage id="crystal_resonance_generator" scale="4" />
</Row>

En interne, AE2 n'utilise ni la Forge Energy (sur Forge) ni la TechReborn Energy (sur Fabric). Il les convertit dans
sa propre unité, l'AE. Cette conversion est à sens unique. L'énergie peut être convertie par les <ItemLink id="energy_acceptor" /> et les
<ItemLink id="controller" />, même s'il est préférable de réserver les faces du contrôleur à davantage de [canaux](../ae2-mechanics/channels.md).
Elle peut aussi être produite par les <ItemLink id="vibration_chamber" />, ou passivement avec un <ItemLink id="crystal_resonance_generator" />, mais AE2 est conçu
pour être utilisé avec d'autres mods techniques offrant une meilleure production d'énergie.

Tout cela signifie qu'il vaut mieux considérer un réseau AE2 comme une seule grande machine multibloc lorsque vous concevez
l'infrastructure de distribution d'énergie de votre base.

Les taux de conversion de la Forge Energy et de la TechReborn Energy sont les suivants :

*   2 FE = 1 AE (Forge)
*   1 E  = 2 AE (Fabric)

## Stockage de l'énergie

<Row>
  <BlockImage id="energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="4" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="4" />
</Row>

Pour des raisons assez évidentes, un réseau ne peut ni absorber ni consommer plus d'énergie en un tick de jeu qu'il ne peut en stocker. Si un réseau
ne peut stocker que 800 AE, lorsque ses [appareils](../ae2-mechanics/devices.md) demandent de l'énergie, ils ne pourront en utiliser que 800 AE au maximum (en supposant le stockage plein),
et un accepteur d'énergie ne pourra injecter que 800 AE au maximum dans le réseau (en supposant le stockage vide).

C'est une cause fréquente de comportements étranges : on monte un petit réseau avec juste un accepteur d'énergie, un range-disque, un terminal et
quelques appareils, puis on essaie de déverser tout un inventaire de pierre dans le réseau. Insérer toute cette pierre d'un coup, en un
seul tick de jeu, demande plus d'énergie que le réseau n'en a en stock : toute la pierre n'est donc pas insérée, le réseau
tombe en panne d'énergie et redémarre.

**Le problème se résout en ajoutant des cellules d'énergie.**

Les réseaux disposent d'un tampon d'énergie intégré de 25 AE par câble, machine ou composant.

Les <ItemLink id="controller" /> possèdent une petite réserve d'énergie interne, de 8 000 AE

La <ItemLink id="energy_cell" /> peut stocker 200 000 AE ; une seule devrait suffire dans la plupart des cas, absorbant sans difficulté les pics de consommation
d'un réseau en usage normal.

La <ItemLink id="dense_energy_cell" /> peut stocker 1,6 M d'AE ; elle sert quand vous voulez faire tourner un réseau sur de l'énergie stockée, ou
encaisser l'énorme appel de courant instantané des grosses installations de [stockage spatial](spatial-io.md).

La <ItemLink id="creative_energy_cell" /> est un objet créatif destiné aux tests, qui fournit de la PUISSANCE ILLIMITÉE ou quelque chose comme ça.
