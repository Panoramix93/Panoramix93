---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Importation, exportation et stockage
---

# Importation, exportation et stockage

**votre système ME et le monde**

Un concept important dans AE2 est l'idée de stockage du réseau. C'est l'endroit où le contenu d'un réseau est rangé,
généralement des [disques de stockage](../items-blocks-machines/storage_cells.md) ou l'inventaire auquel un <ItemLink id="storage_bus" />
est connecté. La plupart des [appareils](../ae2-mechanics/devices.md) AE2 interagissent avec lui d'une manière ou d'une autre.

Par exemple,

*   les <ItemLink id="import_bus" /> poussent des choses dans le stockage du réseau
*   les <ItemLink id="export_bus" /> tirent des choses du stockage du réseau
*   les <ItemLink id="interface" /> tirent du stockage du réseau et y poussent à la fois
*   les [terminaux](../items-blocks-machines/terminals.md) poussent vers le stockage du réseau et en tirent lorsque vous insérez ou retirez des objets, ou pour recharger les cases de fabrication
*   les <ItemLink id="storage_bus" /> ne poussent ni ne tirent vraiment du stockage : ils poussent vers l'inventaire connecté ou en tirent
    afin de l'utiliser comme stockage du réseau (ce sont donc en réalité les autres appareils qui poussent vers *eux* ou tirent d'*eux*)

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/import_export_storage.snbt" />

  <BoxAnnotation color="#dddddd" min="8 1 1" max="9 1.3 2">
        Les bus d'importation importent dans le stockage du réseau les choses contenues dans les inventaires qu'ils visent
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="8 2 1" max="9 3 1.3">
        Insérer quelque chose dans un terminal depuis votre inventaire compte comme une importation par le réseau
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="7 0 1" max="8 1 2">
        Les interfaces importent depuis leur inventaire interne si la case concernée n'est pas configurée pour stocker quelque chose, ou s'il y a plus
        d'objets dans cette case que la quantité configurée : on peut donc y pousser des choses pour les insérer dans le réseau
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="6 0 1" max="7 1 2">
        Les fournisseurs de pattern importent depuis leur case de retour interne : on peut donc y pousser des choses pour les insérer dans le réseau
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4 1 1" max="5 2 2">
        Les range-disques fournissent au réseau les disques insérés comme stockage
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
        Les bus de stockage utilisent comme stockage du réseau l'inventaire qu'ils visent
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 1 1" max="2 1.3 2">
        Les bus d'exportation exportent des choses du stockage du réseau vers les inventaires qu'ils visent
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="2 3 1.3">
        Retirer quelque chose d'un terminal compte comme une exportation par le réseau
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 1 1" max="1 2 2">
        Les interfaces exportent vers leur inventaire interne si la case concernée est configurée pour stocker quelque chose,
        on peut donc y prendre des choses pour les extraire du réseau
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Les actions et événements de poussée vers le stockage du réseau et de tirage depuis celui-ci sont importants à garder en tête lorsque vous concevez des installations
d'automatisation et de logistique.

## Priorité de stockage

Les priorités se règlent en cliquant sur la clé en haut à droite de certaines interfaces.
Les objets qui entrent dans le réseau se dirigent d'abord vers le stockage de plus haute priorité,
comme première destination ; si deux stockages ont la même priorité et que
l'un contient déjà l'objet, celui-ci sera préféré à tout
autre. Tout disque disposant d'une liste blanche est considéré comme contenant déjà l'objet
lorsqu'il se trouve dans le même groupe de priorité que d'autres stockages. Les objets retirés du stockage
sont pris dans le stockage de plus basse priorité. Ce système de priorité signifie qu'au fil des insertions et des retraits
dans le stockage du réseau, les stockages de haute priorité se remplissent et ceux de basse priorité se vident.
