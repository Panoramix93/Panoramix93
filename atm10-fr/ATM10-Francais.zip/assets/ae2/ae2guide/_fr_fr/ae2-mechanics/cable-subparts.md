---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Sous-éléments de câble
icon: fluix_glass_cable
---

# Les sous-éléments de câble

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/subparts_demonstration.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Dans AE2, certains [appareils](devices.md) et composants peuvent être posés sur un câble, dans le même bloc. C'est très pratique pour les montages compacts.
Un Shift + clic droit avec une <ItemLink id="certus_quartz_wrench" /> ou un <ItemLink id="network_tool" /> permet de détacher un seul
sous-élément (ou le câble) sans casser tout ce qui se trouve dans ce bloc.
