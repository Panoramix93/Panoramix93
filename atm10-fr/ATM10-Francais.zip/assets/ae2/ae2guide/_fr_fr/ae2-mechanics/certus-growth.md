---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Croissance du certus
  icon: quartz_cluster
---

# Croissance du certus

## En gros un simple copier-coller de la page de premiers pas

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/budding_certus_1.snbt" />
</GameScene>

Des bourgeons de quartz certus poussent sur les [blocs de certus bourgeonnant](../items-blocks-machines/budding_certus.md), un peu comme l'améthyste. Si vous cassez un bourgeon qui n'a pas fini
de pousser, il lâche une <ItemLink id="certus_quartz_dust" />, sans effet de Fortune. Si vous cassez un amas arrivé à maturité, il lâche quatre
<ItemLink id="certus_quartz_crystal" />, et Fortune augmente ce nombre.

Il existe 4 niveaux de blocs de certus bourgeonnant : parfait, imparfait, ébréché et endommagé, et vous les trouvez
d'abord dans les [météorites](../ae2-mechanics/meteorites.md).

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Chaque fois qu'un bourgeon passe au stade suivant, le bloc bourgeonnant a une chance de perdre un niveau, pour finir par devenir
un simple bloc de quartz certus. On peut les réparer (et créer de nouveaux blocs bourgeonnants) en jetant le bloc bourgeonnant (ou un
bloc de quartz certus) dans l'eau avec un ou plusieurs <ItemLink id="charged_certus_quartz_crystal" />.

<RecipeFor id="damaged_budding_quartz" />

Les blocs de certus bourgeonnant parfaits ne se dégradent pas et produisent du certus à l'infini. En revanche, ils ne peuvent pas être fabriqués ni déplacés
à la pioche, même avec Toucher de soie. (ils *peuvent* toutefois être déplacés avec le [stockage spatial](../ae2-mechanics/spatial-io.md))

Laissés à eux-mêmes, les bourgeons de quartz certus poussent très lentement. Heureusement, l'<ItemLink id="growth_accelerator" /> accélère
massivement ce processus lorsqu'il est placé contre le bloc bourgeonnant. Vous devriez en construire quelques-uns en priorité.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_certus_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Du fait d'interactions complexes, chaque face couverte d'un bloc bourgeonnant ralentit le taux de croissance cumulé de ce bloc,
ce qui finit par annuler le bénéfice d'accélérateurs supplémentaires. Les tests empiriques donnent ceci :

![Objets/min selon les ratios](../assets/diagrams/certus_farm_speed_chart_1.png)

![montages courants](../assets/diagrams/certus_farm_speed_chart_2.png)

Si vous n'avez pas assez de quartz pour fabriquer en plus un <ItemLink id="energy_acceptor" /> ou une <ItemLink id="vibration_chamber" />,
vous pouvez fabriquer une <ItemLink id="crank" /> et la fixer au bout de votre accélérateur.

La récolte automatique du certus est [décrite ici](../example-setups/simple-certus-farm.md).
