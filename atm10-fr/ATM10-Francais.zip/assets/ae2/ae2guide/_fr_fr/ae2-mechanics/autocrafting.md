---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Fabrication automatique
  icon: pattern_provider
---

# Fabrication automatique

### Le gros morceau

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

La fabrication automatique est l'une des fonctions principales d'AE2. Au lieu de devoir fabriquer à la main le bon nombre de chaque sous-ingrédient
et de vous échiner comme une sorte de *plébéien*, vous pouvez demander à votre système ME de le faire pour vous. Ou fabriquer automatiquement des objets et les exporter quelque part.
Ou encore maintenir automatiquement en stock certaines quantités d'objets grâce à un comportement émergent astucieux. Cela fonctionne aussi avec les fluides, et, si vous avez
certains add-ons ajoutant des types de matières d'autres mods, comme les gaz de Mekanism, avec ces matières également. C'est plutôt formidable.

Le sujet est assez complexe, alors accrochez-vous et allons-y.

Une installation de fabrication automatique se compose de 3 éléments :
- Ce qui envoie la demande de fabrication
- Le CPU de fabrication
- Le <ItemLink id="pattern_provider" />.

Voici ce qui se passe :

1.  Quelque chose crée une demande de fabrication. Ce peut être vous dans le terminal, en cliquant sur un objet fabricable automatiquement,
    ou bien un bus d'exportation ou une interface munis d'une carte de fabrication qui demandent un des objets qu'ils sont réglés pour exporter/maintenir en stock.

*   (**IMPORTANT :** utilisez la touche associée à « pick block » (en général le clic du milieu) pour demander la fabrication d'un objet que vous avez déjà en stock ; cela peut entrer en conflit avec les mods de tri d'inventaire),

2.  Le système ME calcule les ingrédients nécessaires et les étapes de fabrication préalables pour satisfaire la demande, puis les stocke dans le CPU de fabrication sélectionné

3.  Le <ItemLink id="pattern_provider" /> contenant le [modèle](../items-blocks-machines/patterns.md) correspondant pousse les ingrédients indiqués dans le modèle vers n'importe quel inventaire adjacent.
    Dans le cas d'une recette de table de fabrication (un « modèle de fabrication »), il s'agira d'un <ItemLink id="molecular_assembler" />.
    Dans le cas d'une recette hors table de fabrication (un « modèle de traitement »), il s'agira d'un autre bloc, d'une machine ou d'une installation élaborée pilotée par la redstone.

4.  Le résultat de la fabrication est renvoyé au système d'une manière ou d'une autre, que ce soit par un bus d'importation, une interface, ou en réinjectant le résultat dans un fournisseur de modèles.
    **Notez qu'un évènement « objet entrant dans le système » doit avoir lieu : vous ne pouvez pas simplement acheminer le résultat dans un coffre muni d'un <ItemLink id="storage_bus" />.**

5.  Si cette fabrication est un prérequis d'une autre fabrication de la demande, les objets sont stockés dans ce CPU de fabrication puis utilisés dans cette fabrication.

## Recettes récursives

<ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="4" />

Il y a une chose que l'algorithme de fabrication automatique *ne sait pas* gérer : les recettes récursives. Par exemple les recettes de duplication du type
« 1 poudre de redstone = 2 poudres de redstone », obtenues en jetant de la redstone dans un bassin de mana de Botania. Autre exemple : les modèles de forge
dans le Minecraft vanilla. Il existe toutefois [un moyen de gérer ces recettes.](../example-setups/recursive-crafting-setup.md)

# Modèles

<ItemImage id="crafting_pattern" scale="4" />

Les modèles sont créés dans un <ItemLink id="pattern_encoding_terminal" /> à partir de modèles vierges.

Il existe plusieurs types de modèles pour différents usages :

*   Les <ItemLink id="crafting_pattern" /> encodent des recettes réalisées dans une table de fabrication. Ils peuvent être placés directement dans un <ItemLink id="molecular_assembler" /> pour qu'il
    fabrique le résultat dès qu'on lui fournit les ingrédients, mais leur usage principal est dans un <ItemLink id="pattern_provider" /> accolé à un assembleur moléculaire.
    Dans ce cas, les fournisseurs de modèles ont un comportement particulier : ils envoient le modèle concerné en même temps que les ingrédients aux assembleurs adjacents.
    Comme les assembleurs éjectent automatiquement le résultat des fabrications vers les inventaires adjacents, un assembleur posé sur un fournisseur de modèles suffit à automatiser les modèles de fabrication.

***

*   Les <ItemLink id="smithing_table_pattern" /> ressemblent beaucoup aux modèles de fabrication, mais ils encodent des recettes de table de forge. Ils sont eux aussi automatisés par un fournisseur
    de modèles et un assembleur moléculaire, et fonctionnent exactement de la même façon. De fait, les modèles de fabrication, de forge et de tailleur de pierre peuvent
    être utilisés dans la même installation.

***

*   Les <ItemLink id="stonecutting_pattern" /> ressemblent beaucoup aux modèles de fabrication, mais ils encodent des recettes de tailleur de pierre. Ils sont eux aussi automatisés par un fournisseur
    de modèles et un assembleur moléculaire, et fonctionnent exactement de la même façon. De fait, les modèles de fabrication, de forge et de tailleur de pierre peuvent
    être utilisés dans la même installation.

***

*   Les <ItemLink id="processing_pattern" /> sont la source d'une grande partie de la souplesse de la fabrication automatique. C'est le type le plus général : ils disent simplement
    « si un fournisseur de modèles pousse ces ingrédients vers les inventaires adjacents, le système ME recevra ces objets à un moment donné dans un
    avenir proche ou lointain ». C'est avec eux que vous automatiserez la fabrication avec presque toutes les machines moddées, ou avec les fours et autres. Parce qu'ils sont
    si généraux et qu'ils ne se soucient pas de ce qui se passe entre l'envoi des ingrédients et la réception du résultat, vous pouvez faire des choses vraiment farfelues, comme injecter
    les ingrédients dans toute une chaîne de production complexe qui triera le tout, prendra d'autres ingrédients dans des
    fermes à production infinie, imprimera l'intégralité du scénario de Bee Movie : le système ME s'en moque, du moment qu'il obtient le résultat indiqué par le modèle. En fait,
    il ne se soucie même pas de savoir si les ingrédients ont le moindre rapport avec le résultat. Vous pourriez lui dire « 1 planche de cerisier = 1 étoile du Nether », faire tuer un wither
    par votre ferme à withers à la réception d'une planche de cerisier, et cela fonctionnerait.

Plusieurs <ItemLink id="pattern_provider" /> contenant des modèles identiques sont pris en charge et fonctionnent en parallèle. De plus, un modèle peut indiquer,
par exemple, 8 Pierres (cobblestone) = 8 Pierre au lieu de 1 Pierres = 1 Pierre, et le fournisseur de modèles insérera 8 blocs de Pierres dans
votre installation de cuisson à chaque opération au lieu d'un seul à la fois.

## La forme la plus générale de « modèle »

Il existe en réalité une forme de « modèle » encore plus « générale » que le modèle de traitement. Un <ItemLink id="level_emitter" /> muni d'une carte de fabrication peut être réglé
pour émettre un signal de redstone afin de fabriquer quelque chose. Ce « modèle » ne définit pas les ingrédients, et ne s'en préoccupe même pas.
Tout ce qu'il dit, c'est : « si vous émettez de la redstone depuis cet émetteur de niveau, le système ME recevra cet objet à un moment donné dans un
avenir proche ou lointain ». On s'en sert généralement pour activer et désactiver des fermes infinies qui ne nécessitent aucun ingrédient en entrée,
ou pour activer un système qui gère les recettes récursives (que la fabrication automatique standard ne sait pas comprendre), comme par exemple « 1 Pierres (cobblestone) = 2 Pierres »
si vous avez une machine qui duplique les Pierres.

# Le CPU de fabrication

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Les CPU de fabrication gèrent les demandes et les tâches de fabrication. Ils stockent les ingrédients intermédiaires pendant l'exécution des tâches
comportant plusieurs étapes, et déterminent la taille maximale des tâches ainsi que, dans une certaine mesure, leur vitesse d'exécution. Ce sont des multiblocs, et
ils doivent former des prismes rectangulaires comprenant au moins un stockage de fabrication.

Les CPU de fabrication sont constitués de :

*   (Obligatoire) [Stockages de fabrication](../items-blocks-machines/crafting_cpu_multiblock.md), disponibles dans toutes les tailles de cellules standard (1k, 4k, 16k, 64k, 256k). Ils stockent les ingrédients et
    les ingrédients intermédiaires impliqués dans une fabrication : il faut donc des stockages plus grands ou plus nombreux pour que le CPU puisse gérer des tâches
    comportant davantage d'ingrédients.
*   (Facultatif) Les <ItemLink id="crafting_accelerator" />, qui font envoyer plus souvent les lots d'ingrédients par les fournisseurs de modèles.
    Cela permet, par exemple, à un fournisseur de modèles entouré de 6 assembleurs moléculaires d'envoyer des ingrédients aux 6 à la fois (et donc de les utiliser tous) au lieu d'un seul.
*   (Facultatif) Les <ItemLink id="crafting_monitor" />, qui affichent la tâche en cours de traitement par le CPU. Ils peuvent être colorés à l'aide d'un <ItemLink id="color_applicator" />
*   (Facultatif) Les <ItemLink id="crafting_unit" />, qui servent simplement à combler l'espace pour donner au CPU la forme d'un prisme rectangulaire.

Chaque CPU de fabrication gère 1 demande ou tâche : donc, si vous voulez demander en même temps un processeur de calcul et 256 pierres lisses, il vous faut 2 multiblocs CPU.

Ils peuvent être réglés pour traiter les demandes des joueurs, celles de l'automatisation (bus d'exportation et interfaces), ou les deux.

# Fournisseurs de modèles

<Row>
<BlockImage id="pattern_provider" scale="4" />

<BlockImage id="pattern_provider" p:push_direction="up" scale="4" />

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

Les <ItemLink id="pattern_provider" /> sont le principal moyen par lequel votre système de fabrication automatique interagit avec le monde. Ils poussent les ingrédients de
leurs [modèles](../items-blocks-machines/patterns.md) vers les inventaires adjacents, et on peut y insérer des objets pour les faire entrer dans le réseau. Souvent,
on peut économiser un canal en renvoyant la sortie d'une machine dans un fournisseur de modèles proche (souvent celui qui a envoyé les ingrédients)
plutôt qu'en utilisant un <ItemLink id="import_bus" /> pour tirer la sortie de la machine vers le réseau.

À noter : comme ils poussent les ingrédients directement depuis le [stockage de fabrication](../items-blocks-machines/crafting_cpu_multiblock.md#crafting-storage) d'un CPU de fabrication, ils
ne contiennent jamais réellement les ingrédients dans leur inventaire : vous ne pouvez donc pas en extraire par tuyauterie. Vous devez faire pousser le fournisseur
vers un autre inventaire (comme un baril), puis tirer depuis celui-ci.

À noter également : le fournisseur doit pousser TOUS les ingrédients d'un coup, il ne peut pas envoyer de demi-lots. C'est une propriété utile
à exploiter.

Les fournisseurs de modèles ont une interaction particulière avec les interfaces placées sur des [sous-réseaux](../ae2-mechanics/subnetworks.md) : si l'interface n'est pas configurée (rien dans les emplacements de demande),
le fournisseur ignore complètement l'interface et pousse directement vers le [stockage](../ae2-mechanics/import-export-storage.md) de ce sous-réseau,
sans passer par l'interface et donc sans la remplir de lots de recette, et surtout sans insérer le lot suivant tant qu'il n'y a pas de place dans le stockage.

Plusieurs fournisseurs de modèles contenant des modèles identiques sont pris en charge et fonctionnent en parallèle.

Les fournisseurs de modèles tentent de répartir leurs lots à tour de rôle sur toutes leurs faces, utilisant ainsi en parallèle toutes les machines rattachées.

## Variantes

Les fournisseurs de modèles existent en 3 variantes : normale, directionnelle et plate. Cela détermine vers quels côtés précis ils poussent
les ingrédients, de quels côtés ils reçoivent des objets, et sur quels côtés ils fournissent une connexion réseau.

*   Les fournisseurs de modèles normaux poussent les ingrédients sur tous les côtés, reçoivent des entrées de tous les côtés et, comme la plupart des machines AE2, se comportent
    comme un câble en fournissant une connexion réseau sur tous les côtés.

*   Les fournisseurs de modèles directionnels s'obtiennent en utilisant une <ItemLink id="certus_quartz_wrench" /> sur un fournisseur de modèles normal pour changer sa
    direction. Ils ne poussent les ingrédients que sur le côté choisi, reçoivent des entrées de tous les côtés et, surtout, ne fournissent pas de connexion
    réseau sur le côté choisi. Cela leur permet de pousser vers des machines AE2 sans relier les réseaux, si vous voulez créer un sous-réseau.

*   Les fournisseurs de modèles plats sont une [sous-partie de câble](../ae2-mechanics/cable-subparts.md) : on peut donc en placer plusieurs sur le même câble, ce qui permet des installations compactes.
    Ils se comportent comme le côté choisi d'un fournisseur de modèles directionnel : ils fournissent les modèles, reçoivent les entrées et ne
    fournissent pas de connexion réseau sur leur face.

Les fournisseurs de modèles peuvent être convertis entre les versions normale et plate dans une grille de fabrication.

## Réglages

Les fournisseurs de modèles disposent de plusieurs modes :

*   Le **mode blocage** empêche le fournisseur d'envoyer un nouveau lot d'ingrédients s'il y a déjà
    des ingrédients dans la machine.
*   Le **verrouillage de la fabrication** peut bloquer le fournisseur selon diverses conditions de redstone, ou jusqu'à ce que le résultat de la
    fabrication précédente soit inséré dans ce fournisseur de modèles précis.
*   Le fournisseur peut être affiché ou masqué sur les <ItemLink id="pattern_access_terminal" />.

## Priorité

Les priorités se règlent en cliquant sur la clé en haut à droite de l'interface. S'il existe plusieurs [modèles](../items-blocks-machines/patterns.md)
pour le même objet, les modèles des fournisseurs de priorité plus élevée seront utilisés avant ceux des fournisseurs de priorité plus faible,
sauf si le réseau ne dispose pas des ingrédients du modèle le plus prioritaire.

# Assembleurs moléculaires

<BlockImage id="molecular_assembler" scale="4" />

Le <ItemLink id="molecular_assembler" /> prend les objets qu'on lui fournit, exécute l'opération définie par un <ItemLink id="pattern_provider" /> adjacent,
ou par le <ItemLink id="crafting_pattern" />, le <ItemLink id="smithing_table_pattern" /> ou le <ItemLink id="stonecutting_pattern" /> qui y est inséré,
puis pousse le résultat vers les inventaires adjacents.

Leur usage principal est d'être placés contre un <ItemLink id="pattern_provider" />. Dans ce cas, les fournisseurs de modèles ont un comportement particulier :
ils envoient les informations sur le modèle concerné en même temps que les ingrédients aux assembleurs adjacents. Comme les assembleurs éjectent automatiquement le résultat des
fabrications vers les inventaires adjacents (et donc dans les emplacements de retour du fournisseur de modèles), un assembleur posé sur un fournisseur de modèles
suffit à automatiser les modèles de fabrication.

<GameScene zoom="4" background="transparent">
<ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>
