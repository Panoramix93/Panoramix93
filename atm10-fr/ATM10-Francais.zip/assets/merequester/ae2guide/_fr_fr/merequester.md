---
navigation:
  title: Demandeur ME
  icon: requester
  position: 100
item_ids:
  - merequester:requester
  - merequester:requester_terminal
---

# Demandeur ME

<Row>
  <ItemImage id="requester" scale="3"/>
  <ItemImage id="requester_terminal" scale="3"/>
</Row>

Un mod complémentaire qui vous permet de maintenir un stock d'objets et de fluides dans votre [système ME](ae2:getting-started.md#your-very-first-me-system).
<br/>

## Premiers pas

Pour commencer, placez un <ItemLink id="requester"/> et raccordez-le à votre réseau. Veillez à le raccorder au même réseau que celui où se trouve votre
logique de [fabrication automatique](ae2:ae2-mechanics/autocrafting.md). Ce réseau doit héberger vos
[processeurs de fabrication](ae2:ae2-mechanics/autocrafting.md#the-crafting-cpu) et vos <ItemLink id="ae2:pattern_provider"/>.

<RecipeFor id="requester"/>

Pour que le <ItemLink id="requester"/> fonctionne, vous devez vous assurer que les objets ou fluides que vous souhaitez garder en stock disposent d'un modèle
et peuvent également être fabriqués si vous les demandez en tant que joueur. Il n'automatise que la demande elle-même. La fabrication est prise en charge par le
[système ME](ae2:getting-started.md#your-very-first-me-system).
<br/>

<FloatingImage src="assets/gui.png" align="right"/>

## Configuration

Lorsque vous ouvrez le <ItemLink id="requester"/> pour la première fois, vous voyez un aperçu des réglages de demande. Le nombre d'emplacements qu'un seul
bloc peut héberger est réglable dans la configuration. Chaque ligne de l'interface représente une demande distincte.
<br/>

### Interrupteur

La case à cocher de gauche active ou désactive la demande configurée sur cette ligne. Lorsqu'une demande est désactivée, aucune vérification n'est effectuée et le stock de votre
demande n'est pas maintenu.<br/>
Cela permet de désactiver temporairement une demande précise ou d'empêcher le <ItemLink id="requester"/> de lancer des tâches de fabrication pendant que
vous modifiez encore une ligne.
<br/>

### Quoi stocker

Dans la deuxième colonne, vous pouvez indiquer ce que vous souhaitez garder en stock. Ces emplacements sont fantômes et ne contiennent pas d'objets réels. Lorsque
vous faites glisser un objet vers l'emplacement, un clic droit règle la quantité sur 1 et un clic gauche reprend la quantité de la pile que vous faites glisser.
Lorsque vous faites glisser un seau contenant un fluide vers l'emplacement, un clic droit définit le fluide contenu et un clic gauche définit le seau lui-même.
Vous pouvez aussi Maj-cliquer sur des objets pour définir rapidement le type d'objet. Si vous n'avez pas l'objet voulu dans votre inventaire, vous pouvez également le glisser-
déposer depuis les visionneuses de recettes prises en charge par Applied Energistics.
<br/>

### Quantité à stocker

Le champ Quantité à stocker indique la quantité à maintenir en stock. Précisez d'abord ce qu'il faut stocker, puis saisissez la valeur souhaitée. Pour les demandes qui ne portent pas sur des objets,
le champ s'adapte au type. Par exemple, un `B` indique des seaux pour un fluide.<br/>
Lorsque le stock actuel descend sous la quantité indiquée, le <ItemLink id="requester"/> en demande davantage.
<br/>

### Taille de lot

Le champ de saisie suivant précise la taille de lot qui sera demandée dès que le stock actuel descend sous le seuil indiqué dans le
champ Quantité à stocker.<br/>
Cela permet de solliciter moins les [processeurs de fabrication](ae2:ae2-mechanics/autocrafting.md#the-crafting-cpu) et les machines utilisées dans la fabrication,
puisque la quantité totale sera demandée d'un coup plutôt qu'en autant de tâches individuelles.
<br/>

### Bouton de validation

Pour appliquer les modifications à la demande, saisissez les valeurs souhaitées dans les champs Quantité à stocker et Taille de lot, puis appuyez sur Entrée ou cliquez
sur le bouton de validation à droite de la ligne en cours. Cliquer sur une autre ligne réinitialise les valeurs à leur état précédent.
<br/>

### Barre d'état

La barre située sous les champs de saisie et le bouton de validation reflète l'état actuel de la demande.
<br clear="all" />
<br/>

## États

Les états suivants s'affichent dans la barre d'état de chaque demande.
<br/>

### Gris - Vide

La ligne actuelle est désactivée ou aucun élément à stocker n'a été précisé.
<br/>

### Vert - En attente

La quantité cible à stocker est déjà atteinte, ou il n'existe aucun modèle pour la demande configurée.
<br/>

### Rouge - Ingrédients manquants

Il manque au système les ingrédients nécessaires pour lancer la tâche en cours. Il reprendra dès que suffisamment d'ingrédients seront trouvés dans le
système.
<br/>

### Jaune - Fabrication

La demande souhaitée est en cours de fabrication. Le demandeur attend la fin de la tâche.<br/>
Pendant que cet état est actif, les réglages de la demande concernée dans le <ItemLink id="requester"/> sont verrouillés et ne peuvent pas être modifiés.
<br/>

### Violet - Exportation

Le <ItemLink id="requester"/> a reçu tous les résultats de la tâche en cours et tente de les exporter vers le système de stockage.<br/>
Cet état n'est généralement pas visible. S'il reste actif trop longtemps, cela signifie qu'il n'y a pas assez de place dans votre système de stockage.
<br/>

### Apparence du bloc

Si une demande dans un <ItemLink id="requester"/> présente un état autre qu'en attente ou vide, le bloc change d'apparence.

<Row>
  <Column>
    Inactif
    <BlockImage id="requester" scale="3" p:active="false"/>
  </Column>
  <Column>
    Actif
    <BlockImage id="requester" scale="3" p:active="true"/>
  </Column>
</Row>
<br/>

## Terminal

Le mod fournit également un nouveau terminal appelé <ItemLink id="requester_terminal"/>. Il vous permet d'accéder à tous les <ItemLink id="requester"/>
du même réseau depuis un point central.

Ce terminal offre les mêmes fonctions que le <ItemLink id="ae2:pattern_access_terminal"/> et permet de rechercher une demande précise.
Comme tous les <ItemLink id="requester"/> portent le même nom par défaut, toutes les demandes sont regroupées sous le
même en-tête. Si vous souhaitez un groupe distinct de <ItemLink id="requester"/> dans le <ItemLink id="requester_terminal"/>, vous pouvez les renommer sur
une enclume ou avec le <ItemLink id="ae2:name_press"/>.
