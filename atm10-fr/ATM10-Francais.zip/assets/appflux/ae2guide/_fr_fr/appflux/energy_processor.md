---
navigation:
  parent: appflux/appflux-index.md
  title: Processeur d'énergie
  icon: appflux:energy_processor
categories:
- flux materials
item_ids:
- appflux:energy_processor
- appflux:printed_energy_processor
- appflux:energy_processor_press
---

# Processeur d'énergie

<Row>
<ItemImage id="appflux:energy_processor" scale="4"></ItemImage>
<ItemImage id="appflux:energy_processor_press" scale="4"></ItemImage>
<ItemImage id="appflux:printed_energy_processor" scale="4"></ItemImage>
</Row>

Le Processeur d'énergie sert à gérer les flux d'énergie dans un système ME. Tous les appareils énergétiques ont besoin d'un processeur d'énergie pour acheminer l'énergie.
