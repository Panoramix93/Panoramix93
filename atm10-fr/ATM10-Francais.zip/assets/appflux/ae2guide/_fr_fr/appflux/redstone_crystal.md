---
navigation:
  parent: appflux/appflux-index.md
  title: Cristal de redstone
  icon: appflux:redstone_crystal
categories:
- flux materials
item_ids:
- appflux:redstone_crystal
- appflux:charged_redstone
- appflux:charged_redstone_block
---

# Cristal de redstone

<Row>
<ItemImage id="appflux:redstone_crystal" scale="4"></ItemImage>
<ItemImage id="appflux:charged_redstone" scale="4"></ItemImage>
</Row>
<Row>
<BlockImage id="appflux:charged_redstone_block" scale="4"></BlockImage>
</Row>

*« Pow ah !! »*

La redstone est un bon support pour stocker de l'énergie, mais elle est bien trop volatile pour être mise dans un disque.

Combiné avec du cristal de fluix et de la pierre lumineuse, le bloc de redstone se cristallise en cristaux de redstone. Ils peuvent stocker une grande quantité 
d'énergie tout en prenant très peu de place.
