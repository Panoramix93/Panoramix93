---
navigation:
  parent: appflux/appflux-index.md
  title: Poudre de diamant
  icon: appflux:diamond_dust
categories:
- flux materials
item_ids:
- appflux:diamond_dust
---

# Poudre de diamant

<Row>
<ItemImage id="appflux:diamond_dust" scale="4"></ItemImage>
</Row>

Du diamant sous forme de poudre.
