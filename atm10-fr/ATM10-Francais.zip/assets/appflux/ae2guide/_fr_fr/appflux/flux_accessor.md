---
navigation:
  parent: appflux/appflux-index.md
  title: Accesseur de flux
  icon: appflux:flux_accessor
categories:
- flux accessor
item_ids:
- appflux:flux_accessor
- appflux:part_flux_accessor
---

# Accesseur de flux

<Row>
<BlockImage id="appflux:flux_accessor" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/flux_accessor.snbt"></ImportStructure>
</GameScene>
</Row>

L'accesseur de flux peut faire entrer et sortir l'énergie stockée dans votre réseau ME. Par défaut, il n'a pas de limite d'E/S, ce qui peut être
modifié dans la configuration d'Appflux.

Il dispose d'un mode rapide et d'un mode normal. En mode rapide, il envoie de l'énergie à chaque tick, ce qui peut provoquer des ralentissements s'il est très sollicité.
En mode normal, l'énergie envoyée dépend de l'énergie déjà stockée dans la cible, ce qui évite les problèmes de ralentissement.

* Remarque : l'« énergie » dont il est question ici est le FE stocké dans vos [disques de stockage FE](./flux_cells.md), et non l'énergie des
[cellules énergétiques](ae2:items-blocks-machines/energy_cells.md).

