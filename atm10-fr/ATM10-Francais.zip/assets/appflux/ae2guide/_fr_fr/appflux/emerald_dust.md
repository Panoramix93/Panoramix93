---
navigation:
  parent: appflux/appflux-index.md
  title: Poudre d'émeraude
  icon: appflux:emerald_dust
categories:
- flux materials
item_ids:
- appflux:emerald_dust
---

# Poudre d'émeraude

<Row>
<ItemImage id="appflux:emerald_dust" scale="4"></ItemImage>
</Row>

De l'émeraude sous forme de poudre.
