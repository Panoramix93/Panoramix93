---
navigation:
    title: Applied Flux
    position: 70
---

# Stockez l'énergie dans des cellules !

Appflux vous permet de gérer votre système d'alimentation avec AE.

## Cellules de flux
<CategoryIndex category="flux cells"></CategoryIndex>

## Matériaux
<CategoryIndex category="flux materials"></CategoryIndex>

## Accesseur de flux
<CategoryIndex category="flux accessor"></CategoryIndex>

## Astuces
<CategoryIndex category="flux tricks"></CategoryIndex>
