---
navigation:
  parent: appflux/appflux-index.md
  title: Marquer le FE
categories:
- flux tricks
---

# Comment marquer le FE dans un emplacement de configuration

Vous voudrez peut-être faire sortir de l'énergie avec un <ItemLink id="ae2:export_bus"/>, et pour cela vous devez marquer le FE dans son emplacement de configuration.

Faites un clic droit sur l'emplacement avec un conteneur d'énergie pour y marquer le FE.

![FE_MARK](../pic/fe_mark.png)

