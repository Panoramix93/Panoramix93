---
navigation:
  parent: appflux/appflux-index.md
  title: Résine isolante
  icon: appflux:insulating_resin
categories:
- flux materials
item_ids:
- appflux:insulating_resin
- appflux:harden_insulating_resin
---

# Résine isolante

<Row>
<ItemImage id="appflux:insulating_resin" scale="4"></ItemImage>
<ItemImage id="appflux:harden_insulating_resin" scale="4"></ItemImage>
</Row>

La résine isolante empêche l'énergie stockée de fuir. C'est le matériau indispensable pour fabriquer un boîtier de stockage FE.
