---
navigation:
  parent: appflux/appflux-index.md
  title: Cellules de flux portables
  icon: appflux:fe_1k_portable_cell
categories:
- flux cells
item_ids:
- appflux:fe_1k_portable_cell
- appflux:fe_4k_portable_cell
- appflux:fe_16k_portable_cell
- appflux:fe_64k_portable_cell
- appflux:fe_256k_portable_cell
- appflux:fe_1m_portable_cell
- appflux:fe_4m_portable_cell
- appflux:fe_16m_portable_cell
- appflux:fe_64m_portable_cell
- appflux:fe_256m_portable_cell
---

# Cellules de flux portables

<Column>
  <Row>
    <ItemImage id="appflux:fe_1k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_4k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_16k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_64k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_256k_portable_cell" scale="4" />
  </Row>
  <Row>
    <ItemImage id="appflux:fe_1m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_4m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_16m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_64m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_256m_portable_cell" scale="4" />
  </Row>
</Column>

Les cellules FE portables n'ont qu'un quart de la capacité des [cellules FE](./flux_cells.md) normales.

En revanche, vous pouvez installer une <ItemLink id="appflux:induction_card"/> dans les cellules FE portables : elles rechargeront alors automatiquement les objets de votre inventaire.
