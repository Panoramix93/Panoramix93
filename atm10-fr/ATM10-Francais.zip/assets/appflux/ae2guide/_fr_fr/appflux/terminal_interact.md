---
navigation:
  parent: appflux/appflux-index.md
  title: Interactions avec les terminaux
categories:
- flux tricks
---

# Interactions avec les terminaux

Les terminaux affichent l'énergie stockée sous la forme de ce *fluide vert*.

![FE_GUI](../pic/fe_terminal.png)

Ce n'est pas un vrai fluide, et vous ne pouvez pas utiliser de seaux pour le remplir.

Vous pouvez utiliser un conteneur d'énergie, comme des batteries ou des outils électriques, pour y injecter ou en retirer de l'énergie.

![FE_GUI2](../pic/fe_terminal2.png)

