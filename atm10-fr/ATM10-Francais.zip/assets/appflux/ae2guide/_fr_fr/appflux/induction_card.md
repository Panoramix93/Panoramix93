---
navigation:
  parent: appflux/appflux-index.md
  title: Carte d'induction
  icon: appflux:induction_card
categories:
- flux accessor
item_ids:
- appflux:induction_card
---

# Carte d'induction

<Row>
<ItemImage id="appflux:induction_card" scale="4"></ItemImage>
</Row>

La carte d'induction permet de transformer un <ItemLink id="ae2:pattern_provider" /> ou une <ItemLink id="ae2:interface" /> en 
<ItemLink id="appflux:flux_accessor" />, ce qui leur permet de recevoir et de fournir de l'énergie.
