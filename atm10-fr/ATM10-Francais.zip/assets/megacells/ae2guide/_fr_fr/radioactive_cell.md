---
navigation:
  title: Cellule chimique radioactive (exclusive à AppMek)
  icon: radioactive_chemical_cell
  parent: index.md
  position: 050
categories:
  - megacells
item_ids:
  - radioactive_cell_component
  - radioactive_chemical_cell
---

# MEGA Cells : cellule chimique radioactive

Dans le cadre de son intégration élargie avec les autres add-ons, MEGA propose une seconde cellule spécialisée, réservée
aux joueurs qui utilisent aussi *Mekanism* et l'add-on ***Applied Mekanistics***. Si vous n'utilisez ni l'un ni l'autre
et que les recettes ci-dessous apparaissent en erreur, vous pouvez ignorer cette page sans crainte et faire comme si
cette cellule n'existait pas.

## Cellule chimique radioactive

<Row>
  <ItemImage id="radioactive_cell_component" scale="3" />
  <ItemImage id="radioactive_chemical_cell" scale="3" />
</Row>

La **cellule chimique radioactive MEGA**, comme son nom l'indique, vient compléter les disques de stockage classiques
proposés par *Applied Mekanistics* (et l'intégration que MEGA en fait) pour stocker les « chemicals » de *Mekanism*. En
temps normal, avec les cellules chimiques classiques, vous avez peut-être remarqué une restriction : elles ne stockent
aucun produit chimique *radioactif*, ce qui, dans Mekanism, concerne principalement les *déchets nucléaires*, le
*polonium* et le *plutonium*. La cellule radioactive, elle, ne stocke bien sûr *rien d'autre* que les produits chimiques
mentionnés.

<Row>
  <RecipeFor id="radioactive_cell_component" />
  <RecipeFor id="radioactive_chemical_cell" />
</Row>

La cellule radioactive n'est pas très différente du <ItemLink id="megacells:bulk_item_cell" /> en ce qu'elle ne peut
stocker qu'un seul type de produit chimique radioactif et qu'elle doit être partitionnée avant de fonctionner. Les
ressemblances entre les deux s'arrêtent cependant là : la cellule radioactive ne stocke qu'une quantité finie de ce
produit chimique, au maximum *256 [octets](ae2:ae2-mechanics/bytes-and-types.md)*. Cela représente néanmoins
l'équivalent de *2048 seaux*, soit le contenu de 4 barils de déchets nucléaires de ce produit chimique radioactif, dans
l'espace d'une seule cellule.

![Radioactive Cell with polonium](assets/diagrams/radioactive_cell.png)

Pour contenir et stocker des substances aussi instables, la cellule exige nettement plus d'énergie afin de les maintenir
(on ne sait trop comment !) dans un état relativement stable. Comparée à la consommation habituelle de 0,5 AE/tick du
<ItemLink id="ae2:item_storage_cell_1k" />, de 2,5 AE/t du <ItemLink id="ae2:item_storage_cell_256k" /> et de 5 AE/t du
<ItemLink id="megacells:item_storage_cell_256m" />, une seule cellule radioactive consomme la bagatelle de
**250 AE/tick** lorsqu'elle se trouve dans un coffre ME ou un range-disque ME connecté.

Enfin, pour encourager les joueurs de Mekanism à continuer de gérer correctement leurs déchets nucléaires comme prévu,
la cellule radioactive interdit toujours explicitement d'y stocker les *déchets nucléaires **usés***. *Par défaut*, vous
ne vous en tirerez pas si facilement pour garder vos centrales nucléaires sous contrôle. Pour les joueurs qui préfèrent
quand même la solution de facilité, ce comportement est néanmoins configurable. *Comment* le configurer est laissé en
exercice au lecteur.
