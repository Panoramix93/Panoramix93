---
navigation:
  title: Stockage MEGA
  icon: item_storage_cell_256m
  parent: index.md
  position: 010
categories:
  - megacells
item_ids:
  - cell_component_1m
  - cell_component_4m
  - cell_component_16m
  - cell_component_64m
  - cell_component_256m
  - mega_item_cell_housing
  - mega_fluid_cell_housing
  - mega_chemical_cell_housing
  - mega_source_cell_housing
  - mega_mana_cell_housing
  - mega_experience_cell_housing
  - item_storage_cell_1m
  - item_storage_cell_4m
  - item_storage_cell_16m
  - item_storage_cell_64m
  - item_storage_cell_256m
  - fluid_storage_cell_1m
  - fluid_storage_cell_4m
  - fluid_storage_cell_16m
  - fluid_storage_cell_64m
  - fluid_storage_cell_256m
  - chemical_storage_cell_1m
  - chemical_storage_cell_4m
  - chemical_storage_cell_16m
  - chemical_storage_cell_64m
  - chemical_storage_cell_256m
  - source_storage_cell_1m
  - source_storage_cell_4m
  - source_storage_cell_16m
  - source_storage_cell_64m
  - source_storage_cell_256m
  - mana_storage_cell_1m
  - mana_storage_cell_4m
  - mana_storage_cell_16m
  - mana_storage_cell_64m
  - mana_storage_cell_256m
  - experience_storage_cell_1m
  - experience_storage_cell_4m
  - experience_storage_cell_16m
  - experience_storage_cell_64m
  - experience_storage_cell_256m
  - portable_item_cell_1m
  - portable_item_cell_4m
  - portable_item_cell_16m
  - portable_item_cell_64m
  - portable_item_cell_256m
  - portable_fluid_cell_1m
  - portable_fluid_cell_4m
  - portable_fluid_cell_16m
  - portable_fluid_cell_64m
  - portable_fluid_cell_256m
  - portable_chemical_cell_1m
  - portable_chemical_cell_4m
  - portable_chemical_cell_16m
  - portable_chemical_cell_64m
  - portable_chemical_cell_256m
  - portable_source_cell_1m
  - portable_source_cell_4m
  - portable_source_cell_16m
  - portable_source_cell_64m
  - portable_source_cell_256m
  - portable_mana_cell_1m
  - portable_mana_cell_4m
  - portable_mana_cell_16m
  - portable_mana_cell_64m
  - portable_mana_cell_256m
  - portable_experience_cell_1m
  - portable_experience_cell_4m
  - portable_experience_cell_16m
  - portable_experience_cell_64m
  - portable_experience_cell_256m
  - sky_bronze_ingot
  - sky_bronze_block
  - sky_osmium_ingot
  - sky_osmium_block
---

# MEGA Cells : stockage

<GameScene zoom="8" background="transparent">
  <ImportStructure src="assets/assemblies/drive_cells.snbt" />
  <IsometricCamera yaw="195" pitch="10" />
</GameScene>

## [Disques de stockage](ae2:items-blocks-machines/storage_cells.md) MEGA

<Row>
  <ItemImage id="mega_item_cell_housing" scale="4" />
  <ItemImage id="item_storage_cell_1m" scale="4" />
  <ItemImage id="item_storage_cell_4m" scale="4" />
  <ItemImage id="item_storage_cell_16m" scale="4" />
  <ItemImage id="item_storage_cell_64m" scale="4" />
  <ItemImage id="item_storage_cell_256m" scale="4" />
</Row>

Comme indiqué plus haut, le <ItemLink id="megacells:accumulation_processor" /> constitue la première étape vers la mise en place
de toute infrastructure MEGA, et cela commence par ses propres paliers supérieurs de disques de stockage. Avec ce
processeur, un <ItemLink id="ae2:cell_component_256k" /> peut aller *encore bien plus loin*, de **1M** (équivalent à
« 1024k ») jusqu'au palier M le plus élevé, **256M** — soit une capacité plus de *mille* fois supérieure à celle du 256k.

<RecipeFor id="cell_component_1m" />
<RecipeFor id="cell_component_4m" />
<RecipeFor id="cell_component_16m" />
<RecipeFor id="cell_component_64m" />
<RecipeFor id="cell_component_256m" />

Bien sûr, un stockage plus performant exige un boîtier plus performant, et c'est là qu'intervient un peu plus de Sky Steel
pour fabriquer un boîtier de cellule à objets destiné à vos nouveaux composants de palier M.

<Row>
  <RecipeFor id="mega_item_cell_housing" />
  <Recipe id="cells/standard/item_storage_cell_1m" />
  <Recipe id="cells/standard/item_storage_cell_1m_with_housing" />
</Row>

Pour les fluides et tout le reste, il existe également des boîtiers dédiés. Il se trouve que la Sky Stone est suffisamment puissante
pour s'allier à d'autres métaux et former ainsi les cellules appropriées : avec du cuivre, par exemple, pour fabriquer des boîtiers de cellule à fluides
en **Sky Bronze**. Même en dehors de ce guide, tout ce que vous pouvez imaginer est peut-être pris en charge par MEGA avec une cellule dédiée
et son propre type de boîtier.

<Row>
  <ItemImage id="sky_bronze_ingot" scale="4" />
  <ItemImage id="mega_fluid_cell_housing" scale="4" />
  <ItemImage id="fluid_storage_cell_1m" scale="4" />
  <ItemImage id="fluid_storage_cell_4m" scale="4" />
  <ItemImage id="fluid_storage_cell_16m" scale="4" />
  <ItemImage id="fluid_storage_cell_64m" scale="4" />
  <ItemImage id="fluid_storage_cell_256m" scale="4" />
</Row>

<Row>
  <Recipe id="transform/sky_bronze_ingot" />
  <RecipeFor id="mega_fluid_cell_housing" />
</Row>

## [Cellules portables](ae2:items-blocks-machines/storage_cells.md#portable-item-storage) MEGA

MEGA propose aussi des versions portables de toutes ses cellules, comme le fait AE2 lui-même, mais la capacité accrue de ces
cellules demande nettement plus d'énergie. Notez donc qu'elles se fabriquent avec une
<ItemLink id="ae2:dense_energy_cell" /> et non une <ItemLink id="ae2:energy_cell" /> ordinaire.

Si ces cellules portables acceptent aussi toute la gamme d'[améliorations](ae2:items-blocks-machines/upgrade_cards.md) que
les cellules portables ME classiques prennent en charge, leur batterie plus grande et leur appétit général en énergie font que la
<ItemLink id="ae2:energy_card" /> ordinaire n'est *pas tout à fait* assez puissante pour elles. Pour cela, seule la
<ItemLink id="megacells:greater_energy_card" /> fera l'affaire.

<Row>
  <RecipeFor id="portable_item_cell_1m" />
</Row>
