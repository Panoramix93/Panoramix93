---
navigation:
  title: Disque d'objets en vrac
  icon: bulk_item_cell
  parent: index.md
  position: 040
categories:
  - megacells
item_ids:
  - bulk_item_cell
  - bulk_cell_component
  - compression_card
  - decompression_module
---

# MEGA Cells : le Disque d'objets en vrac

Nous passons maintenant au premier des disques de stockage *spécialisés* propres à MEGA. C'est là que les choses deviennent intéressantes.

## Disque d'objets en vrac

<Row>
  <ItemImage id="bulk_cell_component" scale="3" />
  <ItemImage id="bulk_item_cell" scale="3" />
</Row>

Le **Disque d'objets en vrac MEGA** est, à bien des égards, une sorte d'antithèse du
[disque de stockage classique](ae2:items-blocks-machines/storage_cells.md).

Alors qu'un disque standard peut généralement contenir jusqu'à 63 types d'objets différents, le Disque en vrac ne peut
stocker qu'un seul type en son sein. En soi, cela rendrait le disque plutôt inutile, mais le Disque en vrac possède dès
le départ un avantage déterminant : contrairement à la quantité finie de chaque type d'objet sur un disque standard, un
Disque en vrac est capable de stocker une quantité ***infinie*** de ce type d'objet unique. Et je parle bien d'*infini*,
au moins d'un point de vue pratique. *(voyez la section « Détails techniques » un peu plus bas si vous êtes curieux)*

Il faut aussi noter que le Disque en vrac n'est pas fabricable avec l'un des boîtiers de disque existants proposés par
AE2 ou MEGA : il utilise son propre boîtier dédié en netherite, toujours fabriqué de zéro en même temps que son composant
dédié. Pour cette raison, le Disque en vrac ne peut pas non plus être démonté pour récupérer son composant et son
boîtier — même s'il n'y aurait de toute façon pas grand intérêt à le faire.

<Row>
  <RecipeFor id="bulk_cell_component" />
  <RecipeFor id="bulk_item_cell" />
</Row>

Un Disque en vrac fraîchement fabriqué ne peut pas encore fonctionner : il doit d'abord être *partitionné* (filtré) pour
désigner l'objet qu'il stockera. Cela se fait à l'aide d'un <ItemLink id="ae2:cell_workbench" /> ou de notre pratique
<ItemLink id="portable_cell_workbench" />. Une fois cette opération effectuée, le disque commence à absorber l'objet
correspondant, se donnant même la priorité comme premier et probablement seul endroit où cet objet sera envoyé dès
l'instant où son filtre est défini.

![Disque en vrac vide](assets/diagrams/bulk_cell_empty.png)
![Disque en vrac partitionné](assets/diagrams/bulk_cell_partitioned.png)
![Disque en vrac avec du contenu](assets/diagrams/bulk_cell_with_contents.png)

Dès lors que le disque a commencé à absorber et à stocker son type d'objet, et tant que le filtre reste identique à
l'objet déjà contenu, il continuera de fonctionner et autorisera aussi bien l'insertion que l'extraction, exactement
comme un disque ordinaire. Si ce filtre est accidentellement effacé ou remplacé, en revanche, le disque passera en erreur
et ne pourra plus accepter de nouveaux objets. Il permettra toutefois l'extraction de son contenu existant en cas
d'urgence et pour permettre une récupération, et dès que le filtre d'origine aura été remis en place ou que le disque
aura été vidé (avec un nouveau filtre non vide), il recommencera à fonctionner normalement.

![Filtre de Disque en vrac non concordant (vide)](assets/diagrams/bulk_cell_mismatch_1.png)
![Filtre de Disque en vrac non concordant (autre objet)](assets/diagrams/bulk_cell_mismatch_2.png)

### Détails techniques à propos de la capacité :

On imagine souvent qu'une « capacité infinie » dans un mod Minecraft correspond simplement à la valeur maximale possible
d'un type de donnée numérique, comme la limite en Java d'un « int » (environ 2,14 milliards), d'un « long » (environ
9,2 *quintillions*, soit 9,2 \* 10^**18**) ou même d'un « double » (qui atteint déjà *308* ordres de grandeur, bien qu'il
ne conviendrait pas du tout ici pour manipuler des quantités entières).

Le Disque en vrac laisse tous ces types primitifs de côté : il est conçu de manière à contenir n'importe quelle quantité
arbitrairement grande qu'un utilisateur pourrait raisonnablement concevoir. De fait, même si un réseau ME donné ne pourra
jamais gérer et afficher plus des 9,2 quintillions mentionnés plus haut pour un type d'objet stocké, le Disque en vrac est
capable en interne de dépasser cette limite, et peut au minimum laisser entendre qu'il l'a fait.

![Nombre d'objets du Disque en vrac à (Long.MAX_VALUE - 1)](assets/diagrams/bulk_cell_max_count_1.png)
![Nombre d'objets du Disque en vrac affiché au-delà de Long.MAX_VALUE](assets/diagrams/bulk_cell_max_count_2.png)

## Compression en vrac

<Row>
  <ItemImage id="compression_card" scale="3" />
</Row>

Jusqu'ici, nous avons bien couvert le fonctionnement d'un disque en vrac en tant que puits sans fond pour n'importe quel
type d'objet. Cependant, la plupart des joueurs savent bien que certains types d'objets — notamment les ressources comme
les *lingots de métal* — doivent être traités un peu différemment pour le stockage. Très souvent, ces ressources comme les
lingots prennent plusieurs formes selon qu'il s'agit de stockage ou de fabrication : leur équivalent « bloc », plus gros,
pour le premier afin de réduire la place occupée, et leur forme « pépite », plus petite, pour la seconde. Si ces formes
gagnent généralement à être gérées conjointement avec le lingot correspondant, un Disque en vrac, dans sa version de base,
ne répondrait pas facilement à cette attente.

C'est là qu'intervient le mécanisme de ***Compression en vrac***, grâce à la **Carte de compression**, une
[carte d'amélioration](ae2:items-blocks-machines/upgrade_cards.md) unique réservée au Disque en vrac à cette fin.

<RecipeFor id="compression_card" />

Avec la *Compression* activée par cette carte, un Disque en vrac peut être rendu conscient de ces formes dérivées de la
ressource suivie, afin d'accepter également ces variantes et de les « compresser » automatiquement vers la variante
immédiatement supérieure au moment où elles entrent. Cette compression automatique fonctionne selon les recettes de
fabrication associées à ces variantes : si l'une de ces recettes transforme par exemple un (1) lingot de métal en neuf (9)
pépites de ce métal et qu'une autre recette retransforme ces neuf pépites en le lingot d'origine, un Disque en vrac
configuré pour stocker ce métal pourra accepter aussi bien la forme lingot que la forme pépite de ce métal, en convertissant
à la volée chaque groupe de 9 pépites insérées en un lingot supplémentaire.

De plus, cette compression automatique s'étend à *toutes* les variantes supérieures, comme les blocs de métal et même les
versions de ces blocs encore plus fortement « compressées » fournies par certains mods, le tout géré comme une longue
« chaîne » de variantes, de la plus petite à la plus grande.

![Disque en vrac avec compression activée](assets/diagrams/bulk_cell_compressed_1.png)

![Contenu d'un disque en vrac avec compression](assets/diagrams/bulk_cell_compressed_2.png)
![Contenu d'un disque en vrac avec compression (+ AllTheCompressed)](assets/diagrams/bulk_cell_compressed_3.png)

Pour que ce mécanisme fonctionne, un Disque en vrac ne suit en interne sa « quantité » réelle qu'en nombre de la plus
petite « unité » d'objet vers laquelle la ressource peut être décomposée — généralement une pépite de métal, un fragment de
gemme, une poudre ou un équivalent. Le long de la chaîne évoquée plus haut, un Disque en vrac avec ce mécanisme activé
acceptera volontiers toutes ces variantes, supérieures comme inférieures, les convertira en un certain nombre d'« unités »
le cas échéant, et permettra même d'*extraire* n'importe laquelle d'entre elles par des moyens automatisés — comme le
<ItemLink id="ae2:import_bus" /> et le <ItemLink id="ae2:export_bus" /> — ou même depuis un
[terminal](ae2:items-blocks-machines/terminals.md) (en *Maj*-cliquant pour extraire).

Lorsqu'un mod ajoute des versions « compressées » en blocs bien plus poussées d'une ressource, il peut être souhaitable de
limiter jusqu'où cette ressource peut monter avec la compression automatique, afin de suivre plus facilement la quantité de
cette ressource sous une forme précise, par exemple pour observer le débit de cette ressource sous forme de lingots. À cette
fin, un Disque en vrac avec Compression activée et encore placé dans un Établi de cellules permet de faire défiler son
« **seuil** de compression », qui détermine la variante la plus élevée que le disque peut accumuler en stockage et à laquelle
la compression automatique doit s'arrêter. Un clic gauche sur ce bouton fait descendre le seuil vers la plus petite unité,
tandis qu'un clic droit remonte vers des variantes de plus en plus compressées.

![Seuil par défaut du Disque en vrac](assets/diagrams/bulk_cell_cutoff_1.png)
![Seuil abaissé du Disque en vrac](assets/diagrams/bulk_cell_cutoff_2.png)

![Contenu d'un disque en vrac avec seuil](assets/diagrams/bulk_cell_cutoff_3.png)

Lorsque la Compression est activée sur un disque, le comportement en cas de « filtre non concordant » devient un peu plus
souple : le disque « se souvient » en pratique de la chaîne avec laquelle il doit travailler, d'après l'objet qu'on lui a
déjà fait stocker, et si son filtre est retiré accidentellement, il peut être remplacé par n'importe laquelle des variantes
associées plutôt que par la variante précise utilisée auparavant comme filtre. En outre, à des fins de correction d'erreurs,
si des recettes de fabrication pour une variante plus petite que l'objet configuré sur le disque sont ajoutées, supprimées ou
remplacées, le « facteur d'unité » actuel — c'est-à-dire le nombre d'« unités » qui tiennent au total dans une instance de la
« variante » configurée — est également enregistré et suivi, et mis à jour en conséquence lorsque la chaîne globale de ces
variantes subit un tel changement.

En dernier recours, si dans le pire des cas un disque en vrac est totalement bloqué quel que soit le filtre (ré)appliqué et
passe dans le mode de « récupération » évoqué plus haut, les éventuelles traces de variantes plus petites pourront être
récupérées en même temps que l'objet de base pour lequel le disque avait été partitionné à l'origine.

## Module de décompression

<GameScene zoom="8" background="transparent">
  <ImportStructure src="assets/assemblies/decompression_module.snbt" />
  <IsometricCamera yaw="195" pitch="10" />
</GameScene>

Jusqu'ici tout va bien. Nous savons qu'avec la Compression activée, un Disque en vrac travaille sans problème avec les
variantes correspondantes lorsqu'elles sont insérées ou extraites, que ce soit par un joueur ou par des appareils comme le
<ItemLink id="ae2:import_bus" /> et le <ItemLink id="ae2:export_bus" />. Et qu'en est-il de la fabrication automatique ?

C'est un peu plus compliqué. Dans AE2, le système de [fabrication automatique](ae2:ae2-mechanics/autocrafting.md) repose sur
le principe « ce que vous voyez est ce que vous avez ». Si le système de stockage ne signale par exemple que 5 lingots de fer,
le système de fabrication supposera que, en l'absence d'un [modèle](ae2:ae2-mechanics/autocrafting.md#patterns) lui indiquant
comment produire d'autres lingots de fer, il ne disposera que de ces 5 lingots pour une tâche donnée et ne pourra pas la mener
à bien s'il en faut davantage. Le problème est donc que, avec la Compression configurée sur un Disque en vrac qui se trouve
stocker des lingots de fer, le système de stockage pourrait très bien ne jamais signaler plus de 8 lingots (généralement) à un
instant donné si le disque est réglé sur un seuil élevé, laissant le système de fabrication incapable de traiter une tâche qui
nécessiterait finalement plus de lingots de fer pour accomplir une étape précédente.

La solution à ce problème prend la forme du **Module de décompression MEGA**, un élément de câble relativement sobre qui sert
presque d'extension au système et aux installations de fabrication automatique d'un réseau ordinaire.

<RecipeFor id="decompression_module" />

Lorsqu'un Module de décompression est placé n'importe où sur le réseau, il analyse en continu le réseau à la recherche de
Disques en vrac connectés ayant la Compression activée, et génère automatiquement un ensemble de « faux modèles » spécialisés
pour chacun de ces disques, couvrant tous les objets de la chaîne de variantes correspondant à ce disque. Ces modèles sont
ensuite gérés entièrement en interne, sans qu'aucune installation dédiée de <ItemLink id="ae2:pattern_provider" /> ou de
<ItemLink id="ae2:molecular_assembler" /> soit nécessaire, ce qui permet au système de fabrication de continuer à fonctionner
normalement en « fabriquant » davantage d'un objet qui est techniquement déjà stocké.

![Modèles de décompression](assets/diagrams/bulk_cell_decompression.png)

Ces modèles réagissent au seuil défini sur chaque Disque en vrac : les modèles générés pour les variantes plus petites que
l'objet seuil prennent la variante supérieure précédente pour la fabriquer *vers le bas* en plusieurs exemplaires de ces
variantes plus petites, tandis que les modèles générés pour les variantes plus grandes prennent plusieurs exemplaires de la
variante plus petite précédente pour la fabriquer vers le haut. Quelle que soit la direction prise par ces modèles, chaque
variante de part et d'autre du seuil reste automatiquement prise en compte au cas où une tâche de fabrication plus importante
en aurait besoin.

Le module permet également de définir une [priorité](ae2:ae2-mechanics/autocrafting.md#priority) « globale » pour tous ces
modèles, relativement à toute infrastructure de fabrication ordinaire comme des Fournisseurs de modèles disposant de leurs
propres modèles pour une variante donnée, en faisant un clic droit sur le module pour ouvrir le menu de priorité.

Le Module de décompression est typiquement un appareil « on l'installe et on l'oublie », et il ne vous faut en général qu'un
seul module sur un réseau donné pour activer toutes ses fonctions de fabrication automatique. ***GARDEZ TOUTEFOIS EN TÊTE***
que le module ne fonctionne qu'au sein d'un même réseau et ne peut suivre que les disques raccordés à des Coffres ME et des
Range-disques ME situés sur le même réseau principal que lui. Il ***NE FONCTIONNERA PAS*** à travers les
[sous-réseaux](ae2:ae2-mechanics/subnetworks.md), par exemple, donc veillez à ce que votre stockage en vrac reste centralisé
dans votre réseau principal pour que le module puisse tout reconnaître.
