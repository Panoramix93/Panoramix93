---
navigation:
  title: "Add-on : MEGA Cells"
  position: 80
item_ids:
  - accumulation_processor
  - accumulation_processor_press
  - printed_accumulation_processor
  - sky_steel_ingot
  - sky_steel_block
---

# MEGA Cells

![Logo de MEGA Cells](assets/logo.png)

## Introduction

**MEGA Cells** est un add-on pour Applied Energistics 2 qui apporte des paliers de stockage supérieurs, d'une capacité allant de **1M**
jusqu'à **256M**, tout en proposant quelques fonctionnalités sur mesure comme des disques de stockage plus spécialisés et des outils
complémentaires associés.

## Pour commencer

<Row>
  <ItemImage id="sky_steel_ingot" scale="4" />
  <ItemImage id="accumulation_processor" scale="4" />
</Row>

Pour atteindre de nouveaux sommets en matière de stockage, il faut de nouveaux matériaux. La ressource la plus importante à rassembler pour
préparer la mise en place d'une infrastructure MEGA, c'est une bonne quantité de <ItemLink id="ae2:sky_stone_block" />, car il faudra la
transformer en lingots d'alliage de **Sky Steel** avec du fer et un
<ItemLink id="ae2:charged_certus_quartz_crystal" />. L'eau ne suffira cependant pas pour ce travail du métal : il vous faudra un fluide bien
plus chaud pour les faire fondre et les transformer.

<Row>
  <Recipe id="transform/sky_steel_ingot" />
</Row>

Une fois que vous avez du Sky Steel, vous pouvez l'utiliser pour assembler un tout nouveau type de processeur, le **processeur
d'accumulation**. Ce processeur constitue la « colonne vertébrale » caractéristique de presque tous les appareils MEGA, qu'il s'agisse des
cellules classiques à grande capacité ou de n'importe quel autre outil spécialisé.

<Row>
  <RecipeFor id="accumulation_processor_press" />
  <RecipeFor id="printed_accumulation_processor" />
  <RecipeFor id="accumulation_processor" />
</Row>

À partir de là, vous êtes prêt à aller plus loin avec l'offre de « *MEGA Corp.* » et à libérer tout le potentiel
de votre stockage et de votre infrastructure ME.

## Pour aller plus loin

<SubPages />
