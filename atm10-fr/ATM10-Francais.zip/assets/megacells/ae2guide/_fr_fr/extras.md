---
navigation:
  title: Extras
  icon: mega_interface
  parent: index.md
  position: 060
categories:
  - megacells
item_ids:
  - mega_interface
  - cell_dock
  - portable_cell_workbench
---

# MEGA Cells : Extras

Le principe central de l'add-on étant désormais traité, nous concluons avec quelques-unes des plus petites fonctionnalités et ajouts
supplémentaires fournis par MEGA, par souci d'exhaustivité et pour un peu plus d'expérimentation.

## Interface MEGA

<Row>
  <BlockImage id="mega_interface" scale="4" />
  <GameScene zoom="4" background="transparent">
    <ImportStructure src="assets/assemblies/cable_mega_interface.snbt" />
  </GameScene>
</Row>

En complément du <ItemLink id="megacells:mega_pattern_provider" />, l'**Interface MEGA** sert de
version à double capacité de l'<ItemLink id="ae2:interface" />. Deux fois plus d'emplacements, deux fois plus d'E/S et de débit, et deux fois plus de
stock à maintenir.

<RecipeFor id="mega_interface" />
<RecipeFor id="cable_mega_interface" />

## Établi de cellules portatif

<ItemImage id="portable_cell_workbench" scale="4" />

Un peu en décalage avec le reste de l'add-on, l'**Établi de cellules portatif** est une version... *plus petite* de
l'<ItemLink id="ae2:cell_workbench" />. Suffisamment petite, en fait, pour tenir dans la paume de votre main, tout en restant
capable de configurer n'importe quel disque de stockage comme à l'accoutumée.

On ne peut que se demander comment un établi entier a bien pu tenir là-dedans.

<RecipeFor id="portable_cell_workbench" />

## Station d'accueil de disque

<GameScene zoom="8" background="transparent">
  <ImportStructure src="assets/assemblies/cell_dock.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Enfin, nous avons encore autre chose qui est une fois de plus plus petit que plus grand, ce qui explique pourquoi l'appeler un objet
« MEGA » paraissait plus déplacé qu'autre chose.

La **Station d'accueil de disque ME** est, à certains égards, comme une version plus compacte du <ItemLink id="ae2:chest" />, capable de contenir
en son sein un disque de stockage à la fois. Même s'il lui manque certaines des fonctionnalités supplémentaires du Coffre ME — à savoir son
terminal intégré — elle constitue tout de même un excellent fournisseur de stockage compact. En particulier, comme elle se présente sous la forme d'un
[élément de câble](ae2:ae2-mechanics/cable-subparts.md) « plat », un seul câble peut accueillir plusieurs Stations d'accueil de disque dans le même
espace d'un bloc. On lui trouvera peut-être une utilité dans le cas d'un sous-réseau compact nécessitant une sorte de stockage
tampon temporaire.

<RecipeFor id="cell_dock" />

## « Couleurs de disques classiques »

En guise de clin d'œil visuel optionnel, MEGA fournit le pack de ressources intégré suivant, que l'utilisateur peut choisir d'activer.

![Pack de ressources Couleurs de disques classiques](assets/diagrams/cell_colours_pack.png)

Dans les versions d'AE2 et de ses add-ons antérieures à Minecraft 1.21, les anciennes textures de chaque série de disques de stockage suivaient
un code couleur à 5 niveaux, partant d'un brun rougeâtre pour les disques 1k et passant par le jaune, le vert et le bleu jusqu'à
une teinte finale violet clair/lavande pour le 256k. MEGA suivait également cette tendance avec ses propres paliers de disques, en partant d'un rouge
profond au 1M et en terminant par un violet plus foncé au 256M.

![Anciennes textures des disques](assets/diagrams/cell_colours_old.png)

Avec la refonte plus large des textures introduite dans AE2 après la 1.20.x, les disques de stockage ont aussi été adaptés pour suivre une palette
de couleurs un peu plus large, les disques de stockage de base d'AE2 suivant un dégradé du bleu au vert au fil de leur progression de paliers et
MEGA ayant l'intention de poursuivre la progression du jaune au rouge puis au rose. Même si c'est également très réussi, il ne semblait
pas inutile d'inclure aussi l'option de l'ancien système de couleurs pour ceux qui l'auraient préféré à
l'actuel.

![Couleurs des disques AE2](assets/diagrams/cell_colours_ae2.png)
![Couleurs des disques MEGA](assets/diagrams/cell_colours_mega.png)
