---
navigation:
  title: Fabrication automatique MEGA
  icon: 256m_crafting_storage
  parent: index.md
  position: 020
categories:
  - megacells
item_ids:
  - mega_crafting_unit
  - 1m_crafting_storage
  - 4m_crafting_storage
  - 16m_crafting_storage
  - 64m_crafting_storage
  - 256m_crafting_storage
  - mega_crafting_accelerator
  - mega_crafting_monitor
  - mega_pattern_provider
  - cable_mega_pattern_provider
---

# MEGA Cells : fabrication automatique

<GameScene zoom="6" background="transparent">
  <ImportStructure src="assets/assemblies/crafting_cpu.snbt" />
  <IsometricCamera yaw="195" pitch="10" />
</GameScene>

## [CPU de fabrication](ae2:items-blocks-machines/crafting_cpu_multiblock.md) MEGA

<Row>
  <BlockImage id="mega_crafting_unit" scale="4" />
  <BlockImage id="1m_crafting_storage" scale="4" />
  <BlockImage id="4m_crafting_storage" scale="4" />
  <BlockImage id="16m_crafting_storage" scale="4" />
  <BlockImage id="64m_crafting_storage" scale="4" />
  <BlockImage id="256m_crafting_storage" scale="4" />
</Row>

Comme pour les disques de stockage, MEGA propose aussi ses paliers de stockage supérieurs pour les CPU de fabrication. Même s'ils exigent
eux aussi leur propre version dédiée de l'<ItemLink id="ae2:crafting_unit" /> pour encaisser leur puissance accrue, ils
viendront facilement à bout des plus grosses tâches de fabrication grâce à leur mémoire plus importante, tout en ayant *une sacrée classe* en
noir.

<RecipeFor id="mega_crafting_unit" />
<RecipeFor id="1m_crafting_storage" />
<RecipeFor id="4m_crafting_storage" />
<RecipeFor id="16m_crafting_storage" />
<RecipeFor id="64m_crafting_storage" />
<RecipeFor id="256m_crafting_storage" />

En bonus, MEGA fournit également son propre équivalent de l'<ItemLink id="ae2:crafting_accelerator" />, avec cette fois
l'avantage d'apporter non pas un, mais *QUATRE* fils de coprocessing dans l'espace de chaque bloc de coprocesseur ajouté.

<BlockImage id="mega_crafting_accelerator" scale="4" />
<RecipeFor id="mega_crafting_accelerator" />

Et, histoire d'avoir la panoplie complète, il existe aussi un équivalent MEGA du <ItemLink id="ae2:crafting_monitor" />.
Celui-ci ne fonctionne en réalité pas différemment du moniteur classique, mais il complète
les unités mentionnées plus haut pour les joueurs qui souhaitent une certaine cohérence esthétique et conserver le même aspect sombre et
élégant sur l'ensemble de leur multibloc CPU.

<BlockImage id="mega_crafting_monitor" scale="4" />
<RecipeFor id="mega_crafting_monitor" />

## Fournisseur de modèles MEGA

<Row>
  <BlockImage id="mega_pattern_provider" scale="4" />
  <GameScene zoom="4" background="transparent">
    <ImportStructure src="assets/assemblies/cable_mega_pattern_provider.snbt" />
  </GameScene>
</Row>

Pendant du <ItemLink id="ae2:pattern_provider" />, le **fournisseur de modèles MEGA** poursuit la
tradition des variantes agrandies des appareils AE2 correspondants en doublant la capacité en modèles, ce qui permet d'en
contenir et d'en gérer 18 au total. Cela se paie toutefois par le fait qu'il ne peut accueillir que
des [**modèles de traitement**](ae2:items-blocks-machines/patterns.md) : il ne fonctionnera donc pas vraiment avec l'<ItemLink id="ae2:molecular_assembler" />.

<Row>
  <RecipeFor id="mega_pattern_provider" />
  <RecipeFor id="cable_mega_pattern_provider" />
</Row>
