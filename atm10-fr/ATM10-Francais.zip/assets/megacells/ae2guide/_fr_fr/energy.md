---
navigation:
  title: Stockage d'énergie
  icon: greater_energy_card
  parent: index.md
  position: 030
categories:
  - megacells
item_ids:
  - mega_energy_cell
  - greater_energy_card
---

# MEGA Cells : énergie

Il serait évidemment inconcevable que MEGA ne fournisse pas aussi une forme de stockage d'[énergie](ae2:ae2-mechanics/energy.md)
plus grande, donc heureusement ce besoin est couvert ici aussi.

## Cellule énergétique superdense

<BlockImage id="mega_energy_cell" scale="4" />

La *cellule énergétique superdense* contient 8 fois plus d'énergie qu'une <ItemLink id="ae2:dense_energy_cell" /> et 64 fois plus
qu'une <ItemLink id="ae2:energy_cell" /> standard, pour un total allant jusqu'à 12,8 *millions* d'AE par cellule. Parfaite pour ces
installations de [Spatial IO](ae2:ae2-mechanics/spatial-io.md) particulièrement grandes et pour les opérations de transfert nécessitant un tampon
d'énergie immense, désormais dans un volume plus compact !

<RecipeFor id="mega_energy_cell" />

## Carte d'énergie supérieure

<ItemImage id="greater_energy_card" scale="3" />

Mieux encore, la cellule énergétique superdense permet de fabriquer une version dopée de la
<ItemLink id="ae2:energy_card" />, offrant un tampon d'énergie encore plus grand à toute infrastructure sans fil comme
les disques de stockage portables et les [terminaux sans fil](ae2:items-blocks-machines/wireless_terminals.md). Les appareils de ce type d'AE2
la prennent en charge aussi bien que la carte d'énergie classique. En revanche, les [disques portables MEGA](storage.md#portable-cells),
plus exigeants, n'accepteront *que* la carte d'énergie supérieure pour augmenter leur capacité de
batterie.

<RecipeFor id="greater_energy_card" />
