---
navigation:
    parent: ae2:items-blocks-machines/items-blocks-machines-index.md
    icon: ae2netanalyser:tick_analyser
    title: Profileur de ticks ME
categories:
- tools
item_ids:
- ae2netanalyser:tick_analyser
---

# Analyser la cadence de ticks ME

<ItemImage id="ae2netanalyser:tick_analyser" scale="4"></ItemImage>

Il arrive que votre jeu devienne saccadé lorsque vous avez un réseau ME vraiment énorme, mais il est plutôt difficile d'identifier
la source du ralentissement dans le réseau. Désormais, vous pouvez trouver facilement ce qui ralentit le jeu grâce au Profileur de ticks ME.

## Qu'est-ce qui fait ramer votre jeu ?

Certains dispositifs AE effectuent leur travail pendant le tick de jeu. Le Profileur de ticks ME peut mesurer le temps (μs/tick) dont ils ont besoin pour terminer 
leur travail et afficher ces valeurs directement dans le monde, ce qui vous aide à déterminer qui prend le plus de temps.

**Vous avez besoin de la permission OP pour l'utiliser sur un serveur multijoueur, afin d'éviter les abus.**

![overview](./pic/tick_rate.png)

La couleur indique à quel point le bloc ralentit le jeu. Plus c'est rouge, plus ça rame.

Le nombre indique la cadence de ticks de ce bloc. Votre jeu deviendra saccadé si le TPS (ticks par seconde) descend en dessous de 20.
Autrement dit, la cadence de ticks du jeu doit toujours rester inférieure à 50000 μs/tick.

De manière générale, la cadence de ticks de la plupart des blocs devrait être inférieure à 100 μs/tick, sinon ils risquent de provoquer des ralentissements.

## Affichage personnalisé

Vous pouvez contrôler l'affichage dans le monde des différentes cadences de ticks dans l'interface de configuration.

![gui](./pic/gui2.png)

Le point vert indique l'affichage des blocs se situant dans la plage de cadence de ticks correspondante. Cliquez sur le point pour activer/désactiver
l'affichage.
