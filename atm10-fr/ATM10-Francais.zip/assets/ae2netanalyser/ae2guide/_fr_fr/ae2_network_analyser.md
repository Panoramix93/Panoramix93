---
navigation:
    parent: ae2:items-blocks-machines/items-blocks-machines-index.md
    icon: ae2netanalyser:network_analyser
    title: Analyseur de réseau ME
categories:
- tools
item_ids:
- ae2netanalyser:network_analyser
---

# Analyser un réseau ME

<ItemImage id="ae2netanalyser:network_analyser" scale="4"></ItemImage>

Vous avez déjà galéré à trouver quel appareil de votre réseau ME est hors ligne ? Ou vous voulez simplement voir comment
votre réseau fonctionne ? Voici l'analyseur de réseau ME !

## Que se passe-t-il dans mon réseau ME ?

Cliquez sur n'importe quel bloc, câble ou appareil connecté au réseau ME, et vous verrez l'état de chaque appareil ainsi
que la façon dont ils sont reliés entre eux.

![overview](./pic/showoff.png)

Les couleurs et les formes représentent des états différents.
- Cube bleu : appareils ME normaux, ils ont assez de canaux et peuvent en faire passer 8.
- Cube jaune : appareils ME denses, ils ont assez de canaux et peuvent en faire passer 32.
- Cube rouge : appareils ME hors ligne, ils n'ont pas assez de canaux.
- Liaison bleue : cette liaison peut transporter 8 canaux au maximum.
- Liaison jaune : cette liaison peut transporter 32 canaux au maximum.
- Liaison rose : il s'agit d'une liaison P2P ME.
- Nombres : le nombre de canaux transportés par cette liaison.

Notez que le nombre maximal de canaux dépend en réalité de votre mode de canaux ME. L'analyseur n'affiche pas les
nombres de canaux lorsque le mode Canaux infinis est activé.

## Affichage personnalisé

Vous pouvez changer le mode d'analyse et les couleurs dans l'interface de configuration.

![gui](./pic/gui.png)

L'analyseur de réseau ME dispose de 5 modes.
- Complet : affiche tout l'état du réseau.
- Nœuds : n'affiche que l'état des nœuds.
- Liaisons : n'affiche que l'état des liaisons.
- Sans nombre : n'affiche pas le nombre de canaux.
- P2P : n'affiche que les liaisons P2P ME.

Vous pouvez aussi changer la couleur des nœuds ou des liaisons.

![gui2](./pic/color.png)
