# Traduction française d'All the Mods 10 — fichiers sources

Tout le texte est ici, découpé pour pouvoir être envoyé en amont mod par mod.
Aucun crédit demandé. Servez-vous.

## `lang/`

Un dossier par mod, nommé d'après son namespace. Dans chacun, le fichier est
déjà au chemin qu'il doit avoir dans le dépôt du mod :

```
lang/mekanism/assets/mekanism/lang/fr_fr.json
```

Pour contribuer à un mod : copiez le contenu de `lang/<namespace>/` à la racine
de `src/main/resources/` du dépôt, et ouvrez une PR intitulée
« Add French (fr_fr) translation ».

Attention : ces fichiers ont été extraits des jars livrés dans ATM10, donc
d'une version figée du mod. Avant d'ouvrir une PR, comparez au `en_us.json`
actuel du dépôt pour retirer les clés disparues et repérer les nouvelles.

Si le dépôt contient un `crowdin.yml` ou renvoie vers Crowdin ou Weblate,
passez par la plateforme : une PR GitHub y serait écrasée à la synchro
suivante.

348 fichiers, 140 189 clés.

## `guides/`

Les textes qui ne vivent pas dans les fichiers de langue, aux chemins qu'ils
ont dans un pack de ressources :

- `patchouli/` — 26 livres Patchouli, 1 474 fichiers
- `ae2/` — guide GuideME d'AE2 et de ses add-ons, 223 pages
- `immersive-engineering/` — Manuel de l'ingénieur, 114 pages
- `ice-and-fire-bestiaire/` — bestiaire, 80 pages

## Ce qui n'est pas ici

- La traduction des quêtes FTB Quests (70 chapitres) : contenu AllTheMods,
  distribué séparément.
- Le titre et la page de garde de 17 livres Patchouli : Patchouli lit ces deux
  champs directement dans le jar du mod, ni un pack de ressources ni un
  datapack ne peuvent les remplacer.
- L'aide des ordinateurs ComputerCraft, qui vit dans `data/` et non dans les
  ressources.

## État

Traduction produite en une passe et validée mécaniquement : clés, placeholders
(`%s`, `%d`, `{0}`), codes couleur `§`, macros Patchouli, balises GuideME,
nombre de lignes. Tout est vérifié.

Elle n'a pas été relue en jeu. Quelques choix de vocabulaire restent discutables
sur les gros mods techniques, notamment autour d'Applied Energistics
(*pattern* / « modèle », *Inscriber* → « Presse ») et d'Immersive Engineering.
Les corrections sont bienvenues.
